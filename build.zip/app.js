const APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbyqpppW2wnxH4nAYrZDaIu0XedFB5wfOeUXXokxFz4TpslB-GqD24B9GsPp0i_nTJ4GVA/exec';

const TRAINER_CHAT_ID = '739299264';
const TRAINER_VK_CHAT_ID = 'vk_458191089'; // тот же тренер, но заходит через VK

// 2026-08-19: у Matvey (дефолт-тенант) второй вход, кроме Telegram — его
// собственная VK-группа matpavbot (vk_group_id=240408566). Раньше при входе
// оттуда CURRENT_TRAINER_ID становился этим числом, _newApiTrainerId() не
// узнавал его ни как пилотного тренера, ни как дефолт-тенанта — и падал в
// "нет доступа". См. _newApiTrainerId ниже и project_vk_hosting_migration
// в памяти.
const MATVEY_VK_GROUP_ID = '240408566';
// Сырые launch-параметры VK (с sign) — снимок ДО того, как что-либо их
// тронет, нужен бэкенду для проверки подписи (см. vk_auth.py). Именно
// window.location.search целиком, не отдельные поля.
const VK_LAUNCH_PARAMS_RAW = window.location.search.replace(/^\?/, '');

// Мульти-тенантность: если мини-апп открыт из сообщества тренера, VK кладёт
// vk_group_id в параметры запуска — это и есть trainerId для бэкенда (см.
// apps_script.js _resolveTenant). Без него (Telegram, или VK без группы) —
// пусто, бэкенд использует тенанта по умолчанию (Matvey), как и раньше.
// НЕ const: VK не всегда пробрасывает vk_group_id в ссылку (например, если
// открыть мини-апп не той самой ссылкой из сообщения бота) — в этом случае
// бэкенд сам находит тенанта по chatId (см. _resolveTrainerIdByChatId в
// apps_script.js), а loadTenantConfig() ниже подхватывает узнанный trainerId
// и переучивает эту переменную, чтобы ВСЕ следующие запросы тоже шли верно.
//
// superadmin_view_trainer_id (2026-08-19, см. openAsTrainer) — приоритетнее
// vk_group_id: супер-админ (Matvey) просматривает ЧУЖОГО тренера, не меняя
// свою собственную подпись VK/Telegram (та остаётся как есть в URL/сессии,
// см. VK_LAUNCH_PARAMS_RAW ниже) — бэкенд узнаёт "это супер-админ, ему можно
// любой /trainers/{id}/..." по ПОДПИСИ, не по этому параметру, см.
// require_telegram_or_vk_auth_for_trainer_routes в main.py.
//
// Параметр ищем и в строке запроса, и в хеше: кнопка open_app во VK (см.
// _mini_app_keyboard в vk_bot.py) отдаёт свои данные приложению именно как
// #vk_group_id=..., а не как ?vk_group_id=... Раньше бот присылал текстовую
// ссылку, VK открывал её во встроенном браузере, и параметр приходил в
// запросе — теперь открытие родное, а параметр в хеше.
function _launchParam(name) {
    try {
        var q = new URLSearchParams(window.location.search).get(name);
        if (q) return q;
        var h = String(window.location.hash || '').replace(/^#/, '');
        return h ? (new URLSearchParams(h).get(name) || '') : '';
    } catch (_) { return ''; }
}

let CURRENT_TRAINER_ID = _launchParam('superadmin_view_trainer_id') ||
    _launchParam('vk_group_id') || '';

// Тема текущего тенанта, подтягивается в init() через loadTenantConfig().
// tenantTrainerChatId — фоллбэк для isTrainer() у тренеров, подключённых
// после этого шага (у самого Matvey и так есть хардкод выше, на всякий случай).
let tenantTheme = null;
let tenantTrainerChatId = '';

function isTrainer(chatId) {
    return chatId === TRAINER_CHAT_ID || chatId === TRAINER_VK_CHAT_ID ||
        (!!tenantTrainerChatId && chatId === tenantTrainerChatId);
}

// Прозрачно добавляем trainerId ко всем запросам к Apps Script, не трогая
// каждый из ~40 существующих fetch(...) по всему файлу. Без CURRENT_TRAINER_ID
// (обычный Telegram-запуск или VK без группы) ничего не добавляется —
// поведение как раньше.
//
// Заодно ретраим запросы к Apps Script при СЕТЕВОМ сбое (fetch кидает
// исключение, например Safari "Load failed" / "Failed to fetch") — это
// известная особенность хостинга на script.google.com: он отдаёт 302-редирект
// на одноразовый googleusercontent.com URL, и этот "хвост" иногда рвётся без
// всякой связи с нашим кодом ("раз через раз грузит"). НЕ ретраим по статусу
// ответа (200 с {error:...} внутри — это уже настоящая ошибка, не сетевая) —
// только когда fetch вообще не смог достучаться до сервера.
//
// _withTimeout: у fetch() нет таймаута по умолчанию — если соединение просто
// зависает (не рвётся с ошибкой, а молча не отвечает — бывает во встроенных
// браузерах вроде VK-приложения на телефоне, где сеть строже), await fetch()
// висит вечно и вообще не доходит ни до catch выше, ни до отображения ошибки
// — человек видит бесконечный спиннер (см. жалобу "во VK на телефоне крутит
// загрузку бесконечно", 2026-08-12). Promise.race не отменяет сам запрос, но
// перестаёт его ждать и даёт остальному коду (ретраю/экрану ошибки) сработать.
function _withTimeout(promise, ms) {
    return new Promise(function(resolve, reject) {
        var timer = setTimeout(function() { reject(new Error('Таймаут запроса (' + (ms / 1000) + ' с)')); }, ms);
        promise.then(function(v) { clearTimeout(timer); resolve(v); },
                     function(e) { clearTimeout(timer); reject(e); });
    });
}
// Сколько ждать ответа. 15 секунд хватает обычному запросу к базе, но не
// действию, где по мобильной сети уезжает пара фотографий или где на той
// стороне работает ИИ: загрузка упражнения с двумя снимками из зала со
// слабым сигналом упиралась в этот лимит и выглядела как «ошибка
// соединения», хотя запрос был жив. Для таких действий срок отдельный.
var SLOW_ACTIONS = {
    saveExerciseMedia: 90000,      // два фото уходят на сервер
    addClientExercises: 120000,    // блок сохраняется по одному упражнению за раз
    generateMealPlanAI: 90000,     // на той стороне думает модель
    saveMeasurements: 60000,       // фото прогресса
    sendMonthlyReportToClient: 30000
};
var DEFAULT_ACTION_TIMEOUT = 15000;

function _actionTimeout(action) {
    return SLOW_ACTIONS[action] || DEFAULT_ACTION_TIMEOUT;
}

function _fetchWithRetry(nativeFetch, input, init, retriesLeft) {
    return _withTimeout(nativeFetch(input, init), 15000).catch(function(err) {
        if (retriesLeft <= 0) throw err;
        return new Promise(function(resolve) { setTimeout(resolve, 700); })
            .then(function() { return _fetchWithRetry(nativeFetch, input, init, retriesLeft - 1); });
    });
}

// ── Фаза 4 пилот (см. MIGRATION_PLAN.md, 2026-08-13) ────────────────────────
// Для ОДНОГО trainerId (сейчас — Роман) НЕКОТОРЫЕ read-запросы уходят не в
// Apps Script, а в новый Python API (Postgres) на Railway. Намеренно узкий
// срез — только чтение (getClients/getClientProfile/getMeasurements/
// getClientFoodEntries/getExerciseLibrary/getExerciseMediaLibrary/
// getMealPlanForClient), никакой записи. Всё остальное продолжает идти в Apps Script
// как раньше — НИКАКИХ изменений для любого другого trainerId, в том числе
// для Matvey по умолчанию (без trainerId вообще): action просто не найдётся
// в NEW_API_ACTIONS, код пойдёт по старому пути ниже, 1-в-1 как было.
//
// NEW_API_KEY виден любому, кто откроет исходник страницы — это браузер, не
// сервер, спрятать его тут физически нельзя. Не настоящий секрет, а тот же
// уровень защиты, что был у APPS_SCRIPT_URL раньше (публичный адрес плюс
// нужно знать trainerId/chatId). Обсуждали с Matvey — приемлемо для пилота
// на пустом тенанте; для реальных данных понадобится другой механизм
// (проверка подписи VK/Telegram initData на сервере, а не общий ключ).
// 2026-08-18: NEW_API_BASE переключён с Railway на Timeweb App Platform —
// именно та инфраструктурная проблема, описанная ниже (Railway требует
// VPN, VK работает только без VPN), и есть причина переезда, см.
// project_vk_hosting_migration в памяти/MIGRATION_PLAN.md. Данные (все 12
// таблиц) перенесены и сверены 2026-08-18, счётчики автоинкремента
// поправлены. NEW_API_KEY тот же — совпадает с API_SECRET на обоих
// бэкендах намеренно, чтобы фронтенду не нужно было ничего менять кроме
// адреса.
var NEW_API_BASE = 'https://matveyvvedenie-ctrl-fitness-telegram-bot-c136.twc1.net';
var NEW_API_KEY = '72bdc5e9073da1309592590508c0098bcaad8139c82aeafa77438c2ed46f7e61';
// 2026-08-16: Рома временно ВЫКЛЮЧЕН из пилота — не может открыть мини-апп
// во VK на телефоне (таймаут 15 сек на каком-то запросе к новому бэкенду;
// VK-десктоп и Telegram работают у других). Подозрение — VK-мобильное
// приложение специфично не может достучаться до Railway (fitness-api),
// хотя сам Railway отвечает быстро при проверке отсюда. Пока разбираюсь —
// откатил на старый Apps Script (проверенно надёжный для него), чтобы Рома
// прямо сейчас мог попасть в мини-апп. См. MIGRATION_PLAN.md.
// 2026-08-16 (снова выключено): подтверждено напрямую — Railway
// (fitness-api-fitness-bot-v2.up.railway.app) требует VPN, а VK у Романа
// требует VPN ВЫКЛЮЧЕННЫМ — структурный конфликт, не баг в коде. Без VPN
// страница у него не грузит tenant-config (и любой другой запрос к
// новому бэкенду) вообще, с VPN — мгновенно отвечает. Инфраструктурный
// вопрос, не решается правкой фронтенда/бэкенда — см. MIGRATION_PLAN.md.
// 2026-08-18: включаю снова — на этот раз бэкенд на Timeweb (NEW_API_BASE
// выше), а не на Railway, структурная причина VPN-конфликта устранена
// (подтверждено живьём: без VPN у Matvey — грузится, с VPN — нет,
// зеркально прежней railway-проблеме). Если у Ромы опять не откроется —
// сразу откатить обратно на {} и разбираться заново с нуля, не
// предполагать что причина та же самая.

// ── Фаза 5 (2026-08-15, см. MIGRATION_PLAN.md) ──────────────────────────────
// Matvey — тенант ПО УМОЛЧАНИЮ в старой системе (_resolveTenant('') в
// apps_script.js), у него в принципе НЕТ trainerId — поэтому CURRENT_TRAINER_ID
// сработает (в отличие от Романа, у которого trainerId есть в ссылке).
// CURRENT_TRAINER_ID как есть — эта же переменная used для трейлинга
// ?trainerId=... к запросам в СТАРЫЙ Apps Script (см. ниже, isAppsScript-ветка);
// если её подменить на 739299264, apps_script.js._resolveTenant('739299264')
// не найдёт такую строку в реестре "Тренеры" (Matvey там не зарегистрирован,
// он и есть дефолт) — и ВСЁ, что ещё не перенесено, разом сломается на
// старом бэкенде. Поэтому — отдельная функция ТОЛЬКО для путей к новому API,
// CURRENT_TRAINER_ID остаётся нетронутым везде, где он был раньше.
//
// "Это точно Matvey" различаем узко и консервативно: пустой CURRENT_TRAINER_ID
// (не Роман, не какой-то другой тенант) И запуск НЕ через VK-без-группы
// (vkLaunchUserId, см. ниже по файлу — объявлена как var, но код здесь
// исполняется лишь при вызовах fetch НАМНОГО позже разбора скрипта, так что
// объявление уже отработает к моменту вызова). Архитектурно у Matvey только
// Telegram-бот (bot.py, один токен, один тенант) — остальные тренеры/их
// клиенты заходят через vk_bot.py, всегда СО своим vk_group_id. Значит
// пустой CURRENT_TRAINER_ID + Telegram = однозначно Matvey, без гадания.
// VK-запуск БЕЗ группы сознательно НЕ трогаем — у старой системы там есть
// отдельный фоллбэк-резолвинг по chatId (_resolveTrainerIdByChatId), который
// в теории может привести к ЛЮБОМУ тренеру, а не только к Matvey — гадать
// на фронте не будем, оставляем такой запуск на старом бэкенде как есть.
var NEW_API_DEFAULT_TENANT_TRAINER_ID = '739299264'; // Matvey, см. DEFAULT_TRAINER_CHAT_ID в apps_script.js

// 2026-08-20. Тенант, УЗНАННЫЙ по самому человеку (см. resolveTenantForVkUser
// ниже) — для запусков во VK БЕЗ vk_group_id в ссылке. Отдельная переменная,
// а НЕ подмена CURRENT_TRAINER_ID: та живёт в пространстве vk_group_id и
// используется для трейлинга &trainerId=... к старому Apps Script, положить
// туда канонический trainer_id уже один раз всё ломало (см. комментарий в
// loadTenantConfig и коммит d5820b6).
var NEW_API_RESOLVED_TRAINER_ID = '';

function _newApiTrainerId() {
    // Какому тренеру принадлежит то, что мы сейчас читаем и пишем.
    //
    // 2026-08-24. Раньше здесь был список «пилотных» тренеров: на новый
    // бэкенд пускали только тех, кто в нём перечислен, остальные шли в старый
    // Apps Script. Список остался с этапа переезда, когда на новой базе жил
    // один Роман. Переезд давно закончен, а список — нет: Анну завели,
    // запись в базе появилась, а мини-апп продолжал спрашивать про неё
    // старую систему и получал «Тренер не найден». Каждый следующий тренер
    // ломался бы точно так же в день создания.
    //
    // Теперь наоборот: тенант из ссылки работает со своей записью в базе,
    // никаких списков. Особые случаи ниже — только про то, как узнать
    // ДЕФОЛТНОГО тенанта (Matvey), у которого id не совпадает с VK-группой.

    // Явно узнанный тенант важнее любых догадок (см. resolveTenantForVkUser).
    if (NEW_API_RESOLVED_TRAINER_ID) return NEW_API_RESOLVED_TRAINER_ID;

    // Собственная VK-группа Matvey — тот же дефолт-тенант, просто вход с
    // другим «паспортом»: подпись VK вместо Telegram. Его id в базе —
    // Telegram-id, а не номер группы, см. gotcha_trainer_id_vs_vk_group_id.
    if (CURRENT_TRAINER_ID === MATVEY_VK_GROUP_ID) return NEW_API_DEFAULT_TENANT_TRAINER_ID;

    // Любой другой тренер из ссылки — работает со своей записью.
    if (CURRENT_TRAINER_ID) return CURRENT_TRAINER_ID;

    // Тенанта в ссылке нет. Telegram — там всегда Matvey (бот у площадки
    // один). Его же личная VK-ссылка без группы — тоже он.
    if (!vkLaunchUserId || vkLaunchUserId === TRAINER_VK_CHAT_ID.replace('vk_', '')) {
        return NEW_API_DEFAULT_TENANT_TRAINER_ID;
    }

    // Остаётся VK-запуск без группы у кого-то другого: кто это, здесь не
    // угадать — тенанта определит резолвер по самому человеку.
    return '';
}

function _fakeJsonResponse(obj, status) {
    return new Response(JSON.stringify(obj), { status: status, headers: { 'Content-Type': 'application/json' } });
}

// Заголовки для запросов к новому API. Для дефолт-тенанта (Matvey, реальные
// клиенты/деньги, см. MIGRATION_PLAN.md Фаза 5) бэкенд ТРЕБУЕТ ещё и
// X-Telegram-Init-Data (см. api/telegram_auth.py) — X-Api-Key один сам по
// себе виден в исходнике страницы (GitHub Pages публичен), initData
// подделать нельзя без токена бота, которого во фронтенде нет и не будет.
// Для остальных тренеров (Роман и т.п., пока без реальных денег/данных)
// пока достаточно X-Api-Key, как и раньше — сознательно узкая правка.
function _newApiHeaders(extra) {
    var headers = { 'X-Api-Key': NEW_API_KEY };
    if (extra) { for (var k in extra) headers[k] = extra[k]; }
    // 2026-08-19: раньше слали X-Telegram-Init-Data/X-VK-Launch-Params ТОЛЬКО
    // для дефолт-тенанта (Matvey) — для остальных пилотных тренеров (Роман)
    // бэкенд проверял только X-Api-Key, а он публично виден в исходнике
    // app.js на GitHub Pages — то есть curl с этим ключом мог напрямую читать/
    // писать данные ЛЮБОГО пилотного тренера в обход VK вообще. Раньше это
    // было осознанным компромиссом ("у Романа терять нечего, пустой пилот") —
    // с реальными клиентами так уже нельзя. Шлём эти заголовки всегда, когда
    // они доступны — бэкенду они не мешают, если конкретный маршрут их пока
    // не требует (только дефолт-тенант) — а как только require_telegram_auth
    // расширят на остальных пилотных тренеров (main.py), всё уже готово, без
    // повторного передеплоя фронтенда.
    if (tg && tg.initData) {
        headers['X-Telegram-Init-Data'] = tg.initData;
    } else if (vkLaunchUserId && VK_LAUNCH_PARAMS_RAW) {
        headers['X-VK-Launch-Params'] = VK_LAUNCH_PARAMS_RAW;
    }
    return headers;
}

// 2026-08-19: найдено по жалобе Романа — в VK на телефоне мини-апп "раз через
// раз" падал с "Ошибка загрузки / Load failed", перезагрузка страницы (=
// свежая попытка) чинила. Причина — асимметрия с _fetchWithRetry (старый путь
// к Apps Script, ретраит дважды на СЕТЕВОЙ сбой): _newApiCall (а через неё —
// вообще ВСЁ чтение с нового бэкенда, включая getTenantConfig/read — то, с
// чего стартует загрузка) вообще не ретраила, один случайный обрыв соединения
// сразу долетал до пользователя текстом ошибки.
//
// НЕ добавляем сюда свой _withTimeout — общий таймаут на зависшую цепочку и
// так уже есть СНАРУЖИ (monkey-patch fetch ниже, 15 секунд на весь результат
// хендлера целиком) — свой таймаут тут конфликтовал бы с ним (два таймера
// гонялись бы за одним и тем же результатом), а не помогал. Ретраим только на
// УЖЕ случившийся сбой fetch() (нечего ждать, повторяем сразу) — весь повтор
// укладывается в доли секунды, бюджет внешнего таймаута на реально зависший
// запрос не крадёт.
function _fetchNewApiWithRetry(nativeFetch, url, init, retriesLeft) {
    return nativeFetch(url, init).catch(function(err) {
        if (retriesLeft <= 0) throw err;
        return new Promise(function(resolve) { setTimeout(resolve, 400); })
            .then(function() { return _fetchNewApiWithRetry(nativeFetch, url, init, retriesLeft - 1); });
    });
}

// Приводит дни истории к тому, что ждёт renderClientHistory: dateObj (эпоха
// мс, дефолта нет — formatHistoryDate/daysAgoLabel без него дадут NaN), date
// как "dd.MM.yyyy", feedback по RPE.
function _formatHistoryDays(days) {
    return (days || []).map(function(day) {
        return {
            date: _isoDateToRu(day.date), dateObj: Date.parse(day.date + 'T00:00:00'), key: day.date,
            exercises: (day.exercises || []).map(function(ex) {
                var out = {};
                for (var k in ex) out[k] = ex[k];
                out.feedback = _rpeToFeedback(ex.rpe);
                return out;
            })
        };
    });
}

function _newApiCall(nativeFetch, path) {
    // 2026-08-19: было 1 повтор (2 попытки всего) — по факту оказалось мало.
    // Прямые замеры (curl на /health, 20 запросов подряд) поймали 15% сырых
    // сбоев соединения до Timeweb прямо в моменте — с одним повтором шанс
    // поймать сбой ДВАЖДЫ подряд на один вызов всё равно ~2%, а вызовов на
    // загрузку минимум два (getTenantConfig + read) — заметный процент живых
    // "Load failed" у реальных пользователей, ровно то, на что жаловался
    // Роман/Ася. 3 повтора (4 попытки) — тот же сбой подряд 4 раза ~0.05%,
    // с большим запасом укладывается в общий бюджет 15с (см. комментарий
    // выше — попытки быстро проваливаются, не ждут таймаута).
    return _fetchNewApiWithRetry(nativeFetch, NEW_API_BASE + path, { headers: _newApiHeaders() }, 3)
        .then(function(r) { return r.json().then(function(data) { return { ok: r.ok, status: r.status, data: data }; }); });
}

// getClientHistory/getLastExerciseResult в старой системе ключуются по имени
// клиента (общий лист "Заметки"/"История" на тренера), не по chatId — новый
// API ключует по chatId. Резолвим через уже готовый список клиентов (лишний
// запрос, но эти экшены и так не самые частые). Кэш на время жизни вкладки —
// список клиентов Романа меняется редко, а если что — просто обновит страницу.
var _nameToChatIdCache = null;
function _resolveChatIdByName(nativeFetch, name) {
    if (_nameToChatIdCache) return Promise.resolve(_nameToChatIdCache[name] || null);
    var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients';
    return _newApiCall(nativeFetch, path).then(function(res) {
        _nameToChatIdCache = {};
        (res.ok ? (res.data.clients || []) : []).forEach(function(c) { _nameToChatIdCache[c.name] = c.chatId; });
        return _nameToChatIdCache[name] || null;
    });
}

// Общее преобразование ответа GET .../program под то, что ждёт старый
// фронтенд-код (readWorkoutData/readClientProgram в apps_script.js) — общее
// между readClientProgram (тренер смотрит ЧУЖУЮ программу) и read (клиент
// смотрит СВОЮ). rowIndex — это integer `id` из новой БД под старым именем
// поля, как и везде в этом файле. photo1/photo2/videoVk — раньше отдавались
// пустыми (файлового хранилища для фото ещё не было), бэкенд теперь сам
// матчит их из библиотеки упражнений по имени (см. _exercise_photo_map в
// main.py) — просто прокидываем как есть. completed/timestamp — были
// пустышками и в оригинале, не трогаем.
function _mapProgramDays(rawDays) {
    return (rawDays || []).map(function(day) {
        return {
            day: day.day,
            exercises: (day.exercises || []).map(function(ex) {
                return {
                    rowIndex: ex.id, exercise: ex.exercise, sets: ex.sets, reps: ex.reps,
                    weightPlan: ex.weightPlan, rpe: ex.rpe, video: ex.video || '', videoVk: ex.videoVk || '',
                    note: ex.note, weightFact: ex.weightFact, repsFact: ex.repsFact,
                    completed: false, timestamp: '', comment: ex.comment,
                    photo1: ex.photo1 || '', photo2: ex.photo2 || ''
                };
            })
        };
    });
}

// Портировано 1-в-1 из _rpeToFeedback в apps_script.js — новый API отдаёт
// голый rpe, бейдж "Легко/Норм/Тяжело/Не вытянул" собираем на лету.
function _rpeToFeedback(rpe) {
    if (rpe === '' || rpe == null) return null;
    var n = parseFloat(rpe);
    if (isNaN(n)) return null;
    if (n <= 6.5) return { code: 'easy', label: 'Легко', emoji: '😌' };
    if (n <= 8.5) return { code: 'normal', label: 'Норм', emoji: '💪' };
    if (n <= 9.5) return { code: 'hard', label: 'Тяжело', emoji: '🔥' };
    return { code: 'failed', label: 'Не вытянул', emoji: '❌' };
}

// ISO-datetime ("2026-08-13T09:32:16...") -> "dd.MM.yyyy HH:mm", как раньше
// писал apps_script.js. Локальное время браузера — старая система брала
// таймзону скрипта (Europe/Moscow), тут для заметки-другой разница в часовом
// поясе не критична, а усложнять ради этого не стоит.
function _fmtDateTime(iso) {
    try {
        var d = new Date(iso);
        var p2 = function(n) { return (n < 10 ? '0' : '') + n; };
        return p2(d.getDate()) + '.' + p2(d.getMonth() + 1) + '.' + d.getFullYear() + ' ' + p2(d.getHours()) + ':' + p2(d.getMinutes());
    } catch (_) { return iso; }
}

// ISO-дата ("yyyy-MM-dd", без времени) -> "dd.MM.yyyy". Вынесено сюда, было
// продублировано в getClientHistory и getFinances.
function _isoDateToRu(iso) {
    if (!iso) return '';
    var parts = iso.split('-');
    return parts.length === 3 ? (parts[2] + '.' + parts[1] + '.' + parts[0]) : iso;
}

var NEW_API_ACTIONS = {
    // Аналог action=getClients — форма ответа та же ({clients:[...]}), плюс
    // синтетический sheetName (реальных "листов" в новой БД нет; часть
    // старого кода его ожидает — например открытие программы клиента, что
    // пилотом пока не покрыто и честно упадёт "Sheet not found" на старом
    // бэкенде, если попробовать — это ожидаемый пробел, не баг).
    getClients: function(nativeFetch) {
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients';
        return _newApiCall(nativeFetch, path).then(function(res) {
            if (!res.ok) return _fakeJsonResponse({ error: (res.data && res.data.detail) || 'Ошибка' }, 200);
            var clients = (res.data.clients || []).map(function(c) {
                return { chatId: c.chatId, name: c.name, archived: c.archived, sheetName: c.name };
            });
            return _fakeJsonResponse({ clients: clients }, 200);
        });
    },
    // Аналог action=getClientProfile (targetChatId/clientChatId) — добавляем
    // success:true, старый код это проверяет.
    getClientProfile: function(nativeFetch, params) {
        var chatId = params.get('targetChatId') || params.get('clientChatId') || '';
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/profile';
        return _newApiCall(nativeFetch, path).then(function(res) {
            if (!res.ok) return _fakeJsonResponse({ error: (res.data && res.data.detail) || 'Клиент не найден' }, 200);
            res.data.success = true;
            return _fakeJsonResponse(res.data, 200);
        });
    },
    // Дальше — ещё 4 read-экшена (2026-08-13), формы ответа у нового API уже
    // совпадают со старыми 1-в-1 (.measurements/.days/.exercises/.exists),
    // реформатировать почти нечего — только 404 клиента в {error:...}.
    getMeasurements: function(nativeFetch, params) {
        var chatId = params.get('chatId') || '';
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/measurements';
        return _newApiCall(nativeFetch, path).then(function(res) {
            if (!res.ok) return _fakeJsonResponse({ error: (res.data && res.data.detail) || 'Клиент не найден' }, 200);
            return _fakeJsonResponse(res.data, 200);
        });
    },
    getClientFoodEntries: function(nativeFetch, params) {
        var chatId = params.get('clientChatId') || params.get('chatId') || '';
        var days = params.get('days') || '14';
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) +
            '/food-entries?days=' + encodeURIComponent(days);
        return _newApiCall(nativeFetch, path).then(function(res) {
            if (!res.ok) return _fakeJsonResponse({ error: (res.data && res.data.detail) || 'Клиент не найден' }, 200);
            return _fakeJsonResponse(res.data, 200);
        });
    },
    // getExerciseLibrary и getExerciseMediaLibrary — один и тот же новый
    // эндпоинт (там уже расширенная форма с фото/видео, старому "простому"
    // getExerciseLibrary лишние поля не мешают).
    getExerciseLibrary: function(nativeFetch) {
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/exercises';
        return _newApiCall(nativeFetch, path).then(function(res) {
            if (!res.ok) return _fakeJsonResponse({ error: (res.data && res.data.detail) || 'Ошибка' }, 200);
            return _fakeJsonResponse(res.data, 200);
        });
    },
    getMealPlanForClient: function(nativeFetch, params) {
        var chatId = params.get('targetChatId') || params.get('clientChatId') || '';
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) +
            '/meal-plan?dayType=' + encodeURIComponent(params.get('dayType') || 'workout');
        return _newApiCall(nativeFetch, path).then(function(res) {
            if (!res.ok) return _fakeJsonResponse({ error: (res.data && res.data.detail) || 'Клиент не найден' }, 200);
            return _fakeJsonResponse(res.data, 200);
        });
    },
    // Ключуются по имени клиента (см. _resolveChatIdByName выше) — единственная
    // причина, почему их не добавили в прошлый раз вместе с остальным read.
    // История СВОЕЙ тренировки — для клиента. Отличие от getClientHistory
    // одно: клиент знает свой chatId и не должен резолвить его по имени
    // через список клиентов тенанта (чужие имена ему видеть незачем).
    getSelfHistory: function(nativeFetch, params) {
        var chatId = params.get('chatId') || '';
        if (!chatId) return _fakeJsonResponse({ history: [] }, 200);
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) +
            '/history?limit=' + encodeURIComponent(params.get('limit') || '60');
        return _newApiCall(nativeFetch, path).then(function(res) {
            if (!res.ok) return _fakeJsonResponse({ error: (res.data && res.data.detail) || 'Ошибка' }, 200);
            return _fakeJsonResponse({ history: _formatHistoryDays(res.data.history) }, 200);
        });
    },
    getClientHistory: function(nativeFetch, params) {
        var clientName = params.get('clientName') || '';
        var limit = params.get('limit') || '30';
        return _resolveChatIdByName(nativeFetch, clientName).then(function(chatId) {
            if (!chatId) return _fakeJsonResponse({ history: [] }, 200);
            var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) +
                '/history?limit=' + encodeURIComponent(limit);
            return _newApiCall(nativeFetch, path).then(function(res) {
                if (!res.ok) return _fakeJsonResponse({ error: (res.data && res.data.detail) || 'Ошибка' }, 200);
                return _fakeJsonResponse({ history: _formatHistoryDays(res.data.history) }, 200);
            });
        });
    },
    getLastExerciseResult: function(nativeFetch, params) {
        var clientName = params.get('clientName') || '';
        var exerciseName = params.get('exerciseName') || '';
        return _resolveChatIdByName(nativeFetch, clientName).then(function(chatId) {
            if (!chatId) return _fakeJsonResponse({ empty: true }, 200);
            var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) +
                '/exercises/' + encodeURIComponent(exerciseName) + '/last-result';
            return _newApiCall(nativeFetch, path).then(function(res) {
                if (!res.ok || res.data.empty) return _fakeJsonResponse({ empty: true }, 200);
                res.data.feedback = _rpeToFeedback(res.data.rpe);
                return _fakeJsonResponse(res.data, 200);
            });
        });
    },
    // Заметки — читаем И пишем вместе (не по одной, как остальное): удаление
    // ссылается на идентификатор заметки (`ts` в старой системе), и если бы
    // читали через новый API, а удаляли через старый (или наоборот), номера
    // разъехались бы. Тут `ts`, который видит фронтенд — это просто integer
    // `id` из новой БД, переданный под старым именем поля (фронт с ним не
    // делает ничего, кроме как отдаёт обратно при удалении — см. deleteClientNoteFlow).
    getClientNotes: function(nativeFetch, params) {
        var clientName = params.get('clientName') || '';
        return _resolveChatIdByName(nativeFetch, clientName).then(function(chatId) {
            if (!chatId) return _fakeJsonResponse({ notes: [] }, 200);
            var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/notes';
            return _newApiCall(nativeFetch, path).then(function(res) {
                if (!res.ok) return _fakeJsonResponse({ error: (res.data && res.data.detail) || 'Ошибка' }, 200);
                var notes = (res.data.notes || []).map(function(n) {
                    return { date: _fmtDateTime(n.date), text: n.text, important: n.important, ts: n.id };
                });
                return _fakeJsonResponse({ notes: notes }, 200);
            });
        });
    },
    addClientNote: function(nativeFetch, params) {
        var clientName = params.get('clientName') || '';
        var text = params.get('text') || '';
        var important = params.get('important') === 'true';
        return _resolveChatIdByName(nativeFetch, clientName).then(function(chatId) {
            if (!chatId) return _fakeJsonResponse({ success: false, error: 'Клиент не найден' }, 200);
            var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/notes';
            return nativeFetch(NEW_API_BASE + path, {
                method: 'POST', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
                body: JSON.stringify({ text: text, important: important })
            }).then(function(r) { return r.json().then(function(data) {
                if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
                return _fakeJsonResponse({ success: true, ts: data.id, date: _fmtDateTime(data.date) }, 200);
            }); });
        });
    },
    deleteClientNote: function(nativeFetch, params) {
        var clientName = params.get('clientName') || '';
        var ts = params.get('ts') || ''; // на самом деле id из новой БД, см. комментарий выше
        return _resolveChatIdByName(nativeFetch, clientName).then(function(chatId) {
            if (!chatId) return _fakeJsonResponse({ success: false, error: 'Клиент не найден' }, 200);
            var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/notes/' + encodeURIComponent(ts);
            return nativeFetch(NEW_API_BASE + path, { method: 'DELETE', headers: _newApiHeaders() })
                .then(function(r) {
                    if (r.status === 204 || r.ok) return _fakeJsonResponse({ success: true }, 200);
                    return r.json().then(function(data) {
                        return _fakeJsonResponse({ success: false, error: (data && data.detail) || 'Заметка не найдена' }, 200);
                    });
                });
        });
    },
    // Аналог action=createNewClient. Копирование программы у другого клиента
    // (programOpts.type === 'copy') новый бэкенд не умеет — там нет
    // отдельного "листа программы", который можно было бы скопировать (см.
    // docstring create_client в api/main.py: клиент создаётся без единой
    // недели, пока тренер не добавит первое упражнение). В этом случае честно
    // отдаём null — уходит в старый Apps Script, тот же приём, что и у фото в
    // saveMeasurements ниже. Только programOpts.type === 'blank' (пустая
    // программа) перехватываем.
    createNewClient: function(nativeFetch, params) {
        var profile = JSON.parse(params.get('profile') || '{}');
        var programOpts = JSON.parse(params.get('programOpts') || '{}');
        if (programOpts.type === 'copy') return null; // фолбэк на старый бэкенд
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients';
        return nativeFetch(NEW_API_BASE + path, {
            method: 'POST', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify(profile)
        }).then(function(r) { return r.json().then(function(data) {
            if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
            return _fakeJsonResponse({ success: true, chatId: data.chatId, name: data.name }, 200);
        }); });
    },
    // Симметричная запись к уже готовому чтению — форма ответа у обоих уже
    // {success:true[, ...]}, как ждёт старый код, реформатировать нечего.
    updateClientProfile: function(nativeFetch, params) {
        var chatId = params.get('targetChatId') || params.get('clientChatId') || '';
        var fields = {};
        _PROFILE_KEYS.forEach(function(k) { if (params.has(k)) fields[k] = params.get(k); });
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/profile';
        return nativeFetch(NEW_API_BASE + path, {
            method: 'PATCH', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify(fields)
        }).then(function(r) { return r.json().then(function(data) {
            if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
            return _fakeJsonResponse(data, 200);
        }); });
    },
    // Аналог action=renameClientChatId/setClientChatId — тренер поправляет
    // chat_id клиента (например, завели по Telegram id, а клиент зашёл
    // через VK). У нового API есть уникальный индекс (trainer_id, chat_id)
    // — попытка поставить уже занятый chat_id честно возвращает ошибку
    // вместо тихой коллизии строк, как было бы в старой системе. Сбрасываем
    // кэш имя→chatId (см. _resolveChatIdByName выше) — иначе он бы молча
    // отдавал старый chatId до перезагрузки страницы.
    renameClientChatId: function(nativeFetch, params) {
        var oldChatId = params.get('oldChatId') || '';
        var newChatId = params.get('newChatId') || '';
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(oldChatId) + '/chat-id';
        return nativeFetch(NEW_API_BASE + path, {
            method: 'PATCH', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({ newChatId: newChatId })
        }).then(function(r) { return r.json().then(function(data) {
            if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
            _nameToChatIdCache = null;
            return _fakeJsonResponse({ success: true }, 200);
        }); });
    },
    setClientArchived: function(nativeFetch, params) {
        var chatId = params.get('targetChatId') || params.get('clientChatId') || '';
        var archived = params.get('archived') === 'true';
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId);
        return nativeFetch(NEW_API_BASE + path, {
            method: 'PATCH', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({ archived: archived })
        }).then(function(r) { return r.json().then(function(data) {
            if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
            return _fakeJsonResponse(data, 200);
        }); });
    },
    // Аналог action=deleteClient — НЕ настоящее удаление (как и в
    // оригинале): бэкенд помечает клиента статусом 'deleted', данные
    // (программа/питание/замеры) остаются в базе целыми, клиент просто
    // пропадает из getClients и получает 404 при любом обращении — тот же
    // эффект, что и был ("клиент потерял доступ к боту"), без потери
    // истории. См. docstring delete_client в api/main.py.
    deleteClient: function(nativeFetch, params) {
        var chatId = params.get('targetChatId') || params.get('clientChatId') || '';
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId);
        return nativeFetch(NEW_API_BASE + path, { method: 'DELETE', headers: _newApiHeaders() })
            .then(function(r) { return r.json().then(function(data) {
                if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
                return _fakeJsonResponse({ success: true }, 200);
            }); });
    },
    // Фото замера (photoBase64) новый API пока не умеет хранить (нет файлового
    // хранилища на бэкенде, см. DB_SCHEMA.md) — честно НЕ перехватываем такой
    // вызов (возвращаем null), он уйдёт по старому пути и фото не потеряется.
    // Без фото — сохраняем как обычно.
    saveMeasurements: function(nativeFetch, params, init) {
        var chatId = params.get('chatId') || '';
        var body;
        try { body = JSON.parse((init && init.body) || '{}'); } catch (_) { body = {}; }
        if (body.photoBase64) return null; // фолбэк на старый бэкенд, см. коммент выше
        var payload = {};
        ['weight', 'shoulders', 'chest', 'waist', 'hips', 'bicep', 'thigh'].forEach(function(k) {
            if (body[k] !== undefined && body[k] !== '') payload[k] = parseFloat(body[k]);
        });
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/measurements';
        return nativeFetch(NEW_API_BASE + path, {
            method: 'POST', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify(payload)
        }).then(function(r) { return r.json().then(function(data) {
            if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
            return _fakeJsonResponse({ success: true }, 200);
        }); });
    },
    // client_name в теле запроса (не chatId!) — та же причина, что и у
    // заметок/истории, резолвим тем же кэшем.
    saveMealPlan: function(nativeFetch, params, init) {
        var body;
        try { body = JSON.parse((init && init.body) || '{}'); } catch (_) { body = {}; }
        var clientName = body.client_name || '';
        var plan = body.plan || {};
        return _resolveChatIdByName(nativeFetch, clientName).then(function(chatId) {
            if (!chatId) return _fakeJsonResponse({ success: false, error: 'Клиент не найден: ' + clientName }, 200);
            var payload = {
                target_calories: plan.target_calories || 0, target_protein: plan.target_protein || 0,
                target_fats: plan.target_fats || 0, target_carbs: plan.target_carbs || 0,
                meals: plan.meals || [], notes: plan.notes || '',
                dayType: plan.dayType || 'workout'
            };
            var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/meal-plan';
            return nativeFetch(NEW_API_BASE + path, {
                method: 'POST', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
                body: JSON.stringify(payload)
            }).then(function(r) { return r.json().then(function(data) {
                if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
                return _fakeJsonResponse({ success: true }, 200);
            }); });
        });
    },
    // Форма ответа отличается от старой (у нас lastPayment — вложенный объект,
    // раньше были плоские amount/endDate) — реформатируем под то, что ждут
    // renderFinanceSummary/renderFinanceList.
    // Календарь оплат — платежи и окончания абонементов за месяц (см.
    // payments_calendar в api/main.py). Отдельно от getFinances: та отдаёт
    // только последний платёж клиента, а календарю нужны все за период.
    getPaymentsCalendar: function(nativeFetch, params) {
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/payments-calendar' +
            '?start=' + encodeURIComponent(params.get('start') || '') +
            '&end=' + encodeURIComponent(params.get('end') || '');
        return _newApiCall(nativeFetch, path).then(function(res) {
            if (!res.ok) return _fakeJsonResponse({ payments: [], error: (res.data && res.data.detail) || 'Ошибка' }, 200);
            return _fakeJsonResponse(res.data, 200);
        });
    },
    getFinances: function(nativeFetch) {
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/finances';
        return _newApiCall(nativeFetch, path).then(function(res) {
            if (!res.ok) return _fakeJsonResponse({ error: (res.data && res.data.detail) || 'Ошибка' }, 200);
            var clients = (res.data.clients || []).map(function(c) {
                var p = c.lastPayment || {};
                return { chatId: c.chatId, name: c.name, status: c.status, daysLeft: c.daysLeft, endDate: _isoDateToRu(p.endDate), amount: p.amount };
            });
            return _fakeJsonResponse({ clients: clients }, 200);
        });
    },
    // savePaymentDirect в apps_script.js — тонкая обёртка над той же
    // savePayment(), на которую уже равнялся POST .../payments при разработке
    // бэкенда — семантика (продление от конца активного периода) совпадает.
    savePaymentDirect: function(nativeFetch, params) {
        var chatId = params.get('clientChatId') || params.get('chatId') || '';
        var payload = {
            amount: parseFloat(params.get('amount') || '0'), months: parseInt(params.get('months') || '1', 10),
            comment: params.get('comment') || '',
            date: params.get('date') || ''
        };
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/payments';
        return nativeFetch(NEW_API_BASE + path, {
            method: 'POST', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify(payload)
        }).then(function(r) { return r.json().then(function(data) {
            if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
            return _fakeJsonResponse({
                success: true, clientName: params.get('clientName') || '', amount: data.amount,
                months: data.months, endDate: _isoDateToRu(data.endDate), paymentDate: _isoDateToRu(data.date)
            }, 200);
        }); });
    },
    adjustSubscriptionEnd: function(nativeFetch, params) {
        var chatId = params.get('clientChatId') || params.get('chatId') || '';
        var payload = { days: parseInt(params.get('days') || '0', 10), comment: params.get('comment') || '' };
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/payments/adjust';
        return nativeFetch(NEW_API_BASE + path, {
            method: 'POST', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify(payload)
        }).then(function(r) { return r.json().then(function(data) {
            if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
            return _fakeJsonResponse({ success: true, newEndDate: _isoDateToRu(data.endDate) }, 200);
        }); });
    },
    // Программа тренировок — ключуется по sheetName (не chatId), но у нас
    // sheetName === name синтетически (см. getClients выше), так что
    // подходит тот же резолвер _resolveChatIdByName. rowIndex, который видит
    // фронтенд — это integer `id` из новой БД под старым именем поля (тот же
    // приём, что и с `ts` у заметок). Читаем И пишем вместе — если бы читали
    // из новой системы, а писали в старую (или наоборот), id/rowIndex
    // разъехались бы мгновенно.
    //
    // НЕ переносим тут: photo1/photo2/videoVk (фото/VK-видео техники — совпадение
    // по названию с библиотекой упражнений, у Романа она пуста, деградация
    // не критична), completed/timestamp (были всегда пустышками и в
    // apps_script.js), action=write (клиент сам завершает тренировку — там
    // ещё и опрос самочувствия/причина провала, которых на бэкенде пока нет,
    // а настоящих клиентов у Романа всё равно нет — не горит).
    readClientProgram: function(nativeFetch, params) {
        var sheetName = params.get('sheetName') || '';
        return _resolveChatIdByName(nativeFetch, sheetName).then(function(chatId) {
            if (!chatId) return _fakeJsonResponse({ error: 'Sheet not found: ' + sheetName }, 200);
            var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/program';
            return _newApiCall(nativeFetch, path).then(function(res) {
                if (!res.ok) return _fakeJsonResponse({ error: (res.data && res.data.detail) || 'Ошибка' }, 200);
                return _fakeJsonResponse({ weekTitle: res.data.weekTitle, days: _mapProgramDays(res.data.days) }, 200);
            });
        });
    },
    // Аналог action=read — КЛИЕНТ читает СВОЮ программу (chatId — его
    // собственный, из _myChatId(), не резолвер по имени, он и так свой
    // chatId знает). Тот же бэкенд-эндпоинт и то же преобразование дней,
    // что у readClientProgram (трenerской версии просмотра ЧУЖОЙ
    // программы) — вынесено в общий _mapProgramDays. Добавляем clientName
    // в ответ (в оригинале read кладёт его отдельно поверх readWorkoutData,
    // readClientProgram — нет, ей это поле не нужно).
    read: function(nativeFetch, params) {
        var chatId = params.get('chatId') || '';
        if (!chatId) return _fakeJsonResponse({ error: 'Missing chatId' }, 200);
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/program';
        return _newApiCall(nativeFetch, path).then(function(res) {
            if (!res.ok) {
                // init() в app.js регексом ищет в тексте ошибки именно
                // английское "Client not found" (см. getClientSheet в
                // apps_script.js) — по нему решает, показать тренеру
                // админку или клиенту экран запроса доступа в VK. Бэкенд
                // отдаёт русский текст в detail — на 404 подменяем на
                // оригинальную формулировку, чтобы этот механизм не сломался.
                var msg = res.status === 404
                    ? 'Client not found for chatId: ' + chatId
                    : ((res.data && res.data.detail) || 'Ошибка');
                return _fakeJsonResponse({ error: msg }, 200);
            }
            return _fakeJsonResponse({
                weekTitle: res.data.weekTitle, days: _mapProgramDays(res.data.days),
                clientName: res.data.clientName || ''
            }, 200);
        });
    },
    // Аналог action=history — КЛИЕНТСКАЯ версия (chatId свой, не резолвер по
    // имени). НЕ путать с getClientHistory (тренерская, другой экшен, другая
    // форма ответа — группирует по дню с RPE-бейджами). Эта — плоский список
    // (дата, упражнение, вес) для графика прогресса и топ-5 рекордов на
    // клиентском экране. Бэкенд уже отдаёт ровно эту форму — реформатировать
    // нечего.
    history: function(nativeFetch, params) {
        var chatId = params.get('chatId') || '';
        if (!chatId) return _fakeJsonResponse({ error: 'Missing chatId' }, 200);
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/history-flat';
        return _newApiCall(nativeFetch, path).then(function(res) {
            if (!res.ok) {
                var msg = res.status === 404
                    ? 'Client not found for chatId: ' + chatId
                    : ((res.data && res.data.detail) || 'Ошибка');
                return _fakeJsonResponse({ error: msg }, 200);
            }
            return _fakeJsonResponse(res.data, 200);
        });
    },
    // Аналог action=notifyClient — тренер шлёт клиенту произвольное
    // сообщение (или дефолтное "программа обновлена") через Telegram/VK.
    // 2026-08-15: токены бота добавлены в новый сервис (то же решение, что
    // и у sendMonthlyReportToClient/requestAccess ниже), прямой chatId,
    // резолвер имени не нужен.
    notifyClient: function(nativeFetch, params) {
        var chatId = params.get('targetChatId') || params.get('clientChatId') || '';
        var message = params.get('message') || '';
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/notify';
        return nativeFetch(NEW_API_BASE + path, {
            method: 'POST', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({ message: message || null })
        }).then(function(r) { return r.json().then(function(data) {
            if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
            return _fakeJsonResponse({ success: true }, 200);
        }); });
    },
    // Аналог action=sendMonthlyReportToClient — clientName с фронта не
    // нужен, бэкенд сам знает имя клиента по chatId (строит тот же отчёт,
    // что уже показывает getMonthlyReportsPreview, и реально его шлёт).
    sendMonthlyReportToClient: function(nativeFetch, params) {
        var chatId = params.get('targetChatId') || params.get('clientChatId') || '';
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/monthly-report/send';
        return nativeFetch(NEW_API_BASE + path, { method: 'POST', headers: _newApiHeaders() })
            .then(function(r) { return r.json().then(function(data) {
                if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'нет данных для отчёта' }, 200);
                return _fakeJsonResponse({ success: true }, 200);
            }); });
    },
    // Аналог action=requestAccess — уведомление уходит ТРЕНЕРУ (не
    // клиенту), chatId в параметрах — это chatId ПРОСЯЩЕГО доступ (обычно
    // ещё не зарегистрированный клиент), не текущего тренера.
    requestAccess: function(nativeFetch, params) {
        var chatId = params.get('chatId') || '';
        var name = params.get('name') || '';
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/request-access';
        return nativeFetch(NEW_API_BASE + path, {
            method: 'POST', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({ chatId: chatId, name: name })
        }).then(function(r) { return r.json().then(function(data) {
            if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
            return _fakeJsonResponse({ success: true }, 200);
        }); });
    },
    updateClientExercise: function(nativeFetch, params) {
        var sheetName = params.get('sheetName') || '';
        var rowIndex = params.get('rowIndex') || ''; // на самом деле id, см. коммент выше
        return _resolveChatIdByName(nativeFetch, sheetName).then(function(chatId) {
            if (!chatId) return _fakeJsonResponse({ success: false, error: 'Sheet not found: ' + sheetName }, 200);
            var fields = {};
            ['exercise', 'sets', 'reps', 'weightPlan', 'rpe', 'note'].forEach(function(k) {
                if (params.has(k)) fields[k] = params.get(k);
            });
            var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) +
                '/program/exercises/' + encodeURIComponent(rowIndex);
            return nativeFetch(NEW_API_BASE + path, {
                method: 'PATCH', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
                body: JSON.stringify(fields)
            }).then(function(r) { return r.json().then(function(data) {
                if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
                return _fakeJsonResponse({ success: true }, 200);
            }); });
        });
    },
    deleteClientExercise: function(nativeFetch, params) {
        var sheetName = params.get('sheetName') || '';
        var rowIndex = params.get('rowIndex') || '';
        return _resolveChatIdByName(nativeFetch, sheetName).then(function(chatId) {
            if (!chatId) return _fakeJsonResponse({ success: false, error: 'Sheet not found: ' + sheetName }, 200);
            var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) +
                '/program/exercises/' + encodeURIComponent(rowIndex);
            return nativeFetch(NEW_API_BASE + path, { method: 'DELETE', headers: _newApiHeaders() })
                .then(function(r) {
                    if (r.status === 204 || r.ok) return _fakeJsonResponse({ success: true }, 200);
                    // 2026-08-31 (L-2). 404 здесь — не поломка, а «удалять
                    // уже нечего»: чаще всего это второе нажатие по той же
                    // кнопке или открытая в двух местах программа. Раньше
                    // человек видел то же красное «Ошибка», что и при
                    // настоящем сбое, и не понимал, прошло удаление или нет.
                    if (r.status === 404) {
                        return _fakeJsonResponse({ success: true, alreadyGone: true }, 200);
                    }
                    return r.json().then(function(data) {
                        return _fakeJsonResponse({ success: false, error: (data && data.detail) || 'Не удалось' }, 200);
                    });
                });
        });
    },
    // Одно упражнение — кнопка «Сохранить» в редакторе (см. saveExerciseEdit,
    // режим 'add'). 2026-08-25: этой ручки в списке НЕ БЫЛО, хотя bulk-версия
    // (addClientExercises, ниже) была — из-за похожего имени пропажа не
    // бросалась в глаза. Запрос молча уходил в старый Apps Script: тот про
    // тренеров новой базы ничего не знает, а программа читается уже из
    // Postgres — упражнение не появлялось нигде, кнопка «сохраняла» в пустоту.
    // Найдено на Романе; ломалось у ВСЕХ тренеров, кто добавлял упражнения по
    // одному, а не мастером «новый день» (тот всегда шёл через bulk).
    addClientExercise: function(nativeFetch, params) {
        var sheetName = params.get('sheetName') || '';
        return _resolveChatIdByName(nativeFetch, sheetName).then(function(chatId) {
            if (!chatId) return _fakeJsonResponse({ success: false, error: 'Sheet not found: ' + sheetName }, 200);
            var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/program/exercises';
            return nativeFetch(NEW_API_BASE + path, {
                method: 'POST', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
                body: JSON.stringify({
                    day: params.get('dayName') || '',
                    exercise: params.get('exercise') || '',
                    sets: params.get('sets') || '',
                    reps: params.get('reps') || '',
                    weightPlan: params.get('weightPlan') || '',
                    rpe: params.get('rpe') || '',
                    note: params.get('note') || '',
                    video: params.get('video') || ''
                })
            }).then(function(r) { return r.json().then(function(data) {
                if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
                return _fakeJsonResponse({ success: true, rowIndex: data.id }, 200);
            }); });
        });
    },
    // Bulk (сет/трисет/несколько упражнений разом) — новый API умеет только
    // по одному, поэтому шлём N последовательных POST вместо одного bulk-запроса.
    addClientExercises: function(nativeFetch, params, init) {
        var sheetName = params.get('sheetName') || '';
        var dayName = params.get('dayName') || '';
        var body;
        try { body = JSON.parse((init && init.body) || '{}'); } catch (_) { body = {}; }
        var exercises = body.exercises || [];
        return _resolveChatIdByName(nativeFetch, sheetName).then(function(chatId) {
            if (!chatId) return _fakeJsonResponse({ success: false, error: 'Sheet not found: ' + sheetName }, 200);
            var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/program/exercises';
            var chain = Promise.resolve();
            var savedCount = 0;
            var firstError = null;
            exercises.forEach(function(ex) {
                chain = chain.then(function() {
                    // 2026-08-31. Раньше здесь был голый nativeFetch без единого
                    // повтора — при том, что все остальные обращения к бэкенду
                    // ходят через _fetchNewApiWithRetry именно потому, что
                    // соединение до Timeweb рвётся само по себе примерно в 15%
                    // случаев (замеры в комментарии к _newApiCall). В блоке из
                    // четырнадцати упражнений это почти гарантированный обрыв.
                    //
                    // Хуже того: сорванный fetch (или r.json() на не-JSON
                    // ответе) выбрасывал исключение, и вся ЦЕПОЧКА обрывалась —
                    // оставшиеся упражнения даже не пытались сохраниться, а
                    // подсчёт «сохранено N из M» до вызывающего не доходил.
                    // Тренер видел ошибку связи, в программе оказывалась
                    // половина дня, а клиент — «малую часть тренировки».
                    //
                    // Теперь каждое упражнение идёт с повторами, и его провал
                    // не роняет остальные: цепочка доходит до конца всегда и
                    // всегда честно отчитывается, сколько прошло.
                    return _fetchNewApiWithRetry(nativeFetch, NEW_API_BASE + path, {
                        method: 'POST', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
                        body: JSON.stringify({
                            day: dayName, exercise: ex.exercise || '', sets: ex.sets || '', reps: ex.reps || '',
                            weightPlan: ex.weightPlan || '', rpe: ex.rpe || '', note: ex.note || ''
                        })
                    }, 3).then(function(r) {
                        if (r.ok) { savedCount++; return; }
                        return r.json().catch(function() { return {}; }).then(function(data) {
                            if (!firstError) firstError = data.detail || ('Ошибка ' + r.status);
                        });
                    }).catch(function(err) {
                        if (!firstError) firstError = (err && err.message) || 'Обрыв связи';
                    });
                });
            });
            return chain.then(function() {
                if (firstError && savedCount === 0) return _fakeJsonResponse({ success: false, error: firstError }, 200);
                // Частичный провал раньше отдавался как успех: из четырнадцати
                // упражнений сохранялось восемь, тренер видел «готово», а в
                // программе оказывалась половина дня. Теперь говорим прямо,
                // сколько прошло — остальное тренер досоздаёт, а не ищет
                // пропажу глазами.
                if (firstError) {
                    return _fakeJsonResponse({
                        success: false,
                        error: 'Сохранено ' + savedCount + ' из ' + exercises.length +
                               ' — остальные не прошли: ' + firstError
                    }, 200);
                }
                return _fakeJsonResponse({ success: true, saved: savedCount }, 200);
            });
        });
    },
    // Управление днями/неделями. 2026-08-18: РАНЬШЕ addClientDay (добавить
    // ПУСТОЙ день, без единого упражнения) сюда намеренно НЕ включался — в
    // новой модели день не отдельная сущность, а просто day_name на
    // упражнениях, пустого дня без упражнений не существует, комментарий
    // предполагал "уйдёт в старый Apps Script, ничего страшного". На
    // практике оказалось страшно: у Романа (реальный пилот на Timeweb)
    // форма "Новый день тренировки" зависала на "Добавление..." (старый
    // Apps Script медленный/нестабильный — та же причина, по которой вообще
    // переезжали), а даже при успехе день создавался бы в СТАРОЙ таблице,
    // а следующее чтение программы идёт из НОВОЙ базы — день физически не
    // появился бы там, где его ждут. Раз день — не сущность в новой схеме
    // вообще, правильный фикс — не звать никакой бэкенд тут, просто честно
    // отвечать "успех" сразу же. Реальный день появится сам при первом
    // addClientExercises в него (см. ниже) — форма-мастер и так работает в
    // два шага (сначала это, потом добавление упражнений), так что фронту
    // ничего не нужно от этого ответа кроме success:true.
    addClientDay: function() {
        return _fakeJsonResponse({ success: true }, 200);
    },
    renameClientDay: function(nativeFetch, params) {
        var sheetName = params.get('sheetName') || '';
        var oldDayName = params.get('oldDayName') || '';
        var newDayName = params.get('newDayName') || '';
        return _resolveChatIdByName(nativeFetch, sheetName).then(function(chatId) {
            if (!chatId) return _fakeJsonResponse({ success: false, error: 'Sheet not found: ' + sheetName }, 200);
            var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) +
                '/program/days/' + encodeURIComponent(oldDayName);
            return nativeFetch(NEW_API_BASE + path, {
                method: 'PATCH', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
                body: JSON.stringify({ newName: newDayName })
            }).then(function(r) { return r.json().then(function(data) {
                if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
                return _fakeJsonResponse({ success: true }, 200);
            }); });
        });
    },
    deleteClientDay: function(nativeFetch, params) {
        var sheetName = params.get('sheetName') || '';
        var dayName = params.get('dayName') || '';
        return _resolveChatIdByName(nativeFetch, sheetName).then(function(chatId) {
            if (!chatId) return _fakeJsonResponse({ success: false, error: 'Sheet not found: ' + sheetName }, 200);
            var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) +
                '/program/days/' + encodeURIComponent(dayName);
            return nativeFetch(NEW_API_BASE + path, { method: 'DELETE', headers: _newApiHeaders() })
                .then(function(r) { return r.json().then(function(data) {
                    if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
                    return _fakeJsonResponse({ success: true }, 200);
                }); });
        });
    },
    // Старый API даёт только плоский список rowIndex без явного dayName —
    // все переставляемые строки уже гарантированно из одного дня (визуально
    // тащат только внутри одной секции), так что находим день по первому id.
    reorderDayExercises: function(nativeFetch, params) {
        var sheetName = params.get('sheetName') || '';
        var order = (params.get('order') || '').split(',').map(function(s) { return parseInt(s.trim(), 10); }).filter(function(n) { return !isNaN(n); });
        if (order.length === 0) return _fakeJsonResponse({ success: false, error: 'Empty order' }, 200);
        return _resolveChatIdByName(nativeFetch, sheetName).then(function(chatId) {
            if (!chatId) return _fakeJsonResponse({ success: false, error: 'Sheet not found: ' + sheetName }, 200);
            var progPath = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/program';
            return _newApiCall(nativeFetch, progPath).then(function(res) {
                if (!res.ok) return _fakeJsonResponse({ success: false, error: (res.data && res.data.detail) || 'Ошибка' }, 200);
                var dayName = null;
                (res.data.days || []).forEach(function(day) {
                    if (day.exercises.some(function(ex) { return ex.id === order[0]; })) dayName = day.day;
                });
                if (!dayName) return _fakeJsonResponse({ success: false, error: 'День не найден' }, 200);
                var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) +
                    '/program/days/' + encodeURIComponent(dayName) + '/reorder';
                return nativeFetch(NEW_API_BASE + path, {
                    method: 'PUT', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
                    body: JSON.stringify({ orderedIds: order })
                }).then(function(r) { return r.json().then(function(data) {
                    if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
                    return _fakeJsonResponse({ success: true }, 200);
                }); });
            });
        });
    },
    // БЕЗ autoProgress (авто-подбор весов по фактам прошлой недели) — новый
    // бэкенд его не умеет, параметр тихо игнорируется (неделя дублируется
    // как есть, план копируется, факты чистые — то же самое, что autoProgress
    // выключенный вручную).
    duplicateClientWeek: function(nativeFetch, params) {
        var sheetName = params.get('sheetName') || '';
        return _resolveChatIdByName(nativeFetch, sheetName).then(function(chatId) {
            if (!chatId) return _fakeJsonResponse({ success: false, error: 'Sheet not found: ' + sheetName }, 200);
            var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/program/duplicate-week';
            return nativeFetch(NEW_API_BASE + path, { method: 'POST', headers: _newApiHeaders() })
                .then(function(r) { return r.json().then(function(data) {
                    if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
                    return _fakeJsonResponse({ success: true, newTitle: data.weekTitle }, 200);
                }); });
        });
    },
    // Дашборд питания (вкладка "Админка" тренера) — сводка по ВСЕМ клиентам
    // тренера разом, не по одному. Форма ответа у нового API 1-в-1 совпадает
    // со старой ({stats, alerts, clients}) — реформатировать нечего. В
    // отличие от остального пилота, не завязан на конкретного клиента/
    // sheetName, поэтому резолвер имени не нужен.
    getFoodDashboard: function(nativeFetch) {
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/food-dashboard';
        return _newApiCall(nativeFetch, path).then(function(res) {
            if (!res.ok) return _fakeJsonResponse({ error: (res.data && res.data.detail) || 'Ошибка' }, 200);
            return _fakeJsonResponse(res.data, 200);
        });
    },
    // Превью месячных отчётов — тоже сводка по всем клиентам разом, форма
    // ответа ({reports:[...]}) 1-в-1 совпадает со старой. Саму отправку
    // (sendMonthlyReportToClient) пилот не покрывает — уходит в старый
    // Apps Script как раньше (нужна интеграция с ботами, см. MIGRATION_PLAN.md).
    getMonthlyReportsPreview: function(nativeFetch) {
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/monthly-reports-preview';
        return _newApiCall(nativeFetch, path).then(function(res) {
            if (!res.ok) return _fakeJsonResponse({ error: (res.data && res.data.detail) || 'Ошибка' }, 200);
            return _fakeJsonResponse(res.data, 200);
        });
    },
    // Аналог action=generateMealPlanAI — ИИ-генерация плана питания на день
    // (не сохраняет сама, фронт открывает редактор с результатом на правку).
    // Единственный ИИ-экшен мини-аппа в пилоте — остальной ИИ-анализ еды
    // клиента (фото/голос/текст) идёт через ботов напрямую, не через
    // fitness-app, поэтому вне периметра этого шима. Квота отдельная от
    // клиентского анализа еды (15/день на ТРЕНЕРА, не 5/день на клиента —
    // см. docstring generate_meal_plan_ai в api/main.py); ключ по clientName
    // (не chatId, как в теле POST у оригинала), поэтому нужен резолвер.
    generateMealPlanAI: function(nativeFetch, params, init) {
        var body;
        try { body = JSON.parse((init && init.body) || '{}'); } catch (_) { body = {}; }
        var clientName = body.clientName || '';
        return _resolveChatIdByName(nativeFetch, clientName).then(function(chatId) {
            if (!chatId) return _fakeJsonResponse({ success: false, error: 'Клиент не найден: ' + clientName }, 200);
            var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/meal-plan/generate';
            return nativeFetch(NEW_API_BASE + path, {
                method: 'POST', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
                body: JSON.stringify({
                    weight: body.weight || '', height: body.height || '', age: body.age || '',
                    goal: body.goal || '', allergies: body.allergies || ''
                })
            }).then(function(r) { return r.json().then(function(data) {
                // food_ai.generate_meal_plan уже отдаёт {success:false, error}
                // при провале ИИ (HTTP 200) — просто пробрасываем как есть.
                // Только не-2xx (429 квота, 404 клиент не найден) реформатируем.
                if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
                return _fakeJsonResponse(data, 200);
            }); });
        });
    },
    // Аналог action=getAdminClients — главный экран "Тренерской", список
    // клиентов с цветными статусами по активности (не путать с getClients
    // — та отдаёт только chatId/name/archived для простых списков типа
    // резолвера имени). Форма ответа 1-в-1 совпадает со старой.
    getAdminClients: function(nativeFetch) {
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/admin-clients';
        return _newApiCall(nativeFetch, path).then(function(res) {
            if (!res.ok) return _fakeJsonResponse({ error: (res.data && res.data.detail) || 'Ошибка' }, 200);
            return _fakeJsonResponse(res.data, 200);
        });
    },
    // Аналог action=saveExerciseMedia — фото/видео техники упражнения.
    // Поля тела запроса (name/group/video/videoVk/photo1Base64/photo1Mime/
    // photo2Base64/photo2Mime/removePhoto1/removePhoto2) уже совпадают с
    // новым бэкендом 1-в-1 (см. saveExerciseMediaEntry) — реформатировать
    // нечего, только вынести name в путь URL. В отличие от saveMeasurements
    // с фото, тут файловое хранилище на новом бэкенде УЖЕ есть (Railway
    // volume, см. MIGRATION_PLAN.md), поэтому честно перехватываем, а не
    // отдаём null.
    saveExerciseMedia: function(nativeFetch, params, init) {
        var body;
        try { body = JSON.parse((init && init.body) || '{}'); } catch (_) { body = {}; }
        var name = (body.name || '').trim();
        if (!name) return _fakeJsonResponse({ success: false, error: 'Не указано название упражнения' }, 200);
        var payload = {
            photo1Base64: body.photo1Base64 || null, photo1Mime: body.photo1Mime || 'image/jpeg',
            photo2Base64: body.photo2Base64 || null, photo2Mime: body.photo2Mime || 'image/jpeg',
            removePhoto1: !!body.removePhoto1, removePhoto2: !!body.removePhoto2,
            video: body.video, videoVk: body.videoVk, group: body.group
        };
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/exercises/' + encodeURIComponent(name) + '/media';
        return nativeFetch(NEW_API_BASE + path, {
            method: 'POST', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify(payload)
        }).then(function(r) { return r.json().then(function(data) {
            if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось сохранить' }, 200);
            return _fakeJsonResponse(data, 200);
        }); });
    },
    // Аналог action=write/writeWorkoutData — клиент завершает тренировочный
    // день (кнопка «Сохранить» в тренировке). ВАЖНО: этот экшен идёт через
    // GET (см. save-btn обработчик — exercises кладутся в query string, не в
    // тело POST), поэтому читаем всё из params, не из init.body, как в
    // остальных write-шимах.
    //
    // Раньше в MIGRATION_PLAN.md этот экшен считался непереносимым — якобы
    // нужен опрос самочувствия (wn/fr2/fb/fr), которого нет на новом
    // бэкенде. Перепроверил апстрим (apps_script.js) — эти поля там тоже
    // нигде не сохраняются, чисто фронтендовая штука (корректирует
    // отображаемый план по самочувствию). Сохраняется только
    // rowIndex/weightFact/repsFact/comment — это уже умеет
    // POST .../program/complete-day.
    write: function(nativeFetch, params) {
        var chatId = params.get('chatId') || '';
        var raw = [];
        try { raw = JSON.parse(params.get('exercises') || '[]'); } catch (_) { raw = []; }
        var exercises = raw.map(function(ex) {
            return {
                exerciseId: parseInt(ex.r !== undefined ? ex.r : ex.rowIndex, 10),
                weightFact: (ex.w !== undefined ? ex.w : ex.weightFact) || '',
                repsFact: (ex.p !== undefined ? ex.p : ex.repsFact) || '',
                comment: (ex.c !== undefined ? ex.c : ex.comment) || ''
            };
        }).filter(function(e) { return !isNaN(e.exerciseId); });
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/program/complete-day';
        return nativeFetch(NEW_API_BASE + path, {
            method: 'POST', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({ exercises: exercises })
        }).then(function(r) { return r.json().then(function(data) {
            if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось сохранить' }, 200);
            return _fakeJsonResponse({ success: true, saved: data.saved, timestamp: data.timestamp }, 200);
        }); });
    },
    // Аналог action=progress/getProgressStats — 3 плитки на клиентском
    // экране "Прогресс". Раньше числился заблокированным (нужен лист
    // "Архив", которого нет в новой БД) — при перепроверке оказалось, что
    // архив и не нужен: новый бэкенд считает по всем прошлым неделям
    // клиента на лету (они не перезатираются при переходе на новую неделю,
    // в отличие от старой системы). Форма ответа 1-в-1 совпадает со старой.
    progress: function(nativeFetch, params) {
        var chatId = params.get('chatId') || '';
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/clients/' + encodeURIComponent(chatId) + '/progress';
        return _newApiCall(nativeFetch, path).then(function(res) {
            if (!res.ok) return _fakeJsonResponse({ error: (res.data && res.data.detail) || 'Ошибка' }, 200);
            return _fakeJsonResponse(res.data, 200);
        });
    },
    // Аналог action=getTenantConfig — тема оформления, дёргается один раз
    // при старте мини-аппа. Не chatId-резолвинг (fallback на случай пустого
    // trainerId в ссылке) — тот путь и не задет этим шимом вообще, он
    // работает по CURRENT_TRAINER_ID, как и весь остальной пилот.
    // На 403 с blocked:true (доступ отключён/демо истекло) бэкенд отдаёт
    // detail ОБЪЕКТОМ {error, blocked}, не строкой, как везде — прокидываем
    // как есть, фронту (loadTenantConfig) нужен именно плоский blocked:true.
    getTenantConfig: function(nativeFetch) {
        var path = '/trainers/' + encodeURIComponent(_newApiTrainerId()) + '/tenant-config';
        return _newApiCall(nativeFetch, path).then(function(res) {
            if (!res.ok) {
                var d = res.data && res.data.detail;
                if (d && typeof d === 'object') return _fakeJsonResponse(d, 200);
                return _fakeJsonResponse({ error: d || 'Ошибка' }, 200);
            }
            return _fakeJsonResponse(res.data, 200);
        });
    },

    // ── Супер-админка (только Matvey), 2026-08-19 ───────────────────────────
    // В отличие от всего остального в NEW_API_ACTIONS — эти 5 НЕ про "текущий
    // тенант" (_newApiTrainerId()), а про ВСЮ площадку разом, поэтому идут
    // не на /trainers/{tenantId}/..., а на /admin/trainers[...]. Бэкенд для
    // них был готов ещё с Фазы 3 (main.py, группа 5) — не хватало только
    // этого шима. Разрешено ОДНОМУ chatId — Matvey (asChatId, проверяется
    // на бэкенде через _require_super_admin, тот же принцип, что раньше был
    // у _isSuperAdmin в apps_script.js). createDemoTrainer СОЗНАТЕЛЬНО не
    // тронут — в оригинале это копирование шаблонной Google Таблицы с демо-
    // данными, для новой архитектуры без таблиц нужно отдельное решение
    // (см. MIGRATION_PLAN.md) — тот один экшен и дальше уходит в Apps Script
    // как раньше, ничего не сломано.
    getTrainersOverview: function(nativeFetch) {
        var path = '/admin/trainers?asChatId=' + encodeURIComponent(_myChatId());
        return _newApiCall(nativeFetch, path).then(function(res) {
            if (!res.ok) return _fakeJsonResponse({ error: (res.data && res.data.detail) || 'Ошибка' }, 200);
            return _fakeJsonResponse({ trainers: res.data.trainers || [] }, 200);
        });
    },
    // Старый getTrainerPayments отдавал ОДНУ сводную запись НА ТРЕНЕРА (статус
    // подписки на площадку + сколько дней осталось) — новый бэкенд же (Фаза 3)
    // отдаёт полную ИСТОРИЮ платежей ОДНОГО тренера, форма другая. Собираем
    // сводку на лету: список тренеров → для каждого история → берём запись
    // с самым поздним endDate → считаем daysLeft/status 1-в-1 как раньше
    // делал apps_script.js. Трейдофф: N+1 запросов вместо одного, но
    // тренеров пока единицы, а вызывается только при открытии вкладки
    // "Тренеры" супер-админкой, не на каждую загрузку мини-аппа.
    getTrainerPayments: function(nativeFetch) {
        var asChatId = encodeURIComponent(_myChatId());
        return _newApiCall(nativeFetch, '/admin/trainers?asChatId=' + asChatId).then(function(listRes) {
            if (!listRes.ok) return _fakeJsonResponse({ error: (listRes.data && listRes.data.detail) || 'Ошибка' }, 200);
            var trainerIds = (listRes.data.trainers || []).map(function(t) { return t.trainerId; });
            return Promise.all(trainerIds.map(function(tid) {
                var payPath = '/admin/trainers/' + encodeURIComponent(tid) + '/payments?asChatId=' + asChatId;
                return _newApiCall(nativeFetch, payPath).then(function(payRes) {
                    if (!payRes.ok) return null;
                    var latest = null;
                    (payRes.data.payments || []).forEach(function(p) {
                        if (p.endDate && (!latest || p.endDate > latest.endDate)) latest = p;
                    });
                    if (!latest) return null;
                    var daysLeft = Math.ceil((new Date(latest.endDate) - new Date()) / 86400000);
                    var status = daysLeft < 0 ? 'expired' : daysLeft <= 3 ? 'expiring_soon' : daysLeft <= 7 ? 'expiring_week' : 'active';
                    return {
                        trainerId: tid, lastPayment: _isoDateToRu(latest.date), amount: latest.amount,
                        endDate: _isoDateToRu(latest.endDate), daysLeft: daysLeft, status: status
                    };
                });
            })).then(function(results) {
                return _fakeJsonResponse({ payments: results.filter(Boolean) }, 200);
            });
        });
    },
    saveTrainerPayment: function(nativeFetch, params) {
        var asChatId = encodeURIComponent(_myChatId());
        var targetTrainerId = params.get('targetTrainerId') || '';
        var path = '/admin/trainers/' + encodeURIComponent(targetTrainerId) + '/payments?asChatId=' + asChatId;
        return nativeFetch(NEW_API_BASE + path, {
            method: 'POST', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({
                amount: parseFloat(params.get('amount')) || 0,
                months: parseInt(params.get('months'), 10) || 1,
                comment: params.get('comment') || ''
            })
        }).then(function(r) { return r.json().then(function(data) {
            if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
            return _fakeJsonResponse({
                success: true, trainerId: targetTrainerId, amount: data.amount,
                months: data.months, endDate: _isoDateToRu(data.endDate)
            }, 200);
        }); });
    },
    setTrainerLogo: function(nativeFetch, params, init) {
        var body = {};
        try { body = JSON.parse((init && init.body) || '{}'); } catch (_) { body = {}; }
        var path = '/admin/trainers/' + encodeURIComponent(params.get('targetTrainerId') || '') +
            '/logo?asChatId=' + encodeURIComponent(_myChatId());
        return nativeFetch(NEW_API_BASE + path, {
            method: 'PATCH', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify(body)
        }).then(function(r) { return r.json().then(function(data) {
            if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
            return _fakeJsonResponse(data, 200);
        }); });
    },
    setTrainerAvatar: function(nativeFetch, params, init) {
        var body = {};
        try { body = JSON.parse((init && init.body) || '{}'); } catch (_) { body = {}; }
        var path = '/admin/trainers/' + encodeURIComponent(params.get('targetTrainerId') || '') +
            '/avatar?asChatId=' + encodeURIComponent(_myChatId());
        return nativeFetch(NEW_API_BASE + path, {
            method: 'PATCH', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify(body)
        }).then(function(r) { return r.json().then(function(data) {
            if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
            return _fakeJsonResponse(data, 200);
        }); });
    },
    setTrainerTheme: function(nativeFetch, params) {
        var asChatId = encodeURIComponent(_myChatId());
        var path = '/admin/trainers/' + encodeURIComponent(params.get('targetTrainerId') || '') +
            '/theme?asChatId=' + asChatId;
        return nativeFetch(NEW_API_BASE + path, {
            method: 'PATCH', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({
                themeMode: params.get('themeMode') || '',
                themePrimary: params.get('themePrimary') || ''
            })
        }).then(function(r) { return r.json().then(function(data) {
            if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
            return _fakeJsonResponse(data, 200);
        }); });
    },
    setTrainerStatus: function(nativeFetch, params) {
        var asChatId = encodeURIComponent(_myChatId());
        var targetTrainerId = params.get('targetTrainerId') || '';
        var path = '/admin/trainers/' + encodeURIComponent(targetTrainerId) + '/status?asChatId=' + asChatId;
        return nativeFetch(NEW_API_BASE + path, {
            method: 'PATCH', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({ status: params.get('status') || '' })
        }).then(function(r) { return r.json().then(function(data) {
            if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
            return _fakeJsonResponse({ success: true }, 200);
        }); });
    },
    // Только "боевой" путь (status=active из submitNewTrainer) — createDemoTrainer
    // не перехвачен (см. комментарий выше блока), уходит в Apps Script как есть.
    // vkToken create_trainer на бэкенде не принимает (см. её докстринг в
    // main.py) — отдельным точечным PATCH сразу следом; если он вдруг не
    // удастся, тренер всё равно уже создан и виден в списке, токен можно
    // будет доставить позже через ту же форму (create_trainer — upsert).
    // 2026-08-23. Демо было ПОСЛЕДНИМ действием, уходившим в Apps Script —
    // и из-за этого создавало тренера, которого новый бэкенд не знает: в
    // мини-аппе он открывался с «Тренер не найден». Причём форма открывается
    // именно на демо, так что напороться было проще простого (и напоролись).
    // Теперь демо — обычный тренер со статусом demo и сроком жизни; своей
    // VK-группы у него нет, поэтому идентификатор придумываем сами, как это
    // делал старый код.
    createDemoTrainer: function(nativeFetch, params) {
        var asChatId = encodeURIComponent(_myChatId());
        var rnd = Math.random().toString(16).slice(2, 10);
        var trainerId = 'demo_' + rnd;
        var body = {
            trainerId: trainerId, displayName: params.get('displayName') || 'Демо',
            vkGroupId: '', status: 'demo',
            trainerChatId: params.get('trainerChatId') || '',
            demoHours: parseInt(params.get('demoHours') || '48', 10)
        };
        return nativeFetch(NEW_API_BASE + '/admin/trainers?asChatId=' + asChatId, {
            method: 'POST', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify(body)
        }).then(function(r) { return r.json().then(function(data) {
            if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
            return _fakeJsonResponse({ success: true, trainerId: trainerId }, 200);
        }); });
    },
    createTrainer: function(nativeFetch, params) {
        var asChatId = encodeURIComponent(_myChatId());
        var vkGroupId = params.get('vkGroupId') || '';
        var vkToken = params.get('vkToken') || '';
        var body = {
            trainerId: vkGroupId, displayName: params.get('displayName') || '',
            vkGroupId: vkGroupId, status: params.get('status') || 'active',
            themePrimary: params.get('themePrimary') || '', trainerChatId: params.get('trainerChatId') || ''
        };
        return nativeFetch(NEW_API_BASE + '/admin/trainers?asChatId=' + asChatId, {
            method: 'POST', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify(body)
        }).then(function(r) { return r.json().then(function(data) {
            if (!r.ok) return _fakeJsonResponse({ success: false, error: data.detail || 'Не удалось' }, 200);
            var finish = function() { return _fakeJsonResponse({ success: true, trainerId: vkGroupId }, 200); };
            if (!vkToken) return finish();
            var connPath = '/admin/trainers/' + encodeURIComponent(vkGroupId) + '/vk-connection?asChatId=' + asChatId;
            return nativeFetch(NEW_API_BASE + connPath, {
                method: 'PATCH', headers: _newApiHeaders({ 'Content-Type': 'application/json' }),
                body: JSON.stringify({ vkGroupId: vkGroupId, vkToken: vkToken })
            }).then(finish, finish);
        }); });
    }
};
NEW_API_ACTIONS.getExerciseMediaLibrary = NEW_API_ACTIONS.getExerciseLibrary;
var _PROFILE_KEYS = ['gender', 'age', 'height', 'weight', 'goal', 'level', 'frequency', 'limitations', 'inventory'];

(function() {
    var nativeFetch = window.fetch.bind(window);
    window.fetch = function(input, init) {
        var isAppsScript = typeof input === 'string' && input.indexOf(APPS_SCRIPT_URL) === 0;
        if (CURRENT_TRAINER_ID && isAppsScript) {
            // ВАЖНО: тут именно CURRENT_TRAINER_ID, не _newApiTrainerId() — это
            // трейлинг к запросу в СТАРЫЙ Apps Script, где для Matvey (тенант по
            // умолчанию) trainerId вообще не должен передаваться (см. комментарий
            // у _newApiTrainerId выше — иначе _resolveTenant('739299264') не
            // найдёт такую строку в реестре "Тренеры" и всё сломается).
            var sep = input.indexOf('?') === -1 ? '?' : '&';
            input = input + sep + 'trainerId=' + encodeURIComponent(CURRENT_TRAINER_ID);
        }
        if (isAppsScript) {
            if (_newApiTrainerId()) {
                var qIndex = input.indexOf('?');
                var params = new URLSearchParams(qIndex === -1 ? '' : input.slice(qIndex + 1));
                var handler = NEW_API_ACTIONS[params.get('action')];
                // handler может вернуть null (не Promise) — значит сам решил не
                // брать этот конкретный вызов (например saveMeasurements с фото:
                // загрузка в файловое хранилище на новом бэкенде пока не сделана,
                // честно не перехватываем, а не тихо теряем фото) — тогда падаем
                // в обычный старый путь ниже, как будто шима и не было.
                if (handler) {
                    var result = handler(nativeFetch, params, init);
                    // Promise.resolve(...), не result напрямую — большинство
                    // хендлеров возвращают Promise (через .then-цепочку), но
                    // некоторые (например read: при пустом chatId — реальный
                    // случай: голый браузер без Telegram/VK контекста, см.
                    // _myChatId()) делают ранний return _fakeJsonResponse(...)
                    // СИНХРОННО — это просто Response, не Promise, и
                    // _withTimeout(response, ...) падал с "promise.then is not
                    // a function" вместо аккуратной обработки ошибки. Нашли
                    // 2026-08-16 при тестировании фикса telegram-web-app.js
                    // (см. index.html) в обычном браузере без контекста.
                    if (result) return _withTimeout(Promise.resolve(result), _actionTimeout(params.get('action')));
                }
            }
            return _fetchWithRetry(nativeFetch, input, init, 2);
        }
        return nativeFetch(input, init);
    };
})();

// Затемняет hex-цвет на заданную долю (0..1) — чтобы из ОДНОГО присланного
// тренером акцентного цвета получить вторую точку градиента, не требуя от
// тренера подбирать пару цветов вручную.
// Разбор цвета и смешивание с белым — нужны, чтобы построить всю шкалу
// акцента из одного фирменного цвета тренера.
function _hexToRgb(hex) {
    var h = String(hex || '').replace('#', '');
    if (h.length === 3) h = h.split('').map(function(c) { return c + c; }).join('');
    if (!/^[0-9a-fA-F]{6}$/.test(h)) return null;
    var n = parseInt(h, 16);
    return { r: (n >> 16) & 0xFF, g: (n >> 8) & 0xFF, b: n & 0xFF };
}
function _rgbToHex(c) {
    return '#' + [c.r, c.g, c.b].map(function(v) {
        return Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0');
    }).join('');
}
// Смешать цвет с белым: 0 — исходный, 1 — белый.
function _mixWhite(hex, k) {
    var c = _hexToRgb(hex);
    if (!c) return hex;
    return _rgbToHex({ r: c.r + (255 - c.r) * k, g: c.g + (255 - c.g) * k, b: c.b + (255 - c.b) * k });
}
// Контраст двух цветов по WCAG (1 — неразличимы, 21 — чёрное на белом).
// Порог по «средней яркости» для этого не годится: петроль #16706B имеет
// яркость 0.36 и выглядит достаточно светлым по формуле, но на почти чёрном
// фоне даёт контраст всего 3.2.
function _relLum(hex) {
    var c = _hexToRgb(hex);
    if (!c) return 0;
    var v = [c.r, c.g, c.b].map(function(x) {
        x = x / 255;
        return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2];
}
function _contrast(a, b) {
    var l1 = _relLum(a), l2 = _relLum(b);
    return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
}

// Относительная яркость (0 — чёрный, 1 — белый).
function _luminance(hex) {
    var c = _hexToRgb(hex);
    if (!c) return 0.5;
    return (0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b) / 255;
}

// Строит шкалу акцента из фирменного цвета тренера и кладёт её в --accent-*.
// Без этого клиентские экраны всегда были бы петрольными, каким бы ни был
// цвет тренера: петроль задан в :root как значение по умолчанию, а тенантная
// тема ставила только --color-primary.
//
// Шкала строится ИЗ ОДНОГО И ТОГО ЖЕ цвета для обеих тем, меняется только
// способ: на светлом фоне цвет при необходимости затемняется и разбавляется
// белым, на тёмном — осветляется, а мягкие ступени становятся полупрозрачными
// (разбавленный белым цвет на чёрном фоне выглядел бы грязно-серым).
// Отдельного фиксированного акцента для тёмной темы больше нет.
//
// Пустой цвет = у тренера свой цвет не задан: снимаем все inline-значения,
// и в силу вступают значения по умолчанию из :root. Так цвет предыдущего
// тренера не остаётся при переключении в супер-админке.
var _ACCENT_PROPS = ['--accent-50', '--accent-100', '--accent-200', '--accent-300',
                     '--accent-500', '--accent-600', '--accent-700',
                     '--accent-rgb', '--text-on-accent'];

function _applyAccentScale(hex, isDark) {
    var root = document.documentElement;
    if (!_hexToRgb(hex)) {
        // Цвета у тренера нет — снимаем всё, и в силу вступают значения по
        // умолчанию из :root.
        _ACCENT_PROPS.forEach(function(p) { root.style.removeProperty(p); });
        if (!isDark) return;
        // Но значение по умолчанию рассчитано на светлый фон и на чёрном
        // читается плохо. Берём его же и прогоняем через ту же адаптацию,
        // что и цвет тренера. Фиксированный акцент в body.theme-dark для
        // этого заводить нельзя: объявление на body перебивает то, что JS
        // ставит на html, и ломает цвет тренера.
        hex = getComputedStyle(root).getPropertyValue('--accent-500').trim();
        if (!_hexToRgb(hex)) return;
    }
    var base = hex;
    if (isDark) {
        // На тёмном фоне подсвечиваем цвет, пока он не станет читаемым.
        // Ориентир — контраст к фону тёмной темы (--ds-page-bg = #0E0F11),
        // а не абстрактный порог яркости.
        for (var i = 0; i < 14 && _contrast(base, '#0E0F11') < 4.5; i++) {
            var next = _mixWhite(base, 0.14);
            if (next === base) break;
            base = next;
        }
        if (_luminance(base) > 0.72) base = _darkenHex(base, 0.18);
    } else {
        var lum = _luminance(base);
        if (lum > 0.55) base = _darkenHex(base, Math.min(0.45, (lum - 0.4) * 1.1));
        else if (lum < 0.12) base = _mixWhite(base, 0.28);
    }

    var c = _hexToRgb(base);
    var rgb = c.r + ', ' + c.g + ', ' + c.b;
    root.style.setProperty('--accent-rgb', rgb);
    root.style.setProperty('--accent-300', _mixWhite(base, 0.18));
    root.style.setProperty('--accent-500', base);
    root.style.setProperty('--accent-600', _darkenHex(base, isDark ? 0.18 : 0.20));

    if (isDark) {
        root.style.setProperty('--accent-50',  'rgba(' + rgb + ', .16)');
        root.style.setProperty('--accent-100', 'rgba(' + rgb + ', .24)');
        root.style.setProperty('--accent-200', 'rgba(' + rgb + ', .38)');
        // Акцентный текст на тёмном фоне обязан быть светлым, а не тёмным.
        root.style.setProperty('--accent-700', _mixWhite(base, 0.55));
    } else {
        root.style.setProperty('--accent-50',  _mixWhite(base, 0.93));
        root.style.setProperty('--accent-100', _mixWhite(base, 0.86));
        root.style.setProperty('--accent-200', _mixWhite(base, 0.66));
        root.style.setProperty('--accent-700', _darkenHex(base, 0.38));
    }

    // Текст поверх акцентной заливки: обычно белый, но если фирменный цвет
    // оказался очень светлым — тёмный, иначе надпись пропадёт.
    root.style.setProperty('--text-on-accent',
        _luminance(base) > 0.62 ? '#15171B' : '#FFFFFF');
}

function _darkenHex(hex, amount) {
    try {
        var h = hex.replace('#', '');
        if (h.length === 3) h = h.split('').map(function(c) { return c + c; }).join('');
        var num = parseInt(h, 16);
        var r = Math.max(0, Math.round(((num >> 16) & 0xFF) * (1 - amount)));
        var g = Math.max(0, Math.round(((num >> 8) & 0xFF) * (1 - amount)));
        var b = Math.max(0, Math.round((num & 0xFF) * (1 - amount)));
        return '#' + [r, g, b].map(function(v) { return v.toString(16).padStart(2, '0'); }).join('');
    } catch (_) { return hex; }
}

// Баннер тренера виден только на первой вкладке — см. обработчик
// переключения вкладок. Держим признак отдельно: сам факт «у тренера есть
// баннер» не меняется при переходах, меняется только показ.
var _tenantHasBanner = false;

function _activeTabName() {
    var active = document.querySelector('.tab-btn.active');
    return active ? active.dataset.tab : 'home';
}

function _syncTenantBanner(tabName) {
    var banner = document.getElementById('tenant-banner');
    if (!banner) return;
    banner.classList.toggle('hidden', !(_tenantHasBanner && tabName === 'home'));
}

function applyTenantTheme(theme) {
    if (!theme) return;
    // Цвет применяем ВСЕГДА, а не только когда он задан: иначе при
    // переключении между тренерами в супер-админке (без перезагрузки) на
    // экране оставался бы цвет предыдущего тренера.
    var root = document.documentElement;
    if (theme.primary) {
        root.style.setProperty('--color-primary', theme.primary);
        root.style.setProperty('--color-primary-dark', _darkenHex(theme.primary, 0.2));
    } else {
        root.style.removeProperty('--color-primary');
        root.style.removeProperty('--color-primary-dark');
    }
    // Клиентские экраны красятся через --accent-*, поэтому фирменный цвет
    // разворачиваем в полную шкалу. Тёмной теме нужен тот же цвет, но
    // адаптированный по яркости, — отдельного акцента у неё больше нет.
    _applyAccentScale(theme.primary || '', theme.mode === 'dark');
    // Тёмная тема тенанта целиком (не только акцент). Всё переключение —
    // один класс на body, дальше работают переменные в style.css.
    // Тем теперь три, поэтому не переключатель «тёмная да/нет», а выбор
    // одного класса из списка: иначе при смене темы у тренера на теле
    // остался бы висеть класс прошлой.
    ['theme-dark', 'theme-sand'].forEach(function(cls) {
        document.body.classList.toggle(cls, ('theme-' + theme.mode) === cls);
    });
    if (theme.displayName) {
        var titleEl = document.querySelector('title');
        if (titleEl) titleEl.textContent = theme.displayName;
    }
    // Фото тренера для кружка на главной. Приходит вместе с темой, поэтому
    // подхватывается и при обычном входе, и когда супер-админ смотрит
    // чужого тренанта.
    _tenantAvatarUrl = theme.avatar || '';
    _renderHomeAvatar();

    // Фирменный фон мини-аппа (лейбл/лого тренера) — тот же themeLogo, что
    // раньше приходил с бэкенда, но нигде не выводился. Опционально: без
    // него — как раньше, обычный светло-серый фон.
    // Баннер тренера. Раньше это был ФОН страницы: картинка висела по
    // центру сверху, а содержимое ехало прямо по ней — при широком лейбле
    // с лицом получалась каша. Теперь это обычная картинка в шапке: занимает
    // свою высоту, вкладки идут сразу под ней.
    var banner = document.getElementById('tenant-banner');
    if (banner) {
        var img = banner.querySelector('img');
        if (theme.logo) {
            img.src = String(theme.logo);
        } else {
            img.removeAttribute('src');
        }
        _tenantHasBanner = !!theme.logo;
        _syncTenantBanner(_activeTabName());
    }
    // Тёмный фон страницы под баннером оставляем и без картинки — он часть
    // тёмной темы, а не свойство баннера.
    document.body.classList.toggle('has-tenant-bg', !!theme.logo);
}

// ── Кто этот человек и к какому тренеру он относится (2026-08-20) ──────────
// Нужно ровно для одного случая: мини-апп открыт во VK, но в ссылке НЕТ
// vk_group_id (человек открыл его из «Сервисов»/списка приложений/закладки, а
// не ссылкой из сообщения бота — VK тогда не говорит, чьё это сообщество).
//
// Раньше в этом случае тенанта искал СТАРЫЙ Apps Script по своим Google
// Таблицам (_resolveTrainerIdByChatId). После переезда на Postgres клиентов
// туда больше никто не пишет — и человек, добавленный уже на новом бэкенде,
// не находился НИГДЕ: мини-апп молча падал в тенант по умолчанию (Matvey),
// читал его старую таблицу и показывал «Доступа пока нет», хотя доступ есть.
// Ровно так выглядела жалоба Аси 2026-08-20.
//
// Спрашиваем новый бэкенд напрямую. Отдельно разбираем случай, когда человек
// числится у НЕСКОЛЬКИХ тренеров сразу (у Аси так и есть — она и у Matvey, и
// у Романа): угадывать за него нельзя, показываем выбор и запоминаем.
var TENANT_CHOICE_KEY = 'fitnessapp:chosenTrainerId';

// С теми же 3 повторами, что и остальные запросы к новому бэкенду (см.
// _newApiCall) — разовый обрыв соединения тут не должен молча возвращать
// человека на старый путь и на экран «Доступа пока нет».
function _fetchJsonWithTimeout(url, ms) {
    return _withTimeout(
        _fetchNewApiWithRetry(window.fetch, url, { headers: _newApiHeaders() }, 3), ms || 12000
    ).then(function(r) { return r.json(); });
}

function renderTenantPicker(tenants) {
    return new Promise(function(resolve) {
        // Человек может думать над выбором дольше, чем 20 секунд сторожевого
        // таймера в index.html — иначе тот затрёт кнопки своим «загрузка идёт
        // дольше обычного», и выбрать станет нечего.
        window.__appInitSettled = true;
        var box = document.getElementById('loading');
        box.innerHTML = '<div style="padding:24px;text-align:center;">' +
            '<h3 style="margin-bottom:8px;">Чей кабинет открыть?</h3>' +
            '<p style="opacity:.7;margin-bottom:16px;">Ты занимаешься у нескольких тренеров. ' +
            'Выбор запомнится — поменять можно, открыв мини-апп ссылкой из сообщения нужного тренера.</p>' +
            '<div id="tenant-picker-list"></div></div>';
        var list = document.getElementById('tenant-picker-list');
        tenants.forEach(function(t) {
            var btn = document.createElement('button');
            btn.textContent = t.displayName || t.trainerId;
            btn.style.cssText = 'display:block;width:100%;padding:14px;margin:8px 0;font-size:16px;' +
                'border-radius:12px;border:1px solid #ddd;background:#fff;cursor:pointer;';
            btn.onclick = function() {
                try { localStorage.setItem(TENANT_CHOICE_KEY, t.trainerId); } catch (_) {}
                box.innerHTML = '<div style="padding:40px;text-align:center;">Загружаю…</div>';
                resolve(t.trainerId);
            };
            list.appendChild(btn);
        });
    });
}

async function resolveTenantForVkUser() {
    var chatId = _myChatId();
    if (!chatId) return;
    var data;
    try {
        data = await _fetchJsonWithTimeout(NEW_API_BASE + '/internal/whois/' + encodeURIComponent(chatId));
    } catch (e) {
        console.error('resolveTenantForVkUser failed:', e);
        return; // сеть подвела — дальше как раньше, старым путём
    }
    var tenants = (data && data.tenants || []).filter(function(t) {
        return t.trainerStatus !== 'disabled' && t.clientStatus !== 'deleted' && t.clientStatus !== 'archived';
    });
    // 2026-08-30. Тенанты, где человек — сам тренер (демо), берём ТОЛЬКО если
    // клиентских нет. Порядок важен: у тренера, который вдобавок занимается
    // сам у себя или у коллеги, «мой кабинет клиента» и «мой демо-кабинет»
    // раньше были бы двумя вариантами, и вместо приложения человек получал бы
    // выбор тенанта, которого никогда не видел. Роли в ответе может не быть
    // (бэкенд старее фронтенда — VK-хостинг обновляется руками, отдельно от
    // сервера): тогда считаем строку клиентской, то есть ведём себя ровно как
    // до этой правки.
    var clientTenants = tenants.filter(function(t) { return (t.role || 'client') === 'client'; });
    if (clientTenants.length) {
        tenants = clientTenants;
    } else if (vkLaunchUserId === TRAINER_VK_CHAT_ID.replace('vk_', '')) {
        // Сам Matvey: его кабинет — всегда дефолтный, его и так вернёт
        // _newApiTrainerId ниже по цепочке. Без этой ветки он, будучи
        // тренером своего тенанта (и любых демо, выписанных на себя для
        // проверки), увидел бы «Чей кабинет открыть?» — экран выбора,
        // которого у него никогда не было.
        return;
    } else {
        tenants = tenants.filter(function(t) { return t.role === 'trainer'; });
    }
    if (!tenants.length) return;
    if (tenants.length === 1) { NEW_API_RESOLVED_TRAINER_ID = tenants[0].trainerId; return; }
    var saved = '';
    try { saved = localStorage.getItem(TENANT_CHOICE_KEY) || ''; } catch (_) {}
    var match = tenants.filter(function(t) { return t.trainerId === saved; })[0];
    NEW_API_RESOLVED_TRAINER_ID = match ? match.trainerId : await renderTenantPicker(tenants);
}

// Возвращает false, если доступ тенанта заблокирован (демо истекло/отключён) —
// в этом случае сообщение уже показано и init() должен остановиться, ничего
// больше не загружая.
async function loadTenantConfig() {
    // Без vk_group_id в ссылке, но внутри VK (vkLaunchUserId есть) — всё
    // равно спрашиваем бэкенд: он найдёт тенанта по chatId сам (см. выше).
    //
    // 2026-08-30. Раньше чистый Telegram-запуск здесь ВЫХОДИЛ: «тенант всегда
    // Matvey, спрашивать нечего». Пока у тенанта были только цвет и баннер,
    // которых у Matvey нет, разницы не было. С появлением фото тренера
    // (theme.avatar) разница появилась: в Telegram настройки не запрашивались
    // вовсе, и фото не могло показаться в принципе.
    //
    // Теперь спрашиваем всегда. Это один небольшой запрос при запуске — тот
    // же, что клиенты во VK делают и так. Ошибка не страшна: весь блок ниже
    // обёрнут в try/catch и при неудаче просто остаются значения по умолчанию.
    // VK без vk_group_id в ссылке — сначала выясняем, чей это клиент, иначе
    // ниже уйдём в тенант по умолчанию и покажем «Доступа пока нет» человеку,
    // у которого доступ есть (см. resolveTenantForVkUser выше).
    if (!CURRENT_TRAINER_ID && vkLaunchUserId) await resolveTenantForVkUser();
    try {
        var myChatId = tg && tg.initDataUnsafe && tg.initDataUnsafe.user ? String(tg.initDataUnsafe.user.id) : '';
        var url = APPS_SCRIPT_URL + '?action=getTenantConfig' +
            (myChatId ? '&chatId=' + encodeURIComponent(myChatId) : '');
        var resp = await fetch(url);
        var data = await resp.json();
        if (data && data.blocked) {
            document.body.innerHTML = '<div style="padding:40px 20px;text-align:center;font-family:sans-serif;">' +
                (data.error || 'Доступ недоступен') + '</div>';
            return false;
        }
        if (data && !data.error) {
            tenantTheme = data.theme || null;
            tenantTrainerChatId = data.trainerChatId || '';
            // Бэкенд мог сам разрулить тенанта по chatId, не по trainerId из
            // ссылки (которого у нас не было) — подхватываем узнанный id,
            // чтобы все дальнейшие запросы (через monkey-patch fetch выше)
            // тоже шли в правильную таблицу, а не только этот один.
            //
            // 2026-08-19: НЕ подхватываем, если это NEW_API_DEFAULT_TENANT_TRAINER_ID
            // ('739299264') — реальный найденный баг ("Тренер не найден: 739299264"
            // при входе через личный VK-профиль Matvey без vk_group_id в ссылке).
            // Этот getTenantConfig для дефолт-тенанта уходит НЕ в Apps Script, а в
            // новый бэкенд (см. NEW_API_ACTIONS.getTenantConfig) — и тот честно
            // отвечает canonical trainerId ('739299264', Telegram id) в data.trainerId
            // (см. get_tenant_config в main.py). Но CURRENT_TRAINER_ID везде по
            // файлу — это vk_group_id-пространство (используется и для трейлинга
            // к СТАРОМУ Apps Script, и для сравнения с MATVEY_VK_GROUP_ID в
            // _newApiTrainerId()) — Telegram id туда не подходит вообще. Подхватив
            // его, следующий же запрос (loadWorkoutData) переставал совпадать ни с
            // одним условием в _newApiTrainerId(), падал в СТАРЫЙ Apps Script с
            // трейлингом &trainerId=739299264 — а такой строки в реестре
            // "Тренеры" никогда не было (Matvey там дефолт, без trainerId).
            // _newApiTrainerId() и без этой подмены уже правильно резолвит
            // дефолт-тенант по vkLaunchUserId — сама подмена тут просто не нужна.
            if (data.trainerId && data.trainerId !== 'default' && data.trainerId !== NEW_API_DEFAULT_TENANT_TRAINER_ID) {
                CURRENT_TRAINER_ID = data.trainerId;
            }
            applyTenantTheme(tenantTheme);
        }
    } catch (e) {
        console.error('loadTenantConfig failed:', e);
    }
    return true;
}

let tg;
let workoutData = [];
let completedCount = 0;
let totalExercises = 0;

// Платформа определяется по параметрам запуска: VK Mini Apps всегда добавляют
// vk_user_id в URL при открытии. Если его нет — считаем, что это Telegram
// (или обычный браузер для тестирования на десктопе, см. catch-фоллбэк ниже).
var vkLaunchUserId = new URLSearchParams(window.location.search).get('vk_user_id');

if (vkLaunchUserId) {
    try { window.vkBridge && window.vkBridge.send('VKWebAppInit'); } catch (_) {}
    tg = {
        initDataUnsafe: { user: { id: 'vk_' + vkLaunchUserId } },
        showAlert: function(msg) {
            try {
                window.vkBridge.send('VKWebAppShowSnackbar', { text: String(msg) }).catch(function() { alert(msg); });
            } catch (_) { alert(msg); }
        },
        showConfirm: function(msg, callback) {
            try {
                window.vkBridge.send('VKWebAppShowDialogBox', { title: '', text: String(msg) })
                    .then(function(data) { if (callback) callback(!!(data && data.result)); })
                    .catch(function() { if (callback) callback(confirm(msg)); });
            } catch (_) { if (callback) callback(confirm(msg)); }
        },
        HapticFeedback: {
            impactOccurred: function(style) {
                try { window.vkBridge.send('VKWebAppTapticImpactOccurred', { style: style || 'light' }); } catch (_) {}
            },
            notificationOccurred: function(type) {
                try { window.vkBridge.send('VKWebAppTapticNotificationOccurred', { type: type || 'success' }); } catch (_) {}
            }
        },
        openLink: function(url) {
            try {
                window.vkBridge.send('VKWebAppOpenLink', { link: url }).catch(function() { window.open(url, '_blank'); });
            } catch (_) { window.open(url, '_blank'); }
        },
        openTelegramLink: function(url) { window.open(url, '_blank'); },
        onEvent: function() {},
        ready: function() {},
        expand: function() {},
        isFullscreen: false,
        contentSafeAreaInset: { top: 0 }
    };
    // Во VK кнопки "•••" и "✕" висят плавающими в правом верхнем углу поверх
    // страницы. Пока вкладки стояли сверху, под них резервировалось место
    // справа (--vk-right-pad). После переноса навигации вниз резерв стал не
    // нужен, но содержимое страницы поехало под эти кнопки — приветствие и
    // аватар оказывались под ними. Отступаем сверху так же, как в Telegram.
    document.documentElement.style.setProperty('--tg-top-pad', '48px');
    document.documentElement.style.setProperty('--tg-bottom-pad', '0px');
    document.documentElement.style.setProperty('--vk-right-pad', '0px');
} else {
try {
    tg = window.Telegram.WebApp;
    tg.ready();
    tg.expand();
    // Полноэкранный режим (Bot API 8.0+). Раньше его убрали ВМЕСТЕ с
    // disableVerticalSwipes() — мешала именно блокировка свайпа: без неё
    // мини-апп нельзя было свернуть жестом. Свайп оставляем включённым,
    // просим только полный экран.
    //
    // Вызов обёрнут: на старых клиентах метода нет, а на десктопе он может
    // ответить ошибкой — в обоих случаях просто остаёмся в обычном режиме.
    // Отступ сверху пересчитается сам: applyTelegramTopInset ниже уже умеет
    // читать contentSafeAreaInset и слушает событие fullscreenChanged.
    try {
        if (typeof tg.requestFullscreen === 'function' &&
            typeof tg.isVersionAtLeast === 'function' && tg.isVersionAtLeast('8.0')) {
            tg.requestFullscreen();
        }
    } catch (_) {}
    // Отступ сверху, чтобы контент не залезал под Telegram-шапку (Закрыть/▼/⋯).
    // Bot API 8.0+: tg.contentSafeAreaInset.top даёт точное значение. Старые версии — fallback 56px.
    // Telegram отдаёт ДВА разных отступа, и их надо складывать:
    //   safeAreaInset        — железо: чёлка/строка состояния снизу и сверху;
    //   contentSafeAreaInset — интерфейс Telegram: плавающие «Закрыть» и «•••».
    // Раньше учитывался только второй, поэтому в полноэкранном режиме
    // приветствие и аватар уезжали под кнопку «Закрыть».
    //
    // Снизу env(safe-area-inset-bottom) во встроенном браузере Telegram
    // часто равен нулю — из-за этого подписи нижней навигации срезало
    // домашней полоской. Берём значение у самого Telegram и в CSS выбираем
    // большее из двух.
    function applyTelegramInsets() {
        var top = 0, bottom = 0;
        try {
            var safe = tg.safeAreaInset || {};
            var content = tg.contentSafeAreaInset || {};
            var haveSafe = typeof safe.top === 'number' || typeof content.top === 'number';
            top = (safe.top || 0) + (content.top || 0);
            // Старые клиенты не отдают ни того, ни другого: оставляем прежний
            // запас под шапку, но только когда мы НЕ в полный экран.
            if (!haveSafe && tg.isFullscreen !== true) top = 56;
            bottom = (safe.bottom || 0) + (content.bottom || 0);
        } catch (_) { top = 56; bottom = 0; }
        var root = document.documentElement;
        root.style.setProperty('--tg-top-pad', top + 'px');
        root.style.setProperty('--tg-bottom-pad', bottom + 'px');
    }
    // Прежнее имя оставляем: на него подписаны обработчики событий ниже.
    var applyTelegramTopInset = applyTelegramInsets;
    applyTelegramTopInset();
    // Обновляем при изменении viewport / fullscreen
    try {
        if (typeof tg.onEvent === 'function') {
            tg.onEvent('viewportChanged', applyTelegramTopInset);
            tg.onEvent('contentSafeAreaChanged', applyTelegramTopInset);
            tg.onEvent('fullscreenChanged', applyTelegramTopInset);
            tg.onEvent('safeAreaChanged', applyTelegramTopInset);
        }
    } catch (_) {}
} catch (e) {
    console.error('Telegram WebApp not loaded:', e);
    // БЕЗ user.id здесь (раньше был захардкожен chatId Матвея) — см.
    // объяснение и единственное безопасное место для такого допущения в
    // _myChatId() ниже.
    tg = {
        initDataUnsafe: {},
        showAlert: (msg) => alert(msg),
        openLink: (url) => window.open(url, '_blank'),
        openTelegramLink: (url) => window.open(url, '_blank'),
        HapticFeedback: null
    };
}
}

// Единая точка получения chatId текущего пользователя — везде, где раньше
// каждое место само писало `tg.initDataUnsafe.user ? ... : '739299264'`
// (или TRAINER_CHAT_ID). Раньше это давало доступ ЛЮБОМУ, кто открыл ЛЮБУЮ
// ссылку мини-аппа не в Telegram/VK (обычный браузер) — chatId молча
// подставлялся как Матвея, а isTrainer()/isMatveySuperAdmin() сверяются
// именно с этим id, то есть случайный человек с demo-ссылкой получал
// полную супер-админку (найдено 2026-08-14 при подготовке демо-ссылки для
// Анны). Внутри настоящего Telegram/VK tg.initDataUnsafe.user всегда
// настоящий — туда фолбэк не попадает. Единственное место, где "предположить
// Матвея" оправдано — локальная разработка (localhost), это НЕ публичный
// домен, где ссылку может открыть кто угодно.
function _myChatId() {
    if (tg.initDataUnsafe && tg.initDataUnsafe.user) return String(tg.initDataUnsafe.user.id);
    var isLocalDev = location.hostname === 'localhost' || location.hostname === '127.0.0.1';
    return isLocalDev ? TRAINER_CHAT_ID : '';
}

// Единая безопасная обёртка над tg.showConfirm — раньше в 9 местах файла
// каждое место само проверяло tg.showConfirm && ..., но БЕЗ try/catch вокруг
// самого вызова. Если showConfirm бросает исключение (бывает на части
// Telegram-клиентов) или просто не вызывает колбэк — весь await зависал без
// единого сообщения об ошибке ("нажимаю кнопку — ноль реакции"). Теперь везде
// только через эту функцию, с откатом на нативный confirm() при любой проблеме.
function tgConfirm(message) {
    return new Promise(function(resolve) {
        try {
            if (tg && tg.showConfirm) {
                tg.showConfirm(message, function(ok) { resolve(!!ok); });
            } else {
                resolve(confirm(message));
            }
        } catch (e) {
            console.error('tgConfirm: showConfirm failed, falling back to native confirm', e);
            resolve(confirm(message));
        }
    });
}

document.addEventListener('DOMContentLoaded', init);

var clientName = '';
var weekTitle = '';

// «Load failed» (Safari/VK WebView) и «Failed to fetch» (Chrome) — это не
// ответ сервера, а оборванное соединение: сервер о таком запросе даже не
// узнаёт. Отличаем их от настоящих ошибок, где повтор бессмысленен.
function _isNetworkError(error) {
    var m = (error && error.message) || '';
    return /load failed|failed to fetch|networkerror|network request failed|таймаут/i.test(m);
}

function _humanErrorText(error) {
    var m = (error && error.message) || 'неизвестная ошибка';
    if (_isNetworkError(error)) {
        return 'Не получилось связаться с сервером — похоже, пропала связь. ' +
               'Проверь интернет и открой мини-апп заново.';
    }
    return m;
}

async function init() {
    console.log('Init started...');
    try {
        // 2026-08-19: раньше эти два запроса шли строго по очереди (await
        // loadTenantConfig() → await loadWorkoutData()) — при медленной сети
        // (особенно заметно в VK, см. project_vk_hosting_migration в памяти)
        // это УДВАИВАЕТ время до первого экрана, хотя оба запроса не зависят
        // друг от друга в подавляющем большинстве случаев. Параллелим их —
        // КРОМЕ одного узкого случая: VK-запуск БЕЗ vk_group_id в ссылке
        // (vkLaunchUserId есть, CURRENT_TRAINER_ID пуст) — тогда
        // loadTenantConfig() сам резолвит тенанта по chatId и может
        // ПОДМЕНИТЬ CURRENT_TRAINER_ID (см. её тело выше), а loadWorkoutData()
        // должен уйти уже с правильным id — здесь порядок важен, оставляем
        // как было.
        var needsSequentialTenant = !!vkLaunchUserId && !CURRENT_TRAINER_ID;
        var tenantOk, response;
        if (needsSequentialTenant) {
            tenantOk = await loadTenantConfig();
            if (!tenantOk) return;
            response = await loadWorkoutData();
        } else {
            var results = await Promise.all([loadTenantConfig(), loadWorkoutData()]);
            tenantOk = results[0];
            response = results[1];
            if (!tenantOk) return;
        }
        console.log('Data received:', response);
        clientName = response.clientName || '';
        weekTitle = response.weekTitle || '';
        if (response.weekTitle) {
            const weekNum = response.weekTitle.replace('Неделя ', '');
            document.getElementById('week-number').textContent = weekNum;
        }
        workoutData = response.days || [];
        // Прошлый результат по каждому упражнению — одним запросом на всю
        // тренировку (см. loadLastSessions). Ошибка не мешает: карточки
        // просто отрисуются без блока «Прошлый раз».
        try {
            var _lsMap = await loadLastSessions(_myChatId());
            workoutData.forEach(function(day) {
                (day.exercises || []).forEach(function(ex) {
                    var ls = _lsMap[_lastSessionKey(ex.exercise)];
                    if (ls) ex.lastSession = ls;
                });
            });
        } catch (e) { console.error('lastSessions attach failed:', e); }
        totalExercises = 0;
        completedCount = 0;
        workoutData.forEach(day => {
            day.exercises.forEach(exercise => {
                totalExercises++;
                if (exercise.weightFact || exercise.repsFact) {
                    completedCount++;
                }
            });
        });
        renderWorkout();
        renderHome();
        // Подгружаем рекорды и вес в фоне (для карточек на главной)
        loadHomeExtras();
        window.__appInitSettled = true; // см. сторожевой таймер в index.html — не перекрывать успешный экран
        document.getElementById('loading').classList.add('hidden');
        document.getElementById('main-screen').classList.remove('hidden');
        initializeTabs();
        initAdminTab();
        initSuperAdminTab();
        // Опрос самочувствия — один раз при первом входе в тренировку.
        // Если клиент закроет/пропустит — считается «Бодрый», веса как есть.
        if (!wellnessAsked && workoutData.length > 0) {
            wellnessAsked = true;
            setTimeout(openWellnessModal, 400);
        }
        // Позже опроса самочувствия: два системных окна подряд — перебор,
        // а это разрешение ничего не блокирует и может подождать секунду.
        setTimeout(maybeAskVkMessagesPermission, 1600);
    } catch (error) {
        console.error('ERROR:', error);
        // Любая ветка catch дальше сама покажет какой-то финальный экран
        // (админку, запрос доступа или текст ошибки) — сторожевой таймер в
        // index.html не должен затирать это своим общим "грузится долго",
        // если он сработает уже ПОСЛЕ того, как мы сами разобрались с ошибкой.
        window.__appInitSettled = true;
        // См. _myChatId() — вне Telegram/VK (обычный браузер) и не на
        // localhost currentChatId будет '', isTrainer('') = false, и код
        // ниже честно уйдёт в общий экран ошибки, а не притворится Матвеем.
        var currentChatId = _myChatId();
        if (/Client not found/.test(error.message) && isTrainer(currentChatId)) {
            // Тренер открыл свою же панель, но у него нет "своей" карточки клиента
            // (в отличие от Matvey, у которого в таблице есть тестовая запись о
            // себе — исторически) — это нормально. Ведём сразу в админку, а не на
            // экран "запросить доступ у тренера" (это же и есть тренер).
            document.getElementById('loading').classList.add('hidden');
            document.getElementById('main-screen').classList.remove('hidden');
            initializeTabs();
            initAdminTab();
        initSuperAdminTab();
            var adminTabBtn = document.querySelector('.tab-btn[data-tab="admin"]');
            if (adminTabBtn) adminTabBtn.click();
            return;
        }
        if (vkLaunchUserId && /Client not found/.test(error.message)) {
            renderVkAccessRequest();
            return;
        }
        // Обрыв соединения на старте — самая частая беда во встроенном
        // браузере VK: связь в зале рвётся, запрос умирает, человек видит
        // красный экран с непонятным «Load failed» и идёт перезаходить
        // вручную. Один автоматический повтор снимает почти все такие случаи;
        // повторяем ровно раз, чтобы не крутиться вечно при реальной поломке.
        if (_isNetworkError(error) && !window.__initRetriedOnce) {
            window.__initRetriedOnce = true;
            window.__appInitSettled = false;
            document.getElementById('loading').innerHTML =
                '<div style="padding:20px;text-align:center;color:#666;">Связь оборвалась — пробую ещё раз…</div>';
            setTimeout(init, 1200);
            return;
        }
        document.getElementById('loading').innerHTML =
            '<div style="color: red; padding: 20px; text-align: center;">' +
            '<h3>Ошибка загрузки</h3>' +
            '<p>' + _humanErrorText(error) + '</p>' +
            '<button onclick="location.reload()" style="padding: 10px 20px; margin-top: 10px;">Перезагрузить</button>' +
            '</div>';
    }
}

// Клиент открыл мини-апп во VK, но тренер ещё не выдал доступ (в VK нет
// бота-шлагбаума перед мини-аппом, как в Telegram, поэтому проверяем здесь).
function renderVkAccessRequest() {
    var chatId = tg.initDataUnsafe.user.id; // 'vk_<numeric id>'
    document.getElementById('loading').innerHTML =
        '<div style="padding: 24px; text-align: center;">' +
        '<h3>Доступа пока нет</h3>' +
        '<p>Тренер уже получил уведомление о твоей заявке. Если долго нет ответа — просто скажи ему этот код:</p>' +
        '<p style="font-size: 20px; font-weight: bold; margin: 12px 0;">' + chatId + '</p>' +
        '<button onclick="location.reload()" style="padding: 10px 20px; margin-top: 10px;">Проверить ещё раз</button>' +
        '</div>';

    function ping(name) {
        fetch(APPS_SCRIPT_URL + '?action=requestAccess&chatId=' + encodeURIComponent(chatId) + '&name=' + encodeURIComponent(name || '')).catch(function() {});
    }
    try {
        window.vkBridge.send('VKWebAppGetUserInfo').then(function(data) {
            ping(((data.first_name || '') + ' ' + (data.last_name || '')).trim());
        }).catch(function() { ping(''); });
    } catch (_) { ping(''); }
}
 
// VK не даёт сообществу написать человеку первым: пока клиент сам не начал
// диалог, ЛЮБОЕ уведомление от бота отклоняется с ошибкой 901 — и тренер
// узнаёт об этом в лучшем случае через неделю («я ничего не получал»).
// Мини-апп может спросить разрешение сам, одним системным окном: клиент
// тапает «Разрешить» — и с этого момента до него доходят и уведомления об
// обновлённой программе, и вечерние итоги, и напоминания об абонементе.
//
// Спрашиваем ОДИН раз на группу и только после того, как экран уже
// загрузился: диалог поверх спиннера выглядит как навязчивая просьба
// непонятно от кого. Отказ не запоминаем навсегда — переспросим через
// неделю, вдруг человек просто торопился.
var VK_MSGS_ASK_AGAIN_AFTER_MS = 7 * 24 * 60 * 60 * 1000;

function maybeAskVkMessagesPermission() {
    if (!vkLaunchUserId || !window.vkBridge) return;
    var groupId = new URLSearchParams(window.location.search).get('vk_group_id') || '';
    if (!/^\d+$/.test(groupId)) return; // запуск без группы — не у кого просить
    var key = 'vk_msgs_' + groupId;
    var saved = '';
    try { saved = localStorage.getItem(key) || ''; } catch (_) {}
    if (saved === 'allowed') return;
    if (saved && Date.now() - parseInt(saved, 10) < VK_MSGS_ASK_AGAIN_AFTER_MS) return;
    try {
        window.vkBridge.send('VKWebAppAllowMessagesFromGroup', { group_id: parseInt(groupId, 10), key: '' })
            .then(function(data) {
                try { localStorage.setItem(key, (data && data.result) ? 'allowed' : String(Date.now())); } catch (_) {}
            })
            .catch(function() {
                try { localStorage.setItem(key, String(Date.now())); } catch (_) {}
            });
    } catch (_) {}
}

async function loadWorkoutData() {
    var chatId = _myChatId();
    var url = APPS_SCRIPT_URL + '?action=read&chatId=' + chatId;
    // Google Apps Script изредка отвечает разовым сбоем (HTTP 404/500 на
    // редиректе к googleusercontent.com) без видимой причины — само по себе
    // проходит при повторном запросе. Ретраим только СЕТЕВЫЕ/HTTP-сбои — не
    // трогаем осмысленные ответы бэкенда вида {error: "Client not found"},
    // их повтор не исправит, а только зря отложит нужный экран (админка/
    // запрос доступа).
    var lastErr;
    var maxAttempts = 4; // на практике наблюдали до 3 сбоев подряд — берём запас
    for (var attempt = 0; attempt < maxAttempts; attempt++) {
        try {
            var response = await fetch(url);
            if (!response.ok) throw new Error('HTTP error ' + response.status);
            var data = await response.json();
            if (data.error) throw new Error(data.error);
            return data;
        } catch (e) {
            lastErr = e;
            if (!/^HTTP error/.test(e.message)) throw e;
            if (attempt < maxAttempts - 1) await new Promise(function(r) { setTimeout(r, 700); });
        }
    }
    throw lastErr;
}
 
function renderWorkout() {
    var container = document.getElementById('exercises-container');
    container.innerHTML = '';
    workoutData.forEach(function(day, dayIndex) {
        // Считаем выполненные упражнения в этом дне
        var dayCompleted = 0;
        var dayTotal = day.exercises.length;
        day.exercises.forEach(function(ex) {
            if (ex.weightFact || ex.repsFact) dayCompleted++;
        });
        var dayDone = dayCompleted === dayTotal && dayTotal > 0;

        // Заголовок дня (кликабельный)
        var dayHeader = document.createElement('div');
        dayHeader.className = 'day-header day-collapsible';
        dayHeader.dataset.dayIndex = dayIndex;
        // Тёмная карточка дня (DESIGN.md + утверждённый макет): слева иконка
        // и название с подписью недели, справа счётчик и шеврон. Символы ✅ ▼
        // заменены на Lucide — эмодзи из интерфейса убраны.
        dayHeader.innerHTML =
            '<span class="day-head-main">' +
                '<span class="day-head-ico">' + _homeIcon('flame') + '</span>' +
                '<span class="day-head-txt">' +
                    '<span class="day-title">' + _escHtml(day.day) + '</span>' +
                    '<span class="day-sub">' + _escHtml(weekTitle || '') + '</span>' +
                '</span>' +
            '</span>' +
            '<span class="day-status">' +
                (dayDone ? '<span class="day-done">' + _homeIcon('check') + '</span>' : '') +
                '<span class="day-counter">' + dayCompleted + ' / ' + dayTotal + '</span>' +
                '<span class="day-chevron">' + _homeIcon('chevron') + '</span>' +
            '</span>';
        container.appendChild(dayHeader);

        // Контейнер упражнений (сворачиваемый)
        var dayBody = document.createElement('div');
        dayBody.className = 'day-body';
        dayBody.id = 'day-body-' + dayIndex;

        // Суперсеты/трисеты (см. groupExercises ниже — та же группировка, что
        // и в редакторе тренера) показываем клиенту сгруппированными, с общей
        // подписью, а не отдельными карточками с "Сет:"/"Трисет:" в названии.
        var groups = groupExercises(day.exercises || []);
        var flatIndex = 0;
        groups.forEach(function(group) {
            // Связка (суперсет, трисет, круг) рисуется общим блоком со всеми
            // своими упражнениями. Круг сюда не входил — и уходил в ветку
            // ниже, где берётся ТОЛЬКО первое упражнение группы: у клиента
            // круг из пяти движений превращался в одно, а тренировка
            // выглядела наполовину короче, чем расписал тренер.
            if (group.type === 'superset' || group.type === 'triset' || blockTypeInfo(group.type)) {
                var wrap = document.createElement('div');
                wrap.className = 'exercise-group-block';
                var label = document.createElement('div');
                label.className = 'exercise-group-label';
                var blockInfo = blockTypeInfo(group.type);
                // 2026-08-31 (M-3). Раньше здесь стояло blockInfo.label —
                // «🤸 Разминка», «🔄 Круговая», «🧘 Заминка». Это были
                // единственные эмодзи на клиентских экранах, где по DESIGN.md
                // их нет вообще, только иконки Lucide. У тренера подписи
                // остаются прежними — его интерфейс мы не трогаем.
                label.innerHTML = blockInfo
                    ? (_homeIcon('repeat') + '<span>' + _escHtml(blockInfo.short) +
                       ' · ' + group.exercises.length + ' упр.</span>')
                    : ('<span>' + (group.type === 'triset' ? 'Трисет' : 'Суперсет') + '</span>');
                wrap.appendChild(label);
                group.exercises.forEach(function(exercise) {
                    wrap.appendChild(createExerciseCard(exercise, dayIndex, flatIndex));
                    flatIndex++;
                });
                dayBody.appendChild(wrap);
            } else {
                dayBody.appendChild(createExerciseCard(group.exercises[0], dayIndex, flatIndex));
                flatIndex++;
            }
        });
        container.appendChild(dayBody);

        // Стрелки для уже заполненных упражнений — сразу, не дожидаясь ввода.
        (day.exercises || []).forEach(function(_ex, i) { updateExerciseDelta(dayIndex, i); });

        // Клик по заголовку — свернуть/развернуть
        dayHeader.addEventListener('click', function() {
            var body = document.getElementById('day-body-' + this.dataset.dayIndex);
            var isCollapsed = body.classList.toggle('collapsed');
            this.classList.toggle('collapsed', isCollapsed);
            // Шеврон — SVG, поэтому поворачиваем его стилями по классу
            // .collapsed у заголовка, а не подменяем символ текстом.
            if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred('light');
        });
    });
    updateProgress();
}
 
// Экранирование для вставки произвольной строки (ссылки) внутрь HTML-атрибута.
// Раньше ссылка на видео шла прямо в onclick="..." со «своим» экранированием
// под JS-строку — если в ссылке (скопированной из таблицы) оказывалась хоть
// одна двойная кавычка/перенос строки, вся кнопка молча ломалась.
// Экранирование произвольного текста внутри HTML. Названия упражнений
// приходят от тренера и содержат что угодно — кавычки, угловые скобки.
function _escHtml(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

function _escHtmlAttr(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

// Упражнения, которые клиент раскрыл руками, хотя они уже выполнены.
// Живёт только в памяти вкладки: это состояние интерфейса, а не данные, и
// на сервер оно не уходит. Свёрнутость сама по себе никуда не сохраняется —
// она выводится из exercise.feedback, поэтому переживает любую перерисовку.
var _exExpanded = {};

// Содержимое свёрнутой карточки. Собирается отдельно, чтобы после выбора
// оценки обновить только его, не перерисовывая карточку целиком.
function _exSummaryInner(exercise, exIndex) {
    var fbInfo = exercise.feedback ? RPE_FEEDBACK_MAP[exercise.feedback] : null;
    var photo = exercise.photo1 || exercise.photo2 || '';
    var thumb = photo
        ? '<span class="ex-sum-thumb"><img src="' + _escHtmlAttr(String(photo)) + '" alt="" ' +
          'loading="lazy" onerror="this.style.display=\'none\'"></span>'
        : '';
    // Вес показываем фактический; пока его нет — плановый, чтобы строка не
    // выглядела пустой.
    var w = exercise.weightFact || getDisplayWeight(exercise.weightPlan) || '';
    var meta = [];
    if (exercise.sets && exercise.reps) meta.push(exercise.sets + ' × ' + exercise.reps);
    if (w) meta.push(w + ' кг');
    return thumb +
        '<span class="ex-sum-txt">' +
            '<span class="ex-sum-head">' +
                '<span class="ex-sum-num">' + (exIndex + 1) + '</span>' +
                '<span class="ex-sum-name">' + _escHtml(cleanExerciseName(exercise.exercise)) + '</span>' +
            '</span>' +
            (meta.length ? '<span class="ex-sum-meta">' + meta.join(' · ') + '</span>' : '') +
            (fbInfo ? '<span class="ex-sum-res">' + _homeIcon('check') +
                      '<span>' + fbInfo.label + '</span></span>' : '') +
        '</span>' +
        '<span class="ex-sum-chev">' + _homeIcon('chevron') + '</span>';
}

// Приводит карточку к её состоянию: выполненная и не раскрытая руками —
// свёрнута. Никаких данных не трогает, только классы и текст сводки.
function _syncExerciseCard(dayIndex, exIndex) {
    var card = document.getElementById('ex-card-' + dayIndex + '-' + exIndex);
    if (!card) return;
    var ex = workoutData[dayIndex] && workoutData[dayIndex].exercises[exIndex];
    if (!ex) return;
    var done = !!ex.feedback;
    card.classList.toggle('has-feedback', done);
    card.classList.toggle('collapsed', done && !_exExpanded[dayIndex + '-' + exIndex]);
    var sum = card.querySelector('.ex-summary');
    if (sum) sum.innerHTML = _exSummaryInner(ex, exIndex);
}

// Клик по свёрнутой карточке — раскрыть, по шеврону раскрытой — свернуть.
function toggleExerciseCard(dayIndex, exIndex) {
    var key = dayIndex + '-' + exIndex;
    if (_exExpanded[key]) delete _exExpanded[key];
    else _exExpanded[key] = true;
    _syncExerciseCard(dayIndex, exIndex);
    if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred('light');
}


// ── Прошлый результат прямо в карточке упражнения (2026-08-31, H-3) ──────────
// Разметка для этого в карточке была давно (lastSessionHtml), но поле
// exercise.lastSession никто не заполнял — блок не показывался никогда, и
// тренер уходил смотреть прошлый результат во вкладку «История».
//
// Берём ВСЮ историю ОДНИМ запросом (getSelfHistory уже используется вкладкой
// истории), а не по запросу на упражнение: в дне их бывает двадцать, и
// двадцать обращений к серверу на открытие тренировки — это секунды ожидания
// на телефоне и лишний риск на рваной связи.
var _lastSessionByExercise = null;

function _lastSessionKey(name) {
    return cleanExerciseName(name || '').toLowerCase().trim();
}

async function loadLastSessions(chatId) {
    if (_lastSessionByExercise) return _lastSessionByExercise;
    var map = {};
    try {
        var resp = await fetch(APPS_SCRIPT_URL + '?action=getSelfHistory&chatId=' +
            encodeURIComponent(chatId) + '&limit=60');
        var data = await resp.json();
        // История отсортирована от свежих к старым — значит первое встреченное
        // упоминание упражнения и есть последний результат.
        (data.history || []).forEach(function(day) {
            (day.exercises || []).forEach(function(ex) {
                var key = _lastSessionKey(ex.exercise);
                if (!key || map[key]) return;
                if (!ex.weightFact && !ex.repsFact) return;
                map[key] = {
                    weight: ex.weightFact, reps: ex.repsFact, rpe: ex.rpe,
                    feedback: _rpeToFeedback(ex.rpe), date: day.date || ''
                };
            });
        });
    } catch (e) {
        console.error('loadLastSessions failed:', e);   // не критично: просто не покажем
    }
    _lastSessionByExercise = map;
    return map;
}

// Стрелка «лучше/хуже/так же» рядом с полем ввода.
function _deltaHtml(current, previous, unit) {
    var cur = parseFloat(String(current).replace(',', '.'));
    var prev = parseFloat(String(previous).replace(',', '.'));
    if (!isFinite(cur) || !isFinite(prev)) return '';
    var diff = Math.round((cur - prev) * 100) / 100;
    if (diff > 0) return '<span class="ex-delta up">↑ +' + diff + (unit || '') + '</span>';
    if (diff < 0) return '<span class="ex-delta down">↓ ' + diff + (unit || '') + '</span>';
    return '<span class="ex-delta same">= без изменений</span>';
}

// Пересчитать стрелки у одного упражнения — зовётся при каждом вводе.
function updateExerciseDelta(dayIndex, exIndex) {
    var ex = workoutData[dayIndex] && workoutData[dayIndex].exercises[exIndex];
    if (!ex) return;
    var ls = ex.lastSession;
    var wBox = document.getElementById('delta-weight-' + dayIndex + '-' + exIndex);
    var rBox = document.getElementById('delta-reps-' + dayIndex + '-' + exIndex);
    if (wBox) wBox.innerHTML = (ls && ls.weight) ? _deltaHtml(ex.weightFact, ls.weight, ' кг') : '';
    if (rBox) rBox.innerHTML = (ls && ls.reps) ? _deltaHtml(ex.repsFact, ls.reps, '') : '';
}

function createExerciseCard(exercise, dayIndex, exIndex) {
    var card = document.createElement('div');
    card.className = 'exercise-card';
    card.id = 'ex-card-' + dayIndex + '-' + exIndex;
    var videoStr = exercise.video != null ? String(exercise.video).trim() : '';
    var videoVkStr = exercise.videoVk != null ? String(exercise.videoVk).trim() : '';
    var hasVideo = (videoStr && (videoStr.indexOf('http') !== -1 || videoStr.indexOf('📽️') !== -1)) ||
        (videoVkStr && videoVkStr.indexOf('http') !== -1);
    // Фото упражнения. Их может быть два (исходное и конечное положение) —
    // показываем оба в одной медиа-области. Если фото нет вообще, рисуем
    // аккуратную заглушку с иконкой, а не эмодзи-гантелю, как раньше.
    var photos = [];
    if (exercise.photo1) photos.push(String(exercise.photo1));
    if (exercise.photo2) photos.push(String(exercise.photo2));
    var videoAttrs = 'data-video="' + _escHtmlAttr(videoStr) + '" ' +
                     'data-video-vk="' + _escHtmlAttr(videoVkStr) + '" ' +
                     'onclick="openVideo(this.dataset.video, this.dataset.videoVk)"';

    // Большая медиа-область рисуется ТОЛЬКО когда фото действительно есть.
    // Раньше на её месте оставалась пустая серая плашка на 223px — самый
    // крупный элемент карточки, не несущий никакой информации.
    var mediaHtml = '';
    var videoRowHtml = '';
    if (photos.length) {
        var imgs = photos.map(function(src) {
            return '<img src="' + _escHtmlAttr(src) + '" alt="" class="ex-media-img" ' +
                   'loading="lazy" onerror="this.style.display=\'none\'">';
        }).join('');
        // Кнопка видео поверх фото: круглая «play» по центру и подпись внизу.
        var overlay = hasVideo
            ? '<button class="video-btn" ' + videoAttrs + '>' +
                  '<span class="video-play">' + _homeIcon('play') + '</span>' +
                  '<span class="video-cap">Видео техники</span>' +
              '</button>'
            : '';
        mediaHtml = '<div class="ex-media' + (photos.length > 1 ? ' ex-media-2' : '') + '">' +
            imgs + overlay + '</div>';
    } else if (hasVideo) {
        // Фото нет, но видео есть — компактная кликабельная строка вместо
        // картинки. Если нет ни того, ни другого, не рисуем ничего: пустой
        // заглушки и фальшивых кнопок на экране быть не должно.
        videoRowHtml = '<button class="video-row" ' + videoAttrs + '>' +
                '<span class="video-row-ico">' + _homeIcon('play') + '</span>' +
                '<span class="video-row-txt">Видео техники</span>' +
                '<span class="video-row-arrow">' + _homeIcon('chevron') + '</span>' +
            '</button>';
    }
    // Заметка тренера — лёгкая карточка-подсказка. Текст экранируем: он
    // приходит от тренера и раньше вставлялся в разметку как есть.
    var noteHtml = exercise.note
        ? '<div class="trainer-note">' + _homeIcon('bulb') +
          '<span>' + _escHtml(exercise.note) + '</span></div>'
        : '';
    var commentValue = exercise.comment || '';
    if (commentValue && /^\d{4}-\d{2}-\d{2}T/.test(commentValue)) commentValue = '';
    if (commentValue && /^\d{2}\.\d{2}\.\d{4}/.test(commentValue)) commentValue = '';

    // Вес: с учётом самочувствия (если уставший/приболел — снижаем для отображения)
    var baseWeight = exercise.weightPlan;
    var todayWeight = getDisplayWeight(baseWeight);
    var weightAdjusted = (baseWeight && todayWeight !== baseWeight);
    var weightHtml = weightAdjusted
        ? todayWeight + 'кг <small class="weight-adj">(было ' + baseWeight + ')</small>'
        : (baseWeight || '—') + 'кг';

    // Прозрачность: показать что было в прошлый раз для контекста прогрессии
    var lastSessionHtml = '';
    if (exercise.lastSession && exercise.lastSession.weight) {
        var ls = exercise.lastSession;
        var fbInfo = RPE_FEEDBACK_MAP[ls.feedback];
        var fbText = fbInfo ? ' · ' + fbInfo.label : '';
        var dateStr = ls.date ? ' · ' + ls.date : '';
        lastSessionHtml = '<div class="last-session-info">' + _homeIcon('history') +
            '<span>Прошлый раз: ' + ls.weight + ' × ' + ls.reps + fbText + dateStr + '</span>' +
            '</div>';
    }

    function _param(icon, label, value, cls) {
        return '<div class="param">' +
                   '<div class="param-label">' + _homeIcon(icon) + '<span>' + label + '</span></div>' +
                   '<div class="param-value' + (cls ? ' ' + cls : '') + '">' + value + '</div>' +
               '</div>';
    }

    card.innerHTML =
        // Свёрнутый вид. Лежит в разметке всегда, показывается по классу —
        // так после выбора оценки не нужно пересобирать карточку.
        '<button type="button" class="ex-summary" ' +
            'onclick="toggleExerciseCard(' + dayIndex + ',' + exIndex + ')">' +
            _exSummaryInner(exercise, exIndex) +
        '</button>' +
        mediaHtml +
        '<div class="exercise-body">' +
            '<div class="exercise-name">' +
                '<span>' + _escHtml(cleanExerciseName(exercise.exercise)) + '</span>' +
                // Кнопка «свернуть» есть в разметке всегда, но видна только у
                // выполненных упражнений (класс has-feedback на карточке).
                '<button type="button" class="ex-collapse" ' +
                    'onclick="toggleExerciseCard(' + dayIndex + ',' + exIndex + ')" ' +
                    'aria-label="Свернуть упражнение">' + _homeIcon('chevron') + '</button>' +
            '</div>' +
            videoRowHtml +
            lastSessionHtml +
            '<div class="exercise-params">' +
                _param('hash',   'Подходы',    exercise.sets) +
                _param('repeat', 'Повторения', exercise.reps) +
                _param('weight', 'Вес',        weightHtml, 'plan') +
                _param('flame',  'Сложность',  exercise.rpe, 'rpe') +
            '</div>' +
            noteHtml +
            '<div class="ex-result">' +
            // Факт и самочувствие — два разных вопроса, поэтому и два разных
            // блока со своими заголовками. Раньше поля и кнопки стояли одной
            // сеткой и читались как шесть одинаковых прямоугольников.
            '<div class="ex-block">' +
                '<div class="ex-block-ttl">Фактический результат</div>' +
                '<div class="input-row">' +
                    '<label class="input-cell"><span class="input-cap">Вес, кг</span>' +
                        '<input type="text" inputmode="decimal" enterkeyhint="done" class="input-field" placeholder="—" value="' + _escHtmlAttr(exercise.weightFact || '') + '" data-day="' + dayIndex + '" data-exercise="' + exIndex + '" data-row="' + exercise.rowIndex + '" data-field="weight" oninput="handleInput(this)" onchange="handleInput(this)">' +
                        '<span class="ex-delta-slot" id="delta-weight-' + dayIndex + '-' + exIndex + '"></span>' +
                    '</label>' +
                    '<label class="input-cell"><span class="input-cap">Повторения</span>' +
                        '<input type="text" inputmode="numeric" enterkeyhint="done" class="input-field" placeholder="—" value="' + _escHtmlAttr(exercise.repsFact || '') + '" data-day="' + dayIndex + '" data-exercise="' + exIndex + '" data-row="' + exercise.rowIndex + '" data-field="reps" oninput="handleInput(this)" onchange="handleInput(this)">' +
                        '<span class="ex-delta-slot" id="delta-reps-' + dayIndex + '-' + exIndex + '"></span>' +
                    '</label>' +
                '</div>' +
            '</div>' +
            '<div class="ex-block">' +
                '<div class="ex-block-ttl">Как прошло упражнение?</div>' +
                '<div class="rpe-feedback-row" id="rpe-row-' + dayIndex + '-' + exIndex + '">' +
                    renderRpeButton(exercise, dayIndex, exIndex) +
                '</div>' +
            '</div>' +
            '<textarea class="comment-field" placeholder="Комментарий к упражнению (опционально)" data-day="' + dayIndex + '" data-exercise="' + exIndex + '" data-row="' + exercise.rowIndex + '" data-field="comment" onchange="handleInput(this)">' + commentValue + '</textarea>' +
            '</div>' +
        '</div>';

    // Уже оценённое упражнение приезжает свёрнутым; незаполненное — раскрытым.
    if (exercise.feedback && !_exExpanded[dayIndex + '-' + exIndex]) {
        card.classList.add('collapsed');
    }
    if (exercise.feedback) card.classList.add('has-feedback');
    return card;
}

// ─── Самочувствие клиента (per session, спрашивается при входе) ────────
var WELLNESS_MAP = {
    good:  { multiplier: 1.00, emoji: '💪', label: 'Бодрый',     factor: '' },
    tired: { multiplier: 0.90, emoji: '😴', label: 'Устал',      factor: '−10%' },
    sick:  { multiplier: 0.85, emoji: '🤧', label: 'Приболел',   factor: '−15%' },
    pms:   { multiplier: 0.90, emoji: '🩸', label: 'ПМС',        factor: '−10%' }
};
// Иконка состояния для баннера. Ключи те же, что в WELLNESS_MAP.
var WELLNESS_ICONS = { good: 'smile', tired: 'moon', sick: 'thermometer', pms: 'droplet' };

var sessionWellness = 'good';
var wellnessAsked = false;

function getWellnessMultiplier() {
    var w = WELLNESS_MAP[sessionWellness];
    return w ? w.multiplier : 1.0;
}

function openWellnessModal() {
    document.getElementById('wellness-modal').classList.remove('hidden');
}
function closeWellnessModal() {
    document.getElementById('wellness-modal').classList.add('hidden');
}
function setWellness(kind) {
    sessionWellness = WELLNESS_MAP[kind] ? kind : 'good';
    closeWellnessModal();
    updateWellnessBanner();
    // Перерисовать все дни с новыми весами (мультипликатор изменился)
    if (workoutData && workoutData.length) renderAllDaysIfNeeded();
    if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred('light');
}
function skipWellness() {
    setWellness('good');
}

function updateWellnessBanner() {
    var b = document.getElementById('wellness-banner');
    if (!b) return;
    if (sessionWellness === 'good') {
        b.classList.add('hidden');
        return;
    }
    var info = WELLNESS_MAP[sessionWellness];
    b.classList.remove('hidden');
    // WELLNESS_MAP не трогаем — эмодзи в нём остаются для других мест.
    // В интерфейсе показываем иконку по тому же ключу.
    b.innerHTML = '<span class="wellness-banner-ico">' +
                      _homeIcon(WELLNESS_ICONS[sessionWellness] || 'moon') + '</span>' +
                  '<span class="wellness-banner-txt">' + info.label +
                      ' — рекомендуемые веса снижены на ' + info.factor + '</span>' +
                  '<button class="wellness-banner-edit" onclick="openWellnessModal()">изменить</button>';
}

// Перерисовка дней — поддержка обновления весов после смены самочувствия
function renderAllDaysIfNeeded() {
    if (typeof renderWorkout === 'function') renderWorkout();
}

// Разобрать вес: понимает «80», «80.5», «80-90», «80,5 - 90» → {min, max}
function _parseWeightRange(s) {
    if (s == null) return null;
    var str = s.toString().replace(',', '.').trim();
    var nums = str.match(/[0-9]+(?:\.[0-9]+)?/g);
    if (!nums || nums.length === 0) return null;
    var min = parseFloat(nums[0]);
    var max = nums.length > 1 ? parseFloat(nums[nums.length - 1]) : min;
    if (isNaN(min)) return null;
    if (isNaN(max)) max = min;
    return { min: min, max: max };
}

// Применить самочувствие к плановому весу для отображения клиенту.
// Логика:
//   «Бодрый» (mult=1.0)     → план без изменений (как написал тренер, например «80-90»)
//   «Устал» / «Приболел» / «ПМС» (mult<1) → нижняя граница × mult (со скидкой), округление до 0.5кг
// Если weightPlan — одиночное число, используем его как min=max.
function getDisplayWeight(weightPlan) {
    var mult = getWellnessMultiplier();
    // Бодрый — ничего не трогаем, отдаём план как есть
    if (mult >= 1) return weightPlan;
    var range = _parseWeightRange(weightPlan);
    if (!range) return weightPlan; // нечисловое значение — оставляем как есть
    // Со снижением — нижняя граница диапазона × мультипликатор, округление до 0.5кг
    return Math.round(range.min * mult * 2) / 2;
}

// ─── RPE-фидбэк (после каждого упражнения, опционально) ───────────────
var RPE_FEEDBACK_MAP = {
    easy:   { rpe: 5.5, emoji: '😌', label: 'Легко' },
    normal: { rpe: 7.5, emoji: '💪', label: 'В самый раз' },
    hard:   { rpe: 9,   emoji: '🔥', label: 'Тяжело' },
    failed: { rpe: 10,  emoji: '❌', label: 'Не вытянул' }
};
var FAIL_REASON_LABELS = {
    too_hard: 'слишком тяжело',
    sleep:    'плохо спал',
    illness:  'плохо себя чувствовал',
    stress:   'стресс',
    food:     'мало еды/энергии'
};
// Оценка ставится прямо в карточке: три подписи видны сразу, тап по любой
// сохраняет ответ. Раньше здесь была одна кнопка-заглушка «+ Как было
// упражнение?», а сам выбор жил в отдельной модалке — и она ещё и
// открывалась сама, как только заполнены вес и повторы. Экран поверх
// экрана ради трёх слов; теперь модалка осталась только у «Не вытянул»,
// где действительно надо уточнить причину (она влияет на прогрессию весов).
var RPE_QUICK_KINDS = ['easy', 'normal', 'hard'];

// Иконка для каждой оценки. Эмодзи в RPE_FEEDBACK_MAP оставлены нетронутыми:
// они используются в других местах (уведомления, отчёты), а в интерфейсе
// экрана тренировки рисуем Lucide.
var RPE_ICONS = { easy: 'smile', normal: 'dumbbell', hard: 'flame', failed: 'x' };

function renderRpeButton(exercise, dayIndex, exIndex) {
    var fb = exercise.feedback || '';
    // Четыре равные кнопки-состояния в сетке 2x2. Раньше «Не вытянул» была
    // отдельной широкой кнопкой под тремя остальными — смысл и обработчик те
    // же, изменилась только раскладка.
    var kinds = RPE_QUICK_KINDS.concat(['failed']);
    var html = '<div class="rpe-quick-row">';
    for (var i = 0; i < kinds.length; i++) {
        var kind = kinds[i];
        var info = RPE_FEEDBACK_MAP[kind];
        html += '<button type="button" class="rpe-quick-btn rpe-' + kind +
            (fb === kind ? ' rpe-picked' : '') + '" ' +
            'onclick="setRpeQuick(' + dayIndex + ',' + exIndex + ',\'' + kind + '\')">' +
            _homeIcon(RPE_ICONS[kind] || 'smile') +
            '<span>' + info.label + '</span>' +
            '</button>';
    }
    html += '</div>';
    return html;
}

// Обновляет кнопки фидбэка в DOM после изменения
function refreshRpeButton(dayIndex, exIndex) {
    var container = document.getElementById('rpe-row-' + dayIndex + '-' + exIndex);
    if (!container) return;
    var ex = workoutData[dayIndex].exercises[exIndex];
    container.innerHTML = renderRpeButton(ex, dayIndex, exIndex);
}

function setRpeQuick(dayIndex, exIndex, kind) {
    var info = RPE_FEEDBACK_MAP[kind];
    if (!info) return;
    var ex = workoutData[dayIndex].exercises[exIndex];
    if (ex.feedback === kind) {
        // Повторный тап по выбранной — снять оценку. Кнопки стоят вплотную,
        // промахнуться легко, а другого способа отменить ответ нет.
        ex.feedback = '';
        ex.factualRpe = '';
        ex.failReason = '';
    } else {
        ex.feedback = kind;
        ex.factualRpe = info.rpe;
        if (kind !== 'failed') ex.failReason = '';
    }
    refreshRpeButton(dayIndex, exIndex);
    // Оценка поставлена — упражнение считается выполненным и сворачивается,
    // чтобы на экране помещалось сразу несколько. Снятие оценки раскрывает
    // его обратно. Ручное раскрытие сбрасываем, иначе карточка осталась бы
    // развёрнутой вопреки только что сделанному выбору.
    delete _exExpanded[dayIndex + '-' + exIndex];
    _syncExerciseCard(dayIndex, exIndex);
    if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
    if (ex.feedback === 'failed') openFailReasonModal(ex);
}

// ─── Под-модалка причины провала ───────────────────────────────────────
var failReasonCtx = null;
function openFailReasonModal(exercise) {
    failReasonCtx = exercise; // запомним прямую ссылку
    document.getElementById('fail-reason-modal').classList.remove('hidden');
}
function closeFailReasonModal() {
    document.getElementById('fail-reason-modal').classList.add('hidden');
    failReasonCtx = null;
}
function setFailReason(reason) {
    if (failReasonCtx) {
        failReasonCtx.failReason = reason;
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
    }
    closeFailReasonModal();
}

function handleInput(input) {
    var dayIndex = input.dataset.day;
    var exIndex = input.dataset.exercise;
    var field = input.dataset.field;
    // 2026-08-31 (H-2). Поля были type="number": браузер отвергал «40,5» ещё
    // до нашего кода — input.value отдавал пустоту, человек видел, как
    // введённый вес исчезает. По-русски десятичный разделитель — запятая, и
    // на телефонной клавиатуре она стоит рядом. Теперь поля текстовые, а
    // запятую приводим к точке и отсекаем лишние символы прямо при вводе.
    if (field === 'weight') {
        var w = String(input.value).replace(',', '.').replace(/[^0-9.]/g, '');
        var dot = w.indexOf('.');
        if (dot !== -1) w = w.slice(0, dot + 1) + w.slice(dot + 1).replace(/\./g, '');
        if (w !== input.value) input.value = w;
    } else if (field === 'reps') {
        var r = String(input.value).replace(/[^0-9]/g, '');
        if (r !== input.value) input.value = r;
    }
    var value = input.value;
    var exercise = workoutData[dayIndex].exercises[exIndex];
    if (field === 'weight') exercise.weightFact = value;
    else if (field === 'reps') exercise.repsFact = value;
    else if (field === 'comment') exercise.comment = value;
    if (value && (field === 'weight' || field === 'reps')) {
        input.classList.add('filled');
        if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred('light');
    } else {
        input.classList.remove('filled');
    }
    if (field === 'weight' || field === 'reps') {
        updateExerciseDelta(dayIndex, exIndex);
        var wasCompleted = exercise.completed;
        exercise.completed = !!(exercise.weightFact || exercise.repsFact);
        if (!wasCompleted && exercise.completed) {
            completedCount++;
            updateProgress(true);
        } else if (wasCompleted && !exercise.completed) {
            completedCount--;
            updateProgress(false);
        }
        // Обновляем счётчик дня в заголовке
        updateDayCounter(parseInt(dayIndex));
    }
}
 
function updateProgress(animate) {
    document.getElementById('completed-count').textContent = completedCount;
    document.getElementById('total-count').textContent = totalExercises;
    var percentage = totalExercises > 0 ? (completedCount / totalExercises) * 100 : 0;
    document.getElementById('progress-fill').style.width = percentage + '%';
    if (animate) {
        var progressInfo = document.querySelector('.progress-info');
        progressInfo.classList.add('pulse');
        setTimeout(function() { progressInfo.classList.remove('pulse'); }, 500);
        if (percentage === 100 && tg.HapticFeedback) {
            tg.HapticFeedback.notificationOccurred('success');
        }
    }
}
 
function updateDayCounter(dayIndex) {
    var day = workoutData[dayIndex];
    if (!day) return;
    var dayCompleted = 0;
    day.exercises.forEach(function(ex) {
        if (ex.weightFact || ex.repsFact) dayCompleted++;
    });
    var dayTotal = day.exercises.length;
    var dayDone = dayCompleted === dayTotal && dayTotal > 0;
    var header = document.querySelector('.day-header[data-day-index="' + dayIndex + '"]');
    if (header) {
        var counter = header.querySelector('.day-counter');
        if (counter) counter.textContent = dayCompleted + '/' + dayTotal;
        // Обновляем галочку
        // Разметка должна повторять ту, что собирает renderWorkout: иконки
        // Lucide, а не эмодзи и текстовый шеврон. Раньше здесь оставалась
        // старая версия, и после первого же ввода веса у карточки дня
        // пропадала стрелка и появлялась галочка-эмодзи.
        // Направление шеврона задаётся классом .collapsed на заголовке,
        // поэтому подменять его содержимое не нужно.
        var status = header.querySelector('.day-status');
        status.innerHTML =
            (dayDone ? '<span class="day-done">' + _homeIcon('check') + '</span>' : '') +
            '<span class="day-counter">' + dayCompleted + ' / ' + dayTotal + '</span>' +
            '<span class="day-chevron">' + _homeIcon('chevron') + '</span>';
    }
}

document.getElementById('save-btn').addEventListener('click', async function() {
    var exercisesToSave = [];
    var btn = document.getElementById('save-btn');
    // Раньше здесь запоминался и восстанавливался btn.textContent. С тех пор
    // у кнопки появилась иконка, и восстановление текстом стирало бы её —
    // работаем с разметкой целиком.
    var originalHtml = btn.innerHTML;
    btn.innerHTML = '<span>Сохранение…</span>';
    btn.classList.add('saving');
    btn.disabled = true;
    try {
        for (var d = 0; d < workoutData.length; d++) {
            for (var ex = 0; ex < workoutData[d].exercises.length; ex++) {
                var exercise = workoutData[d].exercises[ex];
                if (exercise.weightFact || exercise.repsFact || (exercise.comment && exercise.comment.trim())) {
                    // Если клиент не выставил фидбэк — считаем «норм» (RPE 7.5) по умолчанию
                    var fb = exercise.feedback || 'normal';
                    var fr = exercise.factualRpe || (RPE_FEEDBACK_MAP[fb] && RPE_FEEDBACK_MAP[fb].rpe) || 7.5;
                    exercisesToSave.push({
                        r: exercise.rowIndex,
                        w: exercise.weightFact || '',
                        p: exercise.repsFact || '',
                        c: (exercise.comment && exercise.comment.trim()) ? exercise.comment.trim() : '',
                        e: exercise.exercise,
                        s: exercise.sets,
                        rp: exercise.reps,
                        wp: exercise.weightPlan,
                        rpe: exercise.rpe,           // плановый RPE из шаблона
                        fb: fb,                      // feedback: easy/normal/hard/failed
                        fr: fr,                      // фактический RPE: 5.5/7.5/9/10
                        wn: sessionWellness,         // самочувствие сессии (good/tired/sick/pms)
                        fr2: exercise.failReason || '' // причина провала (sleep/illness/stress/food/too_hard)
                    });
                }
            }
        }
        if (exercisesToSave.length === 0) {
            tg.showAlert('Нечего сохранять! Заполни вес или повторы 📝');
        } else {
            var chatId = _myChatId();
            var completionPercent = totalExercises > 0 ? Math.round((completedCount / totalExercises) * 100) : 0;
            var url = APPS_SCRIPT_URL + '?action=write&chatId=' + chatId + '&completionPercent=' + completionPercent;
            var data = null;
            var lastError = '';
            // Дошла ли уже первая часть длинного запроса — чтобы повтор её не
            // отправлял ещё раз (см. ниже).
            var savedBatch1 = false;
            for (var attempt = 0; attempt < 3; attempt++) {
                try {
                    var encoded = encodeURIComponent(JSON.stringify(exercisesToSave));
                    var fullUrl = url + '&exercises=' + encoded;
                    var response;
                    if (fullUrl.length > 7500) {
                        // Длинный запрос не влезает в адрес — шлём двумя частями.
                        //
                        // 2026-08-22: раньше при повторе после сбоя обе части
                        // отправлялись заново — даже та, что уже дошла. У клиента
                        // с 10 упражнениями в истории оказывалось 20: одна и та
                        // же тренировка записана дважды (реальный случай,
                        // Александр, 21 августа). Запоминаем, какая часть уже
                        // прошла, и повторяем только непрошедшую.
                        var half = Math.ceil(exercisesToSave.length / 2);
                        if (!savedBatch1) {
                            var url1 = url + '&exercises=' + encodeURIComponent(JSON.stringify(exercisesToSave.slice(0, half)));
                            response = await fetch(url1);
                            var t1 = await response.text();
                            var d1 = null;
                            try { d1 = JSON.parse(t1); } catch (_) { d1 = null; }
                            if (!(d1 && d1.success)) throw new Error((d1 && d1.error) || 'Первая часть не сохранилась');
                            savedBatch1 = true;
                        }
                        var url2 = url + '&exercises=' + encodeURIComponent(JSON.stringify(exercisesToSave.slice(half)));
                        response = await fetch(url2);
                    } else {
                        response = await fetch(fullUrl);
                    }
                    var text = await response.text();
                    try {
                        data = JSON.parse(text);
                    } catch (parseErr) {
                        lastError = 'Ответ сервера не JSON: ' + text.substring(0, 100);
                        data = null;
                    }
                    if (data && data.success) break;
                    if (data && data.error) lastError = data.error;
                } catch (err) {
                    lastError = err.message || 'Сетевая ошибка';
                    console.log('Attempt ' + (attempt + 1) + ' failed: ' + lastError);
                    await new Promise(function(r) { setTimeout(r, 2000); });
                }
            }
            if (data && data.success) {
                btn.classList.remove('saving');
                btn.classList.add('success');
                btn.textContent = '✅ Сохранено!';
                selfHistoryLoaded = false;   // вкладка «История» перечитает свежие данные
                if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
                setTimeout(function() {
                    var alertMsg = 'Сохранено ' + exercisesToSave.length + ' упражнений! ✅';
                    if (completionPercent === 100) {
                        alertMsg += '\n\n🎉 Неделя выполнена на 100%! Тренеру придёт уведомление.';
                    }
                    tg.showAlert(alertMsg);
                    btn.classList.remove('success');
                    btn.innerHTML = originalHtml;
                }, 1000);
            } else {
                var errMsg = 'Не удалось сохранить ❌\n';
                if (lastError) errMsg += '\nПричина: ' + lastError;
                else if (data && data.error) errMsg += '\nПричина: ' + data.error;
                else errMsg += '\nСервер не ответил. Проверь интернет.';
                tg.showAlert(errMsg);
            }
        }
    } catch (error) {
        console.error('Save error:', error);
        tg.showAlert('Ошибка при сохранении ❌\n\n' + (error.message || 'Неизвестная ошибка'));
    } finally {
        setTimeout(function() {
            btn.classList.remove('saving', 'success');
            btn.innerHTML = originalHtml;
            btn.disabled = false;
        }, 1500);
    }
});
 
function openVideo(url, urlVk) {
    // Во VK свои ссылки на видео (обычно vk.com/video...), т.к. t.me-ссылки
    // там не откроешь без Telegram. Если для упражнения такая ссылка ещё не
    // добавлена в таблицу — просто используем старую (Telegram) ссылку.
    var target = (vkLaunchUserId && urlVk) ? urlVk : url;
    if (!target || target === '📽️') {
        tg.showAlert('Ссылка на видео отсутствует');
        return;
    }
    if (target.indexOf('t.me') !== -1) {
        tg.openTelegramLink(target);
        return;
    }
    if (target.indexOf('http') === -1) {
        tg.showAlert('Неверный формат ссылки');
        return;
    }
    // Открываем обычной ссылкой напрямую, без мостовых API (VKWebAppOpenLink
    // иногда молча отказывает на ссылки vk.com, а запасной window.open после
    // такого отказа браузер блокирует как всплывающее окно вне клика).
    var a = document.createElement('a');
    a.href = target;
    a.target = '_blank';
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}
 
var progressChart = null;
var historyData = [];
 
// Прокрутка страницы блокируется классом no-scroll, пока открыта модалка.
// Если модалка закрылась нештатно (ошибка внутри обработчика, закрытие
// системной кнопкой), класс остаётся — и страница «не листается вниз»,
// хотя визуально ничего не открыто. Снимаем блокировку, если на экране
// действительно не осталось ни одной видимой модалки.
function releaseScrollLockIfNothingOpen() {
    if (!document.body.classList.contains('no-scroll')) return;
    var open = document.querySelector(
        '.ex-editor-modal:not(.hidden), .rpe-modal:not(.hidden), .new-client-wizard:not(.hidden), ' +
        '.client-card-screen:not(.hidden)'
    );
    if (!open) document.body.classList.remove('no-scroll');
}

// История СВОИХ тренировок — клиентская вкладка. Тренер ту же историю видит
// в карточке клиента; рендер один и тот же, различается только контейнер и
// то, чей chatId спрашиваем.
var selfHistoryLoaded = false;

async function loadSelfHistory(force) {
    var container = document.getElementById('client-history-container');
    if (!container) return;
    if (selfHistoryLoaded && !force) return;
    container.innerHTML = '<div class="no-data">Загрузка истории...</div>';
    try {
        var chatId = _myChatId();
        var resp = await fetch(APPS_SCRIPT_URL + '?action=getSelfHistory&chatId=' + encodeURIComponent(chatId) + '&limit=60');
        var data = await resp.json();
        if (data.error) {
            container.innerHTML = '<div class="no-data">Не удалось загрузить историю</div>';
            return;
        }
        selfHistoryLoaded = true;
        renderClientHistory(data.history || [], 'client-history-container');
    } catch (e) {
        console.error('loadSelfHistory failed:', e);
        container.innerHTML = '<div class="no-data">Не удалось загрузить историю</div>';
    }
}

// Подписи мельче, когда вкладок много: у клиента их пять, у тренера шесть,
// у супер-админа семь — на телефоне «Тренировка» иначе обрезается.
function _syncTabsDensity() {
    var container = document.getElementById('tabs-container');
    if (!container) return;
    var visible = 0;
    container.querySelectorAll('.tab-btn').forEach(function(b) {
        if (!b.classList.contains('hidden')) visible++;
    });
    container.classList.toggle('tabs-6', visible >= 5);
}

function initializeTabs() {
    _syncTabsDensity();
    document.querySelectorAll('.tab-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var tabName = btn.dataset.tab;
            // Переключение вкладок — момент, когда точно ничего не открыто:
            // заодно снимаем блокировку прокрутки, если та где-то залипла.
            releaseScrollLockIfNothingOpen();
            document.querySelectorAll('.tab-btn').forEach(function(b) { b.classList.remove('active'); });
            btn.classList.add('active');
            document.querySelectorAll('.tab-content').forEach(function(content) { content.classList.remove('active'); });
            document.getElementById(tabName + '-tab').classList.add('active');
            // Баннер тренера показываем только на первой вкладке: на
            // остальных он съедал бы пол-экрана, а там нужен сам список.
            // На них вкладки уезжают наверх, как было раньше.
            _syncTenantBanner(tabName);
            if (tabName === 'progress') loadProgressData();
            if (tabName === 'history') loadSelfHistory();
            if (tabName === 'measurements') loadMeasurementsData();
            if (tabName === 'admin') { loadAdminClients(); loadDashboardData(); }
            if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred('light');
        });
    });

    // Кнопка "Начать тренировку" на главной — переключает на вкладку Тренировка
    var startBtn = document.getElementById('home-start-btn');
    if (startBtn) {
        startBtn.addEventListener('click', function() {
            var workoutTab = document.querySelector('.tab-btn[data-tab="workout"]');
            if (workoutTab) workoutTab.click();
        });
    }
}

// Главный экран: имя, неделя, кружки прогресса по дням, кнопка
function renderHome() {
    // Приветствие
    var displayName = clientName || (tg.initDataUnsafe && tg.initDataUnsafe.user && tg.initDataUnsafe.user.first_name) || '';
    document.getElementById('home-greet').textContent = displayName ? ('Привет, ' + displayName + '!') : 'Привет!';

    // Подзаголовок: процент готовности недели
    var pct = totalExercises > 0 ? Math.round(completedCount / totalExercises * 100) : 0;
    var subtitle;
    if (totalExercises === 0) {
        subtitle = 'На этой неделе тренировок ещё нет';
    } else if (pct === 0) {
        subtitle = 'Готов начать неделю? 💪';
    } else if (pct < 100) {
        subtitle = 'Неделя выполнена на ' + pct + '%';
    } else {
        subtitle = 'Неделя выполнена! 🎉';
    }
    document.getElementById('home-subtitle').textContent = subtitle;

    // Заголовок недели — показываем как есть (например «Месяц 2 Неделя 3»)
    document.getElementById('home-week-num').textContent = (weekTitle || '—').toString();

    // Карточки по дням: только реальные тренировочные дни (с упражнениями).
    var dotsContainer = document.getElementById('home-week-dots');
    dotsContainer.innerHTML = '';
    var trainingDays = workoutData.filter(function(d) {
        return d.exercises && d.exercises.length > 0;
    });
    var doneDays = 0;
    trainingDays.forEach(function(day) {
        var total = day.exercises.length;
        var done = 0;
        day.exercises.forEach(function(ex) {
            if (ex.weightFact || ex.repsFact) done++;
        });
        var dot = document.createElement('div');
        dot.className = 'home-dot';
        var status = '○'; // не начато
        if (total > 0 && done >= total) { dot.classList.add('full'); doneDays++; status = '✓'; }
        else if (done > 0) { dot.classList.add('partial'); status = '⏳'; }
        // Метка: первые 2 буквы названия дня без эмодзи
        var label = (day.day || '').toString()
            .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, '')
            .trim().substring(0, 2);
        dot.title = day.day + ': ' + done + '/' + total;
        dot.innerHTML = '<span class="home-dot-day">' + (label || '?') + '</span>' +
                        '<span class="home-dot-status">' + status + '</span>';
        dotsContainer.appendChild(dot);
    });

    document.getElementById('home-week-summary').textContent =
        doneDays + ' из ' + trainingDays.length + ' дней';

    _renderHomeUI(trainingDays, doneDays);
    loadHomeGoal();
}

// ── Оформление главной ─────────────────────────────────────────────────────
// Здесь только то, чего нет в данных готовым: инициалы для аватара, какая
// тренировка ближайшая, состояния дней и сводные плитки. Все числа считаются
// из уже загруженных workoutData / completedCount — новых запросов к серверу
// эта функция не делает и данные не меняет.
var _HOME_WD = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
var _HOME_ICONS = {
    check: '<path d="M20 6 9 17l-5-5"/>',
    // Часы со стрелкой назад (Lucide history) — блок «Прошлый раз» в карточке
    // упражнения ссылался на этот ключ, а его в наборе не было: в разметку
    // подставлялось undefined.
    history: '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
    chevron: '<path d="m6 9 6 6 6-6"/>',
    play: '<path d="M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z"/>',
    bulb: '<path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/>',
    comment: '<path d="M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z"/>',
    moon: '<path d="M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401"/>',
    thermometer: '<path d="M14 4v10.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0"/>',
    droplet: '<path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z"/>',
    smile: '<circle cx="12" cy="12" r="10"/><path d="M15 10V9"/><path d="M16.472 15a6 6 0 0 1-8.943 0"/><path d="M9 10V9"/>',
    x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
    image: '<rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>',
    hash: '<path d="M4 9h16"/><path d="M4 15h16"/><path d="M10 3 8 21"/><path d="M16 3l-2 18"/>',
    repeat: '<path d="m17 2 4 4-4 4"/><path d="M3 11v-1a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/><path d="M21 13v1a4 4 0 0 1-4 4H3"/>',
    weight: '<circle cx="12" cy="5" r="3"/><path d="M6.5 8a2 2 0 0 0-1.905 1.46L2.1 18.5A2 2 0 0 0 4 21h16a2 2 0 0 0 1.925-2.54L19.4 9.5A2 2 0 0 0 17.48 8Z"/>',
    dumbbell: '<path d="M17.596 12.768a2 2 0 1 0 2.829-2.829l-1.768-1.767a2 2 0 0 0 2.828-2.829l-2.828-2.828a2 2 0 0 0-2.829 2.828l-1.767-1.768a2 2 0 1 0-2.829 2.829z"/><path d="m2.5 21.5 1.4-1.4"/><path d="m20.1 3.9 1.4-1.4"/><path d="M5.343 21.485a2 2 0 1 0 2.829-2.828l1.767 1.768a2 2 0 1 0 2.829-2.829l-6.364-6.364a2 2 0 1 0-2.829 2.829l1.768 1.767a2 2 0 0 0-2.828 2.829z"/><path d="m9.6 14.4 4.8-4.8"/>',
    flame: '<path d="M12 3q1 4 4 6.5t3 5.5a1 1 0 0 1-14 0 5 5 0 0 1 1-3 1 1 0 0 0 5 0c0-2-1.5-3-1.5-5q0-2 2.5-4"/>',
    dashed: '<path d="M10.1 2.182a10 10 0 0 1 3.8 0"/><path d="M13.9 21.818a10 10 0 0 1-3.8 0"/><path d="M17.609 3.721a10 10 0 0 1 2.69 2.7"/><path d="M2.182 13.9a10 10 0 0 1 0-3.8"/><path d="M20.279 17.609a10 10 0 0 1-2.7 2.69"/><path d="M21.818 10.1a10 10 0 0 1 0 3.8"/><path d="M3.721 6.391a10 10 0 0 1 2.7-2.69"/><path d="M6.391 20.279a10 10 0 0 1-2.69-2.7"/>'
};

function _homeIcon(key) {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" ' +
           'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
           (_HOME_ICONS[key] || '') + '</svg>';
}

// Двухбуквенная метка дня — та же логика, что и у кружков недели
function _homeDayLabel(day) {
    return (day || '').toString()
        .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, '')
        .trim().substring(0, 2).toUpperCase();
}

function _renderHomeUI(trainingDays, doneDays) {
    var todayLabel = _HOME_WD[new Date().getDay()];

    _renderHomeAvatar();

    // Состояния дней: иконка вместо символа, плюс отметка «сегодня»
    var dots = document.querySelectorAll('#home-week-dots .home-dot');
    for (var i = 0; i < dots.length; i++) {
        var dot = dots[i];
        var st = dot.querySelector('.home-dot-status');
        if (st) {
            st.innerHTML = _homeIcon(dot.classList.contains('full') ? 'check' :
                                     dot.classList.contains('partial') ? 'flame' : 'dashed');
        }
        var lbl = dot.querySelector('.home-dot-day');
        if (lbl && lbl.textContent.trim().toUpperCase() === todayLabel) dot.classList.add('today');
    }

    // Ближайшая тренировка для карточки-героя
    var todayDay = null, nextDay = null;
    trainingDays.forEach(function(d) {
        var done = 0;
        d.exercises.forEach(function(ex) { if (ex.weightFact || ex.repsFact) done++; });
        if (_homeDayLabel(d.day) === todayLabel && !todayDay) todayDay = d;
        if (done < d.exercises.length && !nextDay) nextDay = d;
    });
    var pick = todayDay || nextDay;
    var whenEl = document.getElementById('home-hero-when');
    var titleEl = document.getElementById('home-hero-title');
    var descEl = document.getElementById('home-hero-desc');
    if (whenEl && titleEl && descEl) {
        if (!pick) {
            whenEl.textContent = trainingDays.length ? 'Неделя закрыта' : 'Пока пусто';
            titleEl.textContent = trainingDays.length ? 'Все тренировки выполнены' : 'Тренировок ещё нет';
            descEl.textContent = trainingDays.length ? 'Отличная работа' : 'Тренер скоро добавит план';
        } else {
            whenEl.textContent = todayDay ? 'Сегодня' : 'Ближайшая';
            // Убираем служебный префикс вида «ПН — », оставляем название
            titleEl.textContent = (pick.day || 'Тренировка').toString()
                .replace(/^[А-Яа-я]{2}\s*[—–-]\s*/, '').trim() || 'Тренировка';
            var n = pick.exercises.length;
            var word = (n % 10 === 1 && n % 100 !== 11) ? 'упражнение' :
                       (n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20)) ? 'упражнения' : 'упражнений';
            descEl.textContent = n + ' ' + word;
        }
    }

    // Плитки «Твои результаты» — счётчики по текущей неделе
    var pct = totalExercises > 0 ? Math.round(completedCount / totalExercises * 100) : 0;
    var wEl = document.getElementById('home-stat-workouts');
    if (wEl) {
        wEl.textContent = doneDays;
        document.getElementById('home-stat-workouts-sub').textContent =
            'из ' + trainingDays.length + ' на неделе';
    }
    var pEl = document.getElementById('home-stat-progress');
    if (pEl) {
        pEl.textContent = pct + '%';
        document.getElementById('home-stat-progress-sub').textContent =
            completedCount + ' из ' + totalExercises + ' упражнений';
    }
}

// Анкета клиента нужна в двух местах — для блока «Твоя цель» и для выбора
// показательного упражнения в карточке рекорда. Запрашиваем один раз и
// отдаём обоим один и тот же промис, чтобы не ходить на сервер дважды.
var _myProfilePromise = null;
function _getMyProfile() {
    if (!_myProfilePromise) {
        _myProfilePromise = fetch(APPS_SCRIPT_URL + '?action=getClientProfile&targetChatId=' + _myChatId())
            .then(function(r) { return r.json(); })
            .then(function(d) { return (d && (d.profile || d)) || {}; })
            .catch(function() { return {}; });
    }
    return _myProfilePromise;
}

// Кружок на главной. Если тренер загрузил своё фото — показываем его:
// клиент видит лицо СВОЕГО тренера, у каждого тенанта своё. Фото нет —
// остаётся первая буква имени клиента, как было раньше.
var _tenantAvatarUrl = '';

function _renderHomeAvatar() {
    var av = document.getElementById('home-avatar');
    if (!av) return;
    if (_tenantAvatarUrl) {
        av.classList.add('has-photo');
        av.innerHTML = '<img src="' + _escHtmlAttr(_tenantAvatarUrl) + '" alt="" ' +
                       'onerror="_onHomeAvatarError()">';
        return;
    }
    av.classList.remove('has-photo');
    var letter = (clientName || '').replace(/[^A-Za-zА-Яа-яЁё]/g, '').charAt(0);
    av.textContent = (letter || '?').toUpperCase();
}

// Картинка не загрузилась (удалили из базы, нет сети) — не оставляем пустой
// кружок, откатываемся на букву.
function _onHomeAvatarError() {
    _tenantAvatarUrl = '';
    _renderHomeAvatar();
}

// Показательное упражнение для карточки рекорда: у женщин — ягодичный
// мостик, у мужчин — жим лёжа. Если клиент его не делал, карточка
// возвращается к прежнему поведению и показывает самый тяжёлый результат.
function _showcaseExercisePattern(gender) {
    var g = String(gender || '').toLowerCase();
    var male = /^m|муж/.test(g);
    return male ? /жим.*л[еёe]ж/i : /ягодичн|мостик/i;
}

// Мини-график динамики для карточек «Последний рекорд» и «Текущий вес».
// Рисуем инлайн-SVG сами: Chart.js для полоски 40px высотой избыточен, а
// каждая его копия — это ещё один canvas и обработчики.
//
// Значения приходят как есть; сглаживание — обычная кривая Безье между
// соседними точками. Один ряд, поэтому цвет акцентный (DESIGN.md, раздел 12).
function _sparkline(values) {
    var pts = (values || []).map(Number).filter(function(v) { return isFinite(v); });
    if (pts.length < 2) return '';
    // По горизонтали отступ больше, чем по вертикали: график растянут во всю
    // ширину карточки, и без запаса точка на конце упиралась бы в край.
    var W = 100, H = 34, PX = 7, PY = 4;
    var min = Math.min.apply(null, pts), max = Math.max.apply(null, pts);
    var span = (max - min) || 1;
    var xy = pts.map(function(v, i) {
        return [PX + i * (W - 2 * PX) / (pts.length - 1),
                H - PY - (v - min) / span * (H - 2 * PY)];
    });
    var d = 'M' + xy[0][0].toFixed(1) + ' ' + xy[0][1].toFixed(1);
    for (var i = 1; i < xy.length; i++) {
        var p0 = xy[i - 1], p1 = xy[i], cx = (p0[0] + p1[0]) / 2;
        d += ' C' + cx.toFixed(1) + ' ' + p0[1].toFixed(1) +
             ' ' + cx.toFixed(1) + ' ' + p1[1].toFixed(1) +
             ' ' + p1[0].toFixed(1) + ' ' + p1[1].toFixed(1);
    }
    var area = d + ' L' + xy[xy.length - 1][0].toFixed(1) + ' ' + H +
               ' L' + xy[0][0].toFixed(1) + ' ' + H + ' Z';
    var gid = 'spk' + Math.random().toString(36).slice(2, 8);
    var last = xy[xy.length - 1];
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none" aria-hidden="true">' +
        '<defs><linearGradient id="' + gid + '" x1="0" y1="0" x2="0" y2="1">' +
            '<stop offset="0" stop-color="currentColor" stop-opacity=".22"/>' +
            '<stop offset="1" stop-color="currentColor" stop-opacity="0"/>' +
        '</linearGradient></defs>' +
        '<path d="' + area + '" fill="url(#' + gid + ')"/>' +
        '<path d="' + d + '" fill="none" stroke="currentColor" stroke-width="2" ' +
            'stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke"/>' +
        '<circle cx="' + last[0].toFixed(1) + '" cy="' + last[1].toFixed(1) + '" r="2.6" ' +
            'fill="currentColor" vector-effect="non-scaling-stroke"/>' +
    '</svg>';
}

// Подпись изменения: направление словом и цветом, без эмодзи.
function _trendDelta(el, diff, unit, lowerIsBetter) {
    if (!el) return;
    if (!isFinite(diff) || diff === 0) { el.textContent = ''; el.className = 'home-trend-delta'; return; }
    var good = lowerIsBetter ? diff < 0 : diff > 0;
    el.textContent = (diff > 0 ? '+' : '') + diff.toFixed(1) + ' ' + unit;
    el.className = 'home-trend-delta ' + (good ? 'trend-good' : 'trend-bad');
}

// Блок «Твоя цель». Цель берётся из анкеты клиента существующей ручкой —
// новых серверных методов не добавляем. Если анкета не заполнена или запрос
// не прошёл, блок просто не показывается: выдуманной цели быть не должно.
async function loadHomeGoal() {
    var box = document.getElementById('home-goal');
    if (!box) return;
    try {
        var prof = await _getMyProfile();
        var labels = { loss: 'Похудение', mass: 'Набор массы', tone: 'Тонус и поддержание', strength: 'Сила' };
        var goal = labels[prof.goal] || prof.goal || '';
        if (!goal) return;

        // Процент — выполнение текущей недели. Отдельного показателя
        // «продвижение к цели» в системе нет, поэтому подпись прямо говорит,
        // что именно посчитано.
        var pct = totalExercises > 0 ? Math.round(completedCount / totalExercises * 100) : 0;
        document.getElementById('home-goal-name').textContent = goal;
        document.getElementById('home-goal-pct').textContent = pct + '%';
        document.getElementById('home-goal-fill').style.width = pct + '%';
        document.getElementById('home-goal-msg').textContent =
            pct >= 100 ? 'Неделя выполнена полностью. Так держать!' :
            pct > 0    ? 'Неделя выполнена на ' + pct + '%. Ты движешься к цели.' :
                         'Неделя ещё впереди — начни с первой тренировки.';
        box.classList.remove('hidden');
    } catch (e) { /* анкета не обязательна — блок остаётся скрытым */ }
}

// Подгружает рекорды и текущий вес для карточек на главной — асинхронно, не блокирует UI
async function loadHomeExtras() {
    var chatId = _myChatId();
    try {
        // Последний рекорд
        var histRes = await fetch(APPS_SCRIPT_URL + '?action=history&chatId=' + chatId);
        var histJson = await histRes.json();
        var history = histJson.history || [];
        if (history.length) {
            // Чистим имена и ищем максимум по каждому упражнению
            var bestByEx = {};
            history.forEach(function(d) {
                var name = cleanExerciseName(d.exercise);
                var w = parseFloat(d.weight) || 0;
                if (!bestByEx[name] || w > bestByEx[name].weight) {
                    bestByEx[name] = { weight: w, date: d.date };
                }
            });
            // Сначала ищем показательное упражнение по полу из анкеты.
            var profile = await _getMyProfile();
            var want = _showcaseExercisePattern(profile.gender);
            var topName = '', topW = 0, topDate = '';
            for (var k in bestByEx) {
                if (want.test(k)) { topW = bestByEx[k].weight; topName = k; topDate = bestByEx[k].date; break; }
            }
            // Не нашли — как и раньше, показываем самый тяжёлый результат.
            if (!topName) {
                for (var k2 in bestByEx) {
                    if (bestByEx[k2].weight > topW) {
                        topW = bestByEx[k2].weight; topName = k2; topDate = bestByEx[k2].date;
                    }
                }
            }
            if (topW > 0) {
                document.getElementById('home-last-pr').textContent = topW + ' кг';
                document.getElementById('home-last-pr-sub').textContent = topName;
                // График: как рос вес именно в этом упражнении. Данные уже
                // загружены выше, дополнительный запрос не нужен.
                var series = history
                    .filter(function(d) { return cleanExerciseName(d.exercise) === topName; })
                    .map(function(d) { return parseFloat(d.weight) || 0; })
                    .filter(function(w) { return w > 0; });
                var spark = document.getElementById('home-pr-spark');
                if (spark) spark.innerHTML = _sparkline(series);
                if (series.length >= 2) {
                    _trendDelta(document.getElementById('home-last-pr-delta'),
                                series[series.length - 1] - series[0], 'кг', false);
                }
            }
        }
    } catch (e) { console.warn('home extras (history) fail:', e); }

    try {
        // Текущий вес — последний замер
        var measRes = await fetch(APPS_SCRIPT_URL + '?action=getMeasurements&chatId=' + chatId);
        var measJson = await measRes.json();
        var meas = measJson.measurements || [];
        if (meas.length) {
            var last = meas[meas.length - 1];
            if (last.weight) {
                document.getElementById('home-weight').textContent = last.weight + ' кг';
                var wSeries = meas.map(function(m) { return parseFloat(m.weight) || 0; })
                                  .filter(function(w) { return w > 0; });
                var wSpark = document.getElementById('home-weight-spark');
                if (wSpark) wSpark.innerHTML = _sparkline(wSeries);
                if (meas.length >= 2) {
                    var prev = meas[meas.length - 2];
                    if (prev.weight) {
                        // Раньше здесь были эмодзи 📈📉➡️. Направление теперь
                        // показывает цвет: для веса снижение — хорошая динамика.
                        var diff = (parseFloat(last.weight) - parseFloat(prev.weight));
                        document.getElementById('home-weight-sub').textContent = 'с прошлого замера';
                        _trendDelta(document.getElementById('home-weight-delta'), diff, 'кг', true);
                    }
                }
            }
        }
    } catch (e) { console.warn('home extras (meas) fail:', e); }
}
 
async function loadProgressData() {
    try {
        var chatId = _myChatId();
        var statsUrl = APPS_SCRIPT_URL + '?action=progress&chatId=' + chatId;
        var statsResponse = await fetch(statsUrl);
        var stats = await statsResponse.json();
        document.getElementById('stat-weeks').textContent = stats.weeksCompleted || 0;
        document.getElementById('stat-exercises').textContent = stats.totalExercises || 0;
        document.getElementById('stat-avg-weight').textContent = (stats.avgWeight || 0) + ' кг';
        await loadExerciseHistory();
    } catch (error) {
        console.error('Progress load error:', error);
    }
}
 
function getMuscleGroup(exerciseName) {
    var name = exerciseName.toLowerCase();

    // ── Специфические упражнения с уникальными названиями (проверяем первыми,
    //    чтобы общие шаблоны не перехватили их в неправильную группу) ──
    if (/румынск/i.test(name)) return 'Ноги';        // румынская тяга — задняя поверхность бедра
    if (/мёртв|мертв/i.test(name)) return 'Ноги';    // мёртвая тяга
    if (/гиперэкс|гипер\s*экс|hyper/i.test(name)) return 'Спина';
    if (/колодец|пек.*дек|peck.*deck/i.test(name)) return 'Спина';
    if (/франц/i.test(name)) return 'Трицепс';       // французский жим
    if (/калифорний/i.test(name)) return 'Трицепс';  // калифорнийский жим
    if (/гудмор|good\s*morning|накл[оё]н\s*со\s*штангой/i.test(name)) return 'Ноги';

    // Грудь
    if (/жим.*(л[её]ж|горизонт|наклон|смит|гильот|крс|кроссовер|жим.*узк|узк\w*\s*хват)|разводк|кроссовер|сведен.*рук|бабочка|отжим|жим.*верх\s*груд|жим.*низ\s*груд|жим.*гантел|жим.*штанг.*груд/i.test(name)) return 'Грудь';
    // Ноги (проверяем РАНЬШЕ Спины — чтобы «отведение/приведение ног», «выпад» и т.д. не уходили в спину)
    if (/присед|жим.*платформ|жим.*ног|выпад|разгиб.*ног|сгиб.*ног|икр|голен|гак|станов|отведен.*ног|приведен.*ног|ягодиц|махи.*ног|болгарск|sissy/i.test(name)) return 'Ноги';
    // Спина
    if (/тяг.*(верхн|нижн|горизонт|блок|штанг|гантел|канат|узк|шир|т-?гриф|сумо|становая)|подтяг|пуловер|рычаж|шраг/i.test(name)) return 'Спина';
    // Плечи
    if (/жим.*(сид|стоя|арнольд|плеч|штанг.*стоя)|мах|тяг.*подбородк|разводк.*стоя|дельт|протяжк|шраги.*стоя/i.test(name)) return 'Плечи';
    // Бицепс
    if (/бицепс|сгиб.*рук|молот|концентр|скотт/i.test(name)) return 'Бицепс';
    // Трицепс
    if (/трицепс|разгиб.*(рук|канат|гантел|штанг|из.*голов|на\s*блоке|на\s*трицепс)|жим.*узк|отжим.*брус|кикбэк|kickback/i.test(name)) return 'Трицепс';
    // Пресс
    if (/пресс|скруч|подъ[её]м.*ног|планк|вакуум|велосипед/i.test(name)) return 'Пресс';
    return 'Другое';
}

async function loadExerciseHistory() {
    try {
        var chatId = _myChatId();
        var url = APPS_SCRIPT_URL + '?action=history&chatId=' + chatId;
        var response = await fetch(url);
        var data = await response.json();
        if (data.error) {
            console.error('History error:', data.error);
            historyData = [];
            return;
        }
        historyData = data.history || [];
        // Чистим названия от "Сет:"
        historyData.forEach(function(d) {
            d.exercise = cleanExerciseName(d.exercise);
        });

        // Собираем уникальные упражнения
        var exercises = [];
        historyData.forEach(function(d) {
            if (exercises.indexOf(d.exercise) === -1) exercises.push(d.exercise);
        });

        // Группируем по мышцам
        var groups = {};
        var groupOrder = ['Грудь', 'Спина', 'Ноги', 'Плечи', 'Бицепс', 'Трицепс', 'Пресс', 'Другое'];
        exercises.forEach(function(ex) {
            var group = getMuscleGroup(ex);
            if (!groups[group]) groups[group] = [];
            groups[group].push(ex);
        });

        var select = document.getElementById('exercise-select');
        select.innerHTML = '<option value="">Выберите упражнение...</option>';
        groupOrder.forEach(function(groupName) {
            if (!groups[groupName] || groups[groupName].length === 0) return;
            var optgroup = document.createElement('optgroup');
            // Раньше к названию группы приклеивался эмодзи. В интерфейсе
            // эмодзи не используем, а в нативном списке они к тому же
            // выглядят по-разному на iPhone и Android.
            optgroup.label = groupName;
            groups[groupName].sort().forEach(function(ex) {
                var option = document.createElement('option');
                option.value = ex;
                option.textContent = ex;
                optgroup.appendChild(option);
            });
            select.appendChild(optgroup);
        });

        select.addEventListener('change', function(e) {
            if (e.target.value) renderChart(e.target.value);
        });
        renderRecords();
    } catch (error) {
        console.error('History load error:', error);
        historyData = [];
    }
}
 
function formatDate(dateStr) {
    if (!dateStr) return '';
    // Если уже в формате dd.MM.yyyy — возвращаем как есть
    if (/^\d{2}\.\d{2}\.\d{4}/.test(dateStr)) return dateStr.substring(0, 10);
    // Если "dd.MM.yyyy HH:mm" — берём только дату
    if (/^\d{2}\.\d{2}\.\d{4}\s/.test(dateStr)) return dateStr.split(' ')[0];
    // Если ISO формат или другой — пробуем распарсить
    try {
        var d = new Date(dateStr);
        if (!isNaN(d.getTime())) {
            var dd = ('0' + d.getDate()).slice(-2);
            var mm = ('0' + (d.getMonth() + 1)).slice(-2);
            return dd + '.' + mm + '.' + d.getFullYear();
        }
    } catch (e) {}
    return String(dateStr);
}

function renderChart(exerciseName) {
    var data = historyData.filter(function(d) { return d.exercise === exerciseName; });
    if (data.length === 0) return;
    if (progressChart) progressChart.destroy();
    var ctx = document.getElementById('progress-chart').getContext('2d');

    // Цвет ЛИНИИ ДАННЫХ — не петроль. Интерфейс вокруг акцентный, а сама
    // кривая должна читаться как данные, а не как ещё один элемент
    // управления. Синий заметно отличается от петроля и не попадает под
    // запреты (золото/жёлтый/фиолетовый/красный).
    var LINE = '#2F6BB5';
    var fill = ctx.createLinearGradient(0, 0, 0, 220);
    fill.addColorStop(0, 'rgba(47,107,181,.20)');
    fill.addColorStop(1, 'rgba(47,107,181,0)');
    var FONT = { family: 'Inter, -apple-system, sans-serif', size: 11, weight: '600' };

    progressChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.map(function(d) { return formatDate(d.date); }),
            datasets: [{
                label: 'Вес (кг)',
                data: data.map(function(d) { return d.weight; }),
                borderColor: LINE,
                backgroundColor: fill,
                borderWidth: 2.5,
                fill: true,
                tension: 0.4,
                pointRadius: 3.5,
                pointBackgroundColor: LINE,
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointHoverRadius: 6,
                pointHoverBorderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: { duration: 400, easing: 'easeOutQuart' },
            layout: { padding: { top: 8, right: 4 } },
            interaction: { intersect: false, mode: 'index' },
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: '#1E2126',
                    titleColor: 'rgba(255,255,255,.62)',
                    bodyColor: '#fff',
                    titleFont: { family: FONT.family, size: 11, weight: '600' },
                    bodyFont: { family: FONT.family, size: 13, weight: '700' },
                    padding: { top: 6, bottom: 6, left: 10, right: 10 },
                    cornerRadius: 8,
                    displayColors: false,
                    caretSize: 0
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    border: { display: false },
                    // Горизонтальную сетку убираем, вертикальную оставляем —
                    // так задано в DESIGN.md, раздел 12.
                    grid: { display: false },
                    ticks: {
                        padding: 6,
                        color: '#A0A4AB',
                        font: FONT,
                        callback: function(value) { return value + ' кг'; }
                    }
                },
                x: {
                    border: { display: false },
                    grid: { color: '#F0F0F3', drawTicks: false },
                    ticks: { padding: 6, color: '#A0A4AB', font: FONT, maxRotation: 0, autoSkipPadding: 12 }
                }
            }
        }
    });
    if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred('light');
}
 
function renderRecords() {
    var recordsList = document.getElementById('records-list');
    var records = {};
    historyData.forEach(function(d) {
        if (!records[d.exercise] || d.weight > records[d.exercise].weight) {
            records[d.exercise] = d;
        }
    });
    var top5 = Object.values(records).sort(function(a, b) { return b.weight - a.weight; }).slice(0, 5);
    if (top5.length === 0) {
        recordsList.innerHTML = '<div class="no-data">Пока нет данных о рекордах<br><br>Заполни несколько тренировок!</div>';
        return;
    }
    // Медали-эмодзи заменены на номер места: тот же порядок, та же пятёрка,
    // те же значения — меняется только вид.
    recordsList.innerHTML = top5.map(function(record, index) {
        return '<div class="record-item' + (index === 0 ? ' record-top' : '') + '">' +
            '<div class="record-rank">' + (index + 1) + '</div>' +
            '<div class="record-name">' + _escHtml(cleanExerciseName(record.exercise)) + '</div>' +
            '<div class="record-weight">' + record.weight + ' кг</div>' +
        '</div>';
    }).join('');
}

// ========== СКРЫТИЕ КЛАВИАТУРЫ ==========
// Тап вне input/textarea скрывает клавиатуру
document.addEventListener('click', function(e) {
    var tag = e.target.tagName.toLowerCase();
    if (tag !== 'input' && tag !== 'textarea' && tag !== 'select') {
        document.activeElement.blur();
    }
});

// Enter на input — скрывает клавиатуру
document.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && e.target.tagName.toLowerCase() === 'input') {
        e.target.blur();
    }
});

// ========== ADMIN DASHBOARD ==========

var dashboardClients = [];
var currentFilter = 'all';

function initAdminTab() {
    var chatId = _myChatId();
    if (isTrainer(chatId)) {
        document.getElementById('admin-tab-btn').classList.remove('hidden');
        _syncTabsDensity();
        initFilters();
        initAdminClientsControls();
        initAdminSectionTabs();
        initClientCardTabs();
        initExerciseEditor();
        initAddTypeDialog();
        initBlockModal();
        initNewClientPlatformToggle();
        initExerciseMediaLibrary();
    }
}

// Переключатель VK / Telegram в форме нового клиента — меняет подпись, плейсхолдер
// и подсказку под полем chat_id в зависимости от выбранной платформы.
function _updateNcChatIdLabel() {
    var platform = _ncSelectedPlatform();
    var label = document.getElementById('nc-chatid-label');
    var hint = document.getElementById('nc-chatid-hint');
    var input = document.getElementById('nc-chatid');
    if (!label || !hint || !input) return;
    if (platform === 'telegram') {
        label.textContent = 'Telegram chat_id *';
        input.placeholder = '739299264';
        hint.textContent = 'Спроси у клиента — он узнает через @userinfobot в Telegram';
    } else {
        label.textContent = 'ID клиента ВКонтакте *';
        input.placeholder = '123456789';
        hint.textContent = 'Из ссылки на профиль: vk.com/id123456789 → 123456789. Если у клиента короткое имя (vk.com/ivan_petrov) — попроси переслать в сообщения группы любое сообщение, id придёт в уведомлении.';
    }
}

function _ncSelectedPlatform() {
    var checked = document.querySelector('input[name="nc-platform"]:checked');
    return checked ? checked.value : 'vk';
}

function initNewClientPlatformToggle() {
    document.querySelectorAll('input[name="nc-platform"]').forEach(function(el) {
        el.addEventListener('change', _updateNcChatIdLabel);
    });
}

// Супер-админка — список ВСЕХ тренеров (не только текущего тенанта). Видна
// только буквально Matvey (хардкод TRAINER_CHAT_ID/TRAINER_VK_CHAT_ID), а не
// tenantTrainerChatId — иначе тренер, тестирующий своё демо, тоже бы её увидел.
var SUPERADMIN_STATUS_LABELS = { active: 'Активен', demo: 'Демо', disabled: 'Отключён' };

function isMatveySuperAdmin(chatId) {
    return chatId === TRAINER_CHAT_ID || chatId === TRAINER_VK_CHAT_ID;
}

function initSuperAdminTab() {
    var chatId = _myChatId();
    if (!isMatveySuperAdmin(chatId)) return;
    document.getElementById('superadmin-tab-btn').classList.remove('hidden');
    _syncTabsDensity();
    loadSuperAdminTrainers();

    // Открыт чужой тенант (?vk_group_id=...) — показываем баннер, чтобы не
    // перепутать, чью админку сейчас видно.
    if (CURRENT_TRAINER_ID) {
        document.getElementById('superadmin-view-id').textContent = CURRENT_TRAINER_ID;
        document.getElementById('superadmin-view-banner').classList.remove('hidden');
    }
}

function exitTrainerView() {
    window.location.search = '';
}

var SUPERADMIN_PAYMENT_LABELS = {
    active: 'Оплачено', expiring_week: 'Истекает <7д', expiring_soon: 'Истекает <3д', expired: 'Не оплачено'
};

async function loadSuperAdminTrainers() {
    var chatId = _myChatId();
    var container = document.getElementById('superadmin-trainers-list');
    try {
        var resp = await fetch(APPS_SCRIPT_URL + '?action=getTrainersOverview&chatId=' + encodeURIComponent(chatId));
        var data = await resp.json();
        if (data.error) {
            container.innerHTML = '<div class="no-data">Ошибка: ' + data.error + '</div>';
            return;
        }
        var trainers = data.trainers || [];
        try {
            var payResp = await fetch(APPS_SCRIPT_URL + '?action=getTrainerPayments&chatId=' + encodeURIComponent(chatId));
            var payData = await payResp.json();
            var payMap = {};
            (payData.payments || []).forEach(function(p) { payMap[p.trainerId] = p; });
            trainers.forEach(function(t) { t.payment = payMap[t.trainerId] || null; });
        } catch (_) {} // статус оплаты необязателен — список тренеров важнее
        renderSuperAdminTrainers(trainers);
    } catch (e) {
        container.innerHTML = '<div class="no-data">Не удалось загрузить</div>';
    }
}

function renderSuperAdminTrainers(trainers) {
    var container = document.getElementById('superadmin-trainers-list');
    if (!trainers.length) {
        container.innerHTML = '<div class="no-data">Тренеров пока нет</div>';
        return;
    }
    container.innerHTML = trainers.map(function(t) {
        var statusLabel = SUPERADMIN_STATUS_LABELS[t.status] || t.status || '—';
        var isDisabled = t.status === 'disabled';
        var expiresLine = t.demoExpiresAt
            ? ('<div class="superadmin-trainer-meta">Демо до: ' + new Date(t.demoExpiresAt).toLocaleString('ru-RU') + '</div>')
            : '';
        var name = (t.displayName || t.trainerId || '').toString();
        var sheetLink = t.spreadsheetId
            ? ('<a class="superadmin-sheet-link" href="https://docs.google.com/spreadsheets/d/' + t.spreadsheetId + '" target="_blank" onclick="event.stopPropagation()">📊 Таблица</a>')
            : '';
        // У демо своей VK-группы нет — открываем по его собственному
        // идентификатору, мини-апп принимает и такой (см. _newApiTrainerId).
        var openAsId = t.vkGroupId || t.trainerId;
        var openAsBtn = openAsId
            ? ('<button class="superadmin-openas-btn" onclick="openAsTrainer(\'' + openAsId + '\')">🔎 Открыть как тренер</button>')
            : '';
        var p = t.payment;
        var paymentLabel = p ? (SUPERADMIN_PAYMENT_LABELS[p.status] || p.status) : 'Нет оплат';
        var paymentClass = p ? p.status : 'expired';
        var paymentMeta = p ? (' · до ' + p.endDate + ' (' + p.daysLeft + ' дн.)') : '';
        return (
            '<div class="superadmin-trainer-row">' +
                '<div class="superadmin-trainer-info">' +
                    '<div class="superadmin-trainer-name">' + _escHtml(name) + '</div>' +
                    '<div class="superadmin-trainer-meta">ID: ' + _escHtml(t.trainerId) +
                        (t.vkGroupId ? (' · группа ' + t.vkGroupId) : '') + '</div>' +
                    expiresLine +
                    '<span class="superadmin-status-badge status-' + (t.status || '') + '">' + statusLabel + '</span>' +
                    '<span class="superadmin-status-badge payment-' + paymentClass + '">💰 ' + paymentLabel + paymentMeta + '</span>' +
                    sheetLink + openAsBtn +
                '</div>' +
                '<div class="superadmin-trainer-actions">' +
                    '<button class="superadmin-pay-btn" onclick="openTrainerPaymentModal(\'' + t.trainerId + '\', \'' + name.replace(/'/g, "\\'") + '\')">💰 Оплата</button>' +
                    '<button class="superadmin-toggle-btn" onclick="pickTrainerLogo(\'' + t.trainerId + '\')">' +
                        (t.themeLogo ? '🖼 Сменить баннер' : '🖼 Баннер') +
                    '</button>' +
                    (t.themeLogo ? '<button class="superadmin-toggle-btn" onclick="removeTrainerLogo(\'' + t.trainerId + '\')">✕ Убрать баннер</button>' : '') +
                    '<button class="superadmin-toggle-btn" onclick="pickTrainerAvatar(\'' + t.trainerId + '\')">' +
                        (t.themeAvatar ? '👤 Сменить фото' : '👤 Фото') +
                    '</button>' +
                    (t.themeAvatar ? '<button class="superadmin-toggle-btn" onclick="removeTrainerAvatar(\'' + t.trainerId + '\')">✕ Убрать фото</button>' : '') +
                    '<button class="superadmin-toggle-btn" onclick="cycleTrainerTheme(\'' + t.trainerId + '\', \'' + (t.themeMode || '') + '\')">' +
                        THEME_LABELS[t.themeMode || ''] +
                    '</button>' +
                    '<button class="superadmin-toggle-btn' + (isDisabled ? ' is-disabled' : '') +
                        '" onclick="toggleTrainerStatus(\'' + t.trainerId + '\', \'' + (isDisabled ? 'active' : 'disabled') + '\')">' +
                        (isDisabled ? 'Включить' : 'Отключить') +
                    '</button>' +
                '</div>' +
            '</div>'
        );
    }).join('');
}

var currentPaymentTrainer = null;

// Баннер тренера — картинка в шапке мини-аппа. Файл сжимаем прямо в
// браузере (как фото упражнений) и кладём в базу: диск у приложения
// временный, файлы на нём не переживают выкатку.
function pickTrainerLogo(trainerId) {
    var input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = function() {
        var file = input.files && input.files[0];
        if (!file) return;
        // Баннер широкий и невысокий, поэтому сторона больше, чем у фото
        // упражнений — иначе надпись на нём становится нечитаемой.
        _compressImageFile(file, 1600, 0.85, function(res) {
            _sendTrainerLogo(trainerId, { logoBase64: res.base64, logoMime: res.mime }, 'Баннер обновлён');
        }, function(err) { tg.showAlert(err); });
    };
    input.click();
}

function removeTrainerLogo(trainerId) {
    tgConfirm('Убрать баннер у этого тренера?').then(function(ok) {
        if (ok) _sendTrainerLogo(trainerId, { remove: true }, 'Баннер убран');
    });
}

async function _sendTrainerLogo(trainerId, payload, okText) {
    try {
        var url = APPS_SCRIPT_URL + '?action=setTrainerLogo&targetTrainerId=' + encodeURIComponent(trainerId);
        var resp = await fetch(url, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
        });
        var data = await resp.json();
        if (!data.success) { tg.showAlert('Ошибка: ' + (data.error || 'не удалось')); return; }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        await loadSuperAdminTrainers();
        tg.showAlert('✅ ' + okText + '. Тренеру и его клиентам нужно закрыть и открыть мини-апп заново.');
    } catch (e) {
        tg.showAlert('Ошибка соединения');
    }
}

// Фото тренера — кружок на главной у его клиентов. Отдельно от баннера:
// баннер широкий, в круглый аватар не годится. Сжимаем до 400px — больше
// для кружка 44px не нужно даже на экранах с тройной плотностью.
function pickTrainerAvatar(trainerId) {
    var input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = function() {
        var file = input.files && input.files[0];
        if (!file) return;
        _compressImageFile(file, 400, 0.85, function(res) {
            _sendTrainerAvatar(trainerId, { avatarBase64: res.base64, avatarMime: res.mime }, 'Фото обновлено');
        }, function(err) { tg.showAlert(err); });
    };
    input.click();
}

function removeTrainerAvatar(trainerId) {
    tgConfirm('Убрать фото у этого тренера? В кружке снова будет буква.').then(function(ok) {
        if (ok) _sendTrainerAvatar(trainerId, { remove: true }, 'Фото убрано');
    });
}

async function _sendTrainerAvatar(trainerId, payload, okText) {
    try {
        var url = APPS_SCRIPT_URL + '?action=setTrainerAvatar&targetTrainerId=' + encodeURIComponent(trainerId);
        var resp = await fetch(url, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
        });
        var data = await resp.json();
        if (!data.success) { tg.showAlert('Ошибка: ' + (data.error || 'не удалось')); return; }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        await loadSuperAdminTrainers();
        tg.showAlert('✅ ' + okText + '. Тренеру и его клиентам нужно закрыть и открыть мини-апп заново.');
    } catch (e) {
        tg.showAlert('Ошибка соединения');
    }
}

// Темы тенанта. Порядок в списке — порядок перебора по кнопке в
// супер-админке: каждое нажатие переводит тренера к следующей.
var THEME_ORDER = ['', 'dark', 'sand'];
var THEME_LABELS = { '': '🎨 Светлая', 'dark': '🎨 Тёмная', 'sand': '🎨 Бежевая' };
// Акцент, который ставится вместе с темой. У тёмной он яркий (иначе на
// чёрном заголовки не читаются), у бежевой — почти чёрный: там главная
// кнопка тёмная, а не цветная.
var THEME_ACCENTS = { '': '', 'dark': '#e53935', 'sand': '#2a2521' };

async function cycleTrainerTheme(trainerId, currentMode) {
    var next = THEME_ORDER[(THEME_ORDER.indexOf(currentMode || '') + 1) % THEME_ORDER.length];
    var ok = await tgConfirm('Переключить тему тренера на «' +
        THEME_LABELS[next].replace('🎨 ', '') + '»?');
    if (!ok) return;
    try {
        var qs = 'action=setTrainerTheme&targetTrainerId=' + encodeURIComponent(trainerId) +
            '&themeMode=' + encodeURIComponent(next) +
            (THEME_ACCENTS[next] ? '&themePrimary=' + encodeURIComponent(THEME_ACCENTS[next]) : '');
        var resp = await fetch(APPS_SCRIPT_URL + '?' + qs);
        var data = await resp.json();
        if (!data.success) { tg.showAlert('Ошибка: ' + (data.error || 'не удалось')); return; }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        await loadSuperAdminTrainers();
        tg.showAlert('Тема: ' + THEME_LABELS[next].replace('🎨 ', '') +
            '. Тренеру и его клиентам нужно закрыть и открыть мини-апп заново.');
    } catch (e) {
        tg.showAlert('Ошибка соединения');
    }
}

function openTrainerPaymentModal(trainerId, displayName) {
    currentPaymentTrainer = { trainerId: trainerId, name: displayName };
    document.getElementById('trainer-payment-modal-title').textContent = '💰 Оплата — ' + displayName;
    document.getElementById('tp-amount').value = '';
    document.getElementById('tp-months').value = '1';
    document.getElementById('tp-comment').value = '';
    var btn = document.getElementById('tp-save-btn');
    btn.disabled = false;
    btn.textContent = '💾 Записать';
    document.getElementById('trainer-payment-modal').classList.remove('hidden');
}

function closeTrainerPaymentModal() {
    document.getElementById('trainer-payment-modal').classList.add('hidden');
    currentPaymentTrainer = null;
}

async function saveTrainerPaymentFromModal() {
    if (!currentPaymentTrainer) return;
    var amount = parseFloat(document.getElementById('tp-amount').value);
    var months = parseInt(document.getElementById('tp-months').value);
    var comment = document.getElementById('tp-comment').value.trim();
    if (!amount || amount <= 0) { tg.showAlert('Укажи сумму больше 0'); return; }
    if (!months || months <= 0) { tg.showAlert('Укажи кол-во месяцев больше 0'); return; }
    var chatId = _myChatId();
    var btn = document.getElementById('tp-save-btn');
    btn.disabled = true;
    btn.textContent = '⏳ Сохранение...';
    try {
        var url = APPS_SCRIPT_URL + '?action=saveTrainerPayment' +
            '&chatId=' + encodeURIComponent(chatId) +
            '&targetTrainerId=' + encodeURIComponent(currentPaymentTrainer.trainerId) +
            '&amount=' + encodeURIComponent(amount) +
            '&months=' + encodeURIComponent(months) +
            '&comment=' + encodeURIComponent(comment);
        var resp = await fetch(url);
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось'));
            btn.disabled = false;
            btn.textContent = '💾 Записать';
            return;
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        closeTrainerPaymentModal();
        loadSuperAdminTrainers();
    } catch (e) {
        tg.showAlert('Ошибка соединения ❌');
        btn.disabled = false;
        btn.textContent = '💾 Записать';
    }
}

// Открыть мини-апп «от лица» тренера — vk_group_id уже подхватывается всей
// остальной логикой мульти-тенантности сам по себе (см. CURRENT_TRAINER_ID,
// isTrainer() в начале файла), отдельный бэкенд-эндпоинт не нужен.
//
// 2026-08-19: раньше ПОЛНОСТЬЮ заменяли window.location.search на один
// vk_group_id — при заходе из VK это стирало настоящие подписанные VK
// launch-параметры (sign/vk_user_id/vk_ts) со страницы Matvey. После
// расширения проверки подписи на ВСЕ /trainers/{id}/... (см.
// require_telegram_or_vk_auth_for_trainer_routes в main.py) это стало
// реальным багом: "Открыть как тренер" из VK-сессии превращало каждый
// следующий запрос в неавторизованный (нет подписи вообще) — в т.ч.
// createNewClient, из-за чего добавленный клиент физически не создавался,
// хотя UI не показывал явной ошибки. Теперь ДОБАВЛЯЕМ параметр поверх
// существующих, не трогая vk_group_id/sign — бэкенд признаёт валидную
// подпись Matvey (супер-админа) достаточной для ЛЮБОГО /trainers/{id}/...,
// независимо от того, для какой VK-группы она изначально выдана (сама
// подпись перестать быть валидной при подмене vk_group_id — это встроенное
// свойство HMAC, не обойти на фронте, поэтому его и не трогаем).
function openAsTrainer(vkGroupId) {
    var params = new URLSearchParams(window.location.search);
    params.set('superadmin_view_trainer_id', vkGroupId);
    window.location.search = params.toString();
}

function openNewTrainerForm() {
    document.getElementById('nt-name').value = '';
    document.getElementById('nt-vkgroup').value = '';
    document.getElementById('nt-chatid').value = '';
    document.getElementById('nt-demo-chatid').value = '';
    document.getElementById('nt-color').value = '';
    document.getElementById('nt-vktoken').value = '';
    // Открываем на «боевом»: обычных тренеров заводят почти всегда, а демо
    // редко. Раньше форма открывалась на демо, и было легко не заметить, что
    // группа с токеном, которые ты только что вписал, никуда не пойдут.
    document.getElementById('nt-status').value = 'active';
    updateNewTrainerFormMode();
    document.getElementById('new-trainer-modal').classList.remove('hidden');
    document.body.classList.add('no-scroll');
}

function closeNewTrainerForm() {
    document.getElementById('new-trainer-modal').classList.add('hidden');
    document.body.classList.remove('no-scroll');
}

// Демо — имя + необязательный VK ID зрителя (см. submitNewTrainer: демо
// уходит через action=createDemoTrainer, не createTrainer — VK-группа/токен
// не нужны вообще, готовая ссылка появляется в списке тренеров сразу после
// создания). Боевой — как раньше, все поля.
//
// VK ID зрителя (2026-08-14) — без него ссылку сможет открыть кто угодно в
// обычном браузере, но НЕ увидит панель тренера: раньше "работало" только
// из-за дыры в безопасности (обычный браузер притворялся Матвеем, см.
// _myChatId()) — теперь дыра закрыта, и без настоящего VK ID зрителя
// демо-ссылка никого не узнает.
function updateNewTrainerFormMode() {
    var isDemo = document.getElementById('nt-status').value === 'demo';
    document.getElementById('nt-demo-fields').classList.toggle('hidden', !isDemo);
    document.getElementById('nt-active-fields').classList.toggle('hidden', isDemo);
    document.getElementById('nt-mode-hint').textContent = isDemo
        ? 'Таблица под тренера создастся автоматически (копия шаблона с демо-клиентами), доступ сгорит через 48 часов сам. Ссылку — из списка тренеров, кнопка «Открыть как тренер».'
        : 'Таблица под тренера создастся автоматически, пустая — без твоих клиентов и упражнений. Тренер заведёт всё своё сам.';
}

async function submitNewTrainer() {
    var name = document.getElementById('nt-name').value.trim();
    if (!name) { tg.showAlert('Укажи имя тренера'); return; }
    var status = document.getElementById('nt-status').value;
    var myChatId = _myChatId();

    var btn = document.getElementById('nt-create-btn');
    var origText = btn.textContent;
    btn.disabled = true;
    btn.textContent = '⏳ Создание...';

    try {
        var data;
        if (status === 'demo') {
            // Демо: имя + необязательный VK ID зрителя, ссылку показываем
            // сразу — не нужно ждать, пока тренер сам её найдёт в списке.
            // trainerChatId (2026-08-14): раньше нарочно не передавали — но
            // это опиралось на дыру в безопасности (обычный браузер
            // притворялся Матвеем, см. _myChatId()), дыра закрыта, и без
            // настоящего VK ID зрителя демо-ссылка теперь никого не узнает.
            var demoChatIdRaw = document.getElementById('nt-demo-chatid').value.trim();
            var demoTrainerChatId = demoChatIdRaw ? ('vk_' + demoChatIdRaw.replace(/\D/g, '')) : '';
            var demoQs = 'action=createDemoTrainer&chatId=' + encodeURIComponent(myChatId) +
                '&displayName=' + encodeURIComponent(name) +
                '&trainerChatId=' + encodeURIComponent(demoTrainerChatId) +
                '&demoHours=48';
            var demoResp = await fetch(APPS_SCRIPT_URL + '?' + demoQs);
            data = await demoResp.json();
            if (!data.success) {
                tg.showAlert('Ошибка: ' + (data.error || 'не удалось создать демо'));
                btn.disabled = false;
                btn.textContent = origText;
                return;
            }
            if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
            closeNewTrainerForm();
            btn.disabled = false;
            btn.textContent = origText;
            await loadSuperAdminTrainers();
            var link = window.location.origin + window.location.pathname + '?vk_group_id=' + encodeURIComponent(data.trainerId);
            var noViewerWarning = demoTrainerChatId ? '' :
                '\n\n⚠️ VK ID зрителя не указан — по этой ссылке никто не увидит панель тренера. Добавь VK ID и создай демо заново, либо укажи его позже прямо в таблице.';
            tg.showAlert('✅ Демо готово на 48 часов.\n\nСсылка:\n' + link + noViewerWarning);
        } else {
            var vkGroupId = document.getElementById('nt-vkgroup').value.trim();
            if (!vkGroupId || !/^\d+$/.test(vkGroupId)) {
                tg.showAlert('Укажи ID VK-группы (число)');
                btn.disabled = false;
                btn.textContent = origText;
                return;
            }
            var chatIdRaw = document.getElementById('nt-chatid').value.trim();
            var trainerChatId = chatIdRaw ? ('vk_' + chatIdRaw.replace(/\D/g, '')) : '';
            var color = document.getElementById('nt-color').value.trim();
            var vkToken = document.getElementById('nt-vktoken').value.trim();
            var qs = 'action=createTrainer&chatId=' + encodeURIComponent(myChatId) +
                '&displayName=' + encodeURIComponent(name) +
                '&vkGroupId=' + encodeURIComponent(vkGroupId) +
                '&trainerChatId=' + encodeURIComponent(trainerChatId) +
                '&themePrimary=' + encodeURIComponent(color) +
                '&vkToken=' + encodeURIComponent(vkToken) +
                '&status=active';
            var resp = await fetch(APPS_SCRIPT_URL + '?' + qs);
            data = await resp.json();
            if (!data.success) {
                tg.showAlert('Ошибка: ' + (data.error || 'не удалось создать'));
                btn.disabled = false;
                btn.textContent = origText;
                return;
            }
            if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
            closeNewTrainerForm();
            btn.disabled = false;
            btn.textContent = origText;
            await loadSuperAdminTrainers();
            tg.showAlert('✅ Тренер создан. Пустая таблица тоже готова — ссылка есть в списке.');
        }
    } catch (e) {
        console.error('submitNewTrainer error:', e);
        tg.showAlert('Ошибка соединения ❌');
        btn.disabled = false;
        btn.textContent = origText;
    }
}

async function toggleTrainerStatus(trainerId, newStatus) {
    var chatId = _myChatId();
    try {
        var resp = await fetch(APPS_SCRIPT_URL + '?action=setTrainerStatus&chatId=' + encodeURIComponent(chatId) +
            '&targetTrainerId=' + encodeURIComponent(trainerId) + '&status=' + encodeURIComponent(newStatus));
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Не получилось: ' + (data.error || 'ошибка'));
            return;
        }
        loadSuperAdminTrainers();
    } catch (e) {
        tg.showAlert('Ошибка сети');
    }
}

function initFilters() {
    document.querySelectorAll('.filter-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.filter-btn').forEach(function(b) { b.classList.remove('active'); });
            btn.classList.add('active');
            currentFilter = btn.dataset.filter;
            renderClientCards();
            if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred('light');
        });
    });
}

async function loadDashboardData() {
    try {
        var url = APPS_SCRIPT_URL + '?action=getFoodDashboard&chatId=' + TRAINER_CHAT_ID;
        var response = await fetch(url);
        var data = await response.json();
        if (data.error) {
            console.error('Dashboard error:', data.error);
            document.getElementById('clients-list').innerHTML = '<div class="no-data">Ошибка загрузки: ' + data.error + '</div>';
            return;
        }
        renderDashboard(data);
    } catch (error) {
        console.error('Dashboard load error:', error);
        document.getElementById('clients-list').innerHTML = '<div class="no-data">Ошибка загрузки данных</div>';
    }
}

function renderDashboard(data) {
    var now = new Date();
    document.getElementById('dashboard-date').textContent = now.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' });

    dashboardClients = data.clients || [];
    var alerts = data.alerts || [];
    var stats = data.stats || {};

    document.getElementById('dash-total-clients').textContent = stats.total_clients || dashboardClients.length;
    document.getElementById('dash-need-attention').textContent = alerts.length;

    // Бейдж на вкладке
    var badge = document.getElementById('admin-badge');
    if (alerts.length > 0) {
        badge.textContent = alerts.length;
        badge.classList.remove('hidden');
    } else {
        badge.classList.add('hidden');
    }

    var totalScore = 0, scoreCount = 0;
    dashboardClients.forEach(function(c) {
        if (c.avgFoodScore && c.avgFoodScore > 0) { totalScore += c.avgFoodScore; scoreCount++; }
    });
    document.getElementById('dash-avg-food-score').textContent = scoreCount > 0 ? (totalScore / scoreCount).toFixed(1) : '-';

    renderClientCards();
}

function renderClientCards() {
    var clientsList = document.getElementById('clients-list');
    var filtered = dashboardClients;

    if (currentFilter === 'problem') {
        filtered = dashboardClients.filter(function(c) { return c.status === 'red' || c.status === 'yellow'; });
    } else if (currentFilter === 'active') {
        filtered = dashboardClients.filter(function(c) { return c.status === 'green'; });
    }

    if (filtered.length === 0) {
        clientsList.innerHTML = '<div class="no-data">Нет клиентов в этой категории</div>';
        return;
    }

    clientsList.innerHTML = filtered.map(function(client) {
        var status = client.status || 'inactive';
        var statusClass, statusIcon;
        if (status === 'green' || status === 'good') { statusClass = 'status-green'; statusIcon = '🟢'; }
        else if (status === 'yellow') { statusClass = 'status-yellow'; statusIcon = '🟡'; }
        else { statusClass = 'status-red'; statusIcon = '🔴'; }

        var workoutPercent = client.workoutPercent != null ? client.workoutPercent + '%' : '-';
        var avgScore = (client.avgFoodScore || 0);
        avgScore = avgScore > 0 ? avgScore.toFixed(1) : '-';

        // Процент калорий
        var calHtml = '';
        if (client.targetCalories > 0) {
            var calPct = client.caloriesPercent || 0;
            var calColor = calPct >= 80 && calPct <= 120 ? '#43A047' : calPct > 120 ? '#E53935' : '#FFA726';
            calHtml = '<div class="client-calories">' +
                '<div class="cal-label">Калории сегодня</div>' +
                '<div class="cal-bar-bg"><div class="cal-bar-fill" style="width:' + Math.min(calPct, 100) + '%;background:' + calColor + '"></div></div>' +
                '<div class="cal-text">' + client.todayCalories + ' / ' + client.targetCalories + ' (' + calPct + '%)</div>' +
            '</div>';
        }

        // Сравнение недель
        var trendHtml = '';
        if (client.weekTrend === 'up') trendHtml = '<span class="week-trend trend-up">📈 Лучше прошлой</span>';
        else if (client.weekTrend === 'down') trendHtml = '<span class="week-trend trend-down">📉 Хуже прошлой</span>';

        // Мини-график веса (sparkline через canvas)
        var sparkHtml = '';
        if (client.avgWeights && client.avgWeights.length >= 2) {
            sparkHtml = '<canvas class="weight-spark" data-weights="' + client.avgWeights.join(',') + '" width="80" height="30"></canvas>';
        }

        // Алерты
        var alertsList = [];
        if (client.missedWorkouts) alertsList.push('Пропускает тренировки');
        if (client.missedFood) alertsList.push('Не записывает питание');
        var alertHtml = alertsList.length > 0 ? '<div class="client-alert">⚠️ ' + alertsList.join(' | ') + '</div>' : '';

        // Кнопка написать
        var msgBtn = client.chatId ? '<button class="msg-client-btn" onclick="messageClient(\'' + client.chatId + '\', \'' + (client.name || '') + '\')">✉️ Написать</button>' : '';
        var foodLogBtn = client.chatId ? '<button class="food-log-btn" data-chat-id="' + _escHtmlAttr(client.chatId) + '" data-name="' + _escHtmlAttr(client.name || '') + '" onclick="openFoodLogModal(this.dataset.chatId, this.dataset.name)">📋 Питание по дням</button>' : '';

        return '<div class="client-card ' + statusClass + '">' +
            '<div class="client-header">' +
                '<div class="client-status">' + statusIcon + '</div>' +
                '<div class="client-name">' + _escHtml(client.name || 'Клиент') + '</div>' +
                trendHtml +
                sparkHtml +
            '</div>' +
            '<div class="client-stats">' +
                '<div class="client-stat">' +
                    '<div class="client-stat-label">Тренировки</div>' +
                    '<div class="client-stat-value">' + workoutPercent + '</div>' +
                '</div>' +
                '<div class="client-stat">' +
                    '<div class="client-stat-label">Записей еды</div>' +
                    '<div class="client-stat-value">' + (client.foodCount || 0) + '</div>' +
                '</div>' +
                '<div class="client-stat">' +
                    '<div class="client-stat-label">AI оценка</div>' +
                    '<div class="client-stat-value">' + avgScore + '</div>' +
                '</div>' +
            '</div>' +
            calHtml +
            alertHtml +
            '<div class="client-card-actions">' + foodLogBtn + msgBtn + '</div>' +
        '</div>';
    }).join('');

    // Рисуем sparkline-графики
    document.querySelectorAll('.weight-spark').forEach(function(canvas) {
        var weights = canvas.dataset.weights.split(',').map(Number);
        drawSparkline(canvas, weights);
    });
}

function drawSparkline(canvas, data) {
    var ctx = canvas.getContext('2d');
    var w = canvas.width, h = canvas.height;
    var min = Math.min.apply(null, data);
    var max = Math.max.apply(null, data);
    var range = max - min || 1;
    ctx.clearRect(0, 0, w, h);
    ctx.beginPath();
    ctx.strokeStyle = '#E53935';
    ctx.lineWidth = 2;
    data.forEach(function(val, i) {
        var x = (i / (data.length - 1)) * w;
        var y = h - ((val - min) / range) * (h - 4) - 2;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
    });
    ctx.stroke();
}

// Дриллдаун из дашборда питания: что именно клиент ел по дням, а не только
// суммарные цифры за сегодня.
var FOOD_VERDICT_EMOJI = { excellent: '⭐⭐⭐⭐⭐', good: '⭐⭐⭐⭐', acceptable: '⭐⭐⭐', needs_adjustment: '⭐⭐', poor: '⭐' };

// Дневник еды клиента по дням. Один рендер на два места: дриллдаун из
// дашборда по питанию и вкладка «Питание» в карточке клиента — расходиться
// им незачем.
// Отметка дня в дневнике питания: по какому плану клиент ел. Приходит с
// бэкенда только у тех, у кого заведены оба плана и бот спросил (см.
// food_entries.day_type) — у остальных пусто, и подписи нет вообще, чтобы не
// плодить «неизвестно» на каждом дне у всех клиентов сразу.
var FOOD_DAY_TYPE_LABELS = {
    workout: 'День тренировки',
    rest: 'День отдыха'
};

function renderFoodLogDays(days) {
    return (days || []).map(function(day) {
        var entriesHtml = (day.entries || []).map(function(e) {
            var noteHtml = e.note ? '<div class="food-log-note">' + _escHtml(e.note) + '</div>' : '';
            return '<div class="food-log-entry">' +
                '<div class="food-log-entry-head">' +
                    '<span class="food-log-time">' + _escHtml(e.time || '') + '</span>' +
                    '<span>' + _escHtml(e.mealType || '') + '</span>' +
                    '<span>' + (FOOD_VERDICT_EMOJI[e.verdict] || '') + '</span>' +
                '</div>' +
                '<div class="food-log-macros">' +
                    Math.round(e.calories) + ' ккал · Б' + Math.round(e.protein) + ' · Ж' + Math.round(e.fats) + ' · У' + Math.round(e.carbs) +
                '</div>' +
                noteHtml +
            '</div>';
        }).join('');
        var dayTypeLabel = FOOD_DAY_TYPE_LABELS[day.dayType] || '';
        var dayTypeHtml = dayTypeLabel
            ? '<span class="food-log-daytype food-log-daytype-' + day.dayType + '">' + dayTypeLabel + '</span>'
            : '';
        return '<div class="food-log-day">' +
            '<div class="food-log-day-header">' +
                '<span>' + day.date + dayTypeHtml + '</span>' +
                '<span>' + Math.round(day.totals.calories) + ' ккал · Б' + Math.round(day.totals.protein) + ' Ж' + Math.round(day.totals.fats) + ' У' + Math.round(day.totals.carbs) + '</span>' +
            '</div>' +
            entriesHtml +
        '</div>';
    }).join('');
}

// Среднее за период — по дням, где клиент вообще что-то записал: считать
// вместе с молчаливыми днями значит показывать тренеру заниженную цифру и
// пугать его на ровном месте.
function _foodLogAverages(days) {
    var filled = (days || []).filter(function(d) { return d.totals && d.totals.calories; });
    if (!filled.length) return null;
    var sum = filled.reduce(function(acc, d) {
        acc.calories += d.totals.calories || 0;
        acc.protein += d.totals.protein || 0;
        acc.fats += d.totals.fats || 0;
        acc.carbs += d.totals.carbs || 0;
        return acc;
    }, { calories: 0, protein: 0, fats: 0, carbs: 0 });
    return {
        days: filled.length,
        calories: Math.round(sum.calories / filled.length),
        protein: Math.round(sum.protein / filled.length),
        fats: Math.round(sum.fats / filled.length),
        carbs: Math.round(sum.carbs / filled.length)
    };
}

var clientFoodLogDays = 14;

function switchClientFoodLogPeriod(days) {
    clientFoodLogDays = days;
    if (currentClientCard) loadClientFoodLog(currentClientCard.chatId, true);
}

// Отчёт по питанию прямо в карточке клиента — рядом с планом. Раньше он был
// только в общем дашборде: чтобы посмотреть, что ест ОДИН клиент, тренер шёл
// в другой раздел, разворачивал сводку по всем и искал нужного.
async function loadClientFoodLog(chatId, force) {
    var box = document.getElementById('cc-food-log');
    if (!box) return;
    document.querySelectorAll('#cc-food-log-periods .admin-filter-btn').forEach(function(btn) {
        btn.classList.toggle('active', parseInt(btn.dataset.days, 10) === clientFoodLogDays);
    });
    box.innerHTML = '<div class="no-data">Загрузка отчёта...</div>';
    try {
        var resp = await fetch(APPS_SCRIPT_URL + '?action=getClientFoodEntries&chatId=' +
            encodeURIComponent(chatId) + '&days=' + clientFoodLogDays);
        var data = await resp.json();
        if (data.error) { box.innerHTML = '<div class="no-data">' + data.error + '</div>'; return; }
        if (!data.days || !data.days.length) {
            box.innerHTML = '<div class="no-data">За этот период клиент ничего не записывал</div>';
            return;
        }
        var avg = _foodLogAverages(data.days);
        var avgHtml = avg ? ('<div class="mp-macro-grid">' +
            '<div class="mp-macro-card"><div class="mp-macro-value">' + avg.calories + '</div><div class="mp-macro-label">ккал в день</div></div>' +
            '<div class="mp-macro-card"><div class="mp-macro-value">' + avg.protein + '</div><div class="mp-macro-label">белки</div></div>' +
            '<div class="mp-macro-card"><div class="mp-macro-value">' + avg.fats + '</div><div class="mp-macro-label">жиры</div></div>' +
            '<div class="mp-macro-card"><div class="mp-macro-value">' + avg.carbs + '</div><div class="mp-macro-label">углеводы</div></div>' +
            '</div><div class="mp-macro-hint">Среднее за ' + avg.days + ' дн. с записями</div>') : '';
        box.innerHTML = avgHtml + renderFoodLogDays(data.days);
    } catch (e) {
        console.error('loadClientFoodLog failed:', e);
        box.innerHTML = '<div class="no-data">Не удалось загрузить отчёт ❌</div>';
    }
}

async function openFoodLogModal(chatId, name) {
    document.getElementById('food-log-title').textContent = '📋 Питание — ' + (name || 'Клиент');
    var body = document.getElementById('food-log-body');
    body.innerHTML = '<div class="no-data">Загрузка...</div>';
    document.getElementById('food-log-modal').classList.remove('hidden');
    try {
        var url = APPS_SCRIPT_URL + '?action=getClientFoodEntries&chatId=' + encodeURIComponent(chatId) + '&days=14';
        var resp = await fetch(url);
        var data = await resp.json();
        if (data.error) {
            body.innerHTML = '<div class="no-data">' + data.error + '</div>';
            return;
        }
        if (!data.days || data.days.length === 0) {
            body.innerHTML = '<div class="no-data">Нет записей питания за последние 14 дней</div>';
            return;
        }
        body.innerHTML = renderFoodLogDays(data.days);
    } catch (error) {
        console.error('Food log error:', error);
        body.innerHTML = '<div class="no-data">Ошибка загрузки</div>';
    }
}

function closeFoodLogModal() {
    document.getElementById('food-log-modal').classList.add('hidden');
}

// ========== ADMIN: КЛИЕНТЫ ПО ТРЕНИРОВКАМ ==========

var adminClients = [];
var adminFilter = 'all';
var adminSort = 'status';
var adminSearch = '';

// Соответствие статуса бэка → иконка + подпись + ранг для сортировки (меньше = выше)
var ADMIN_STATUS_INFO = {
    red:      { icon: '🔴', label: 'Провалы',       rank: 1, klass: 'admin-st-red' },
    orange:   { icon: '🟠', label: 'Пропуск 7+ дн', rank: 2, klass: 'admin-st-orange' },
    yellow:   { icon: '🟡', label: 'Пропустил',    rank: 3, klass: 'admin-st-yellow' },
    green:    { icon: '🟢', label: 'В норме',      rank: 4, klass: 'admin-st-green' },
    inactive: { icon: '⚪', label: 'Неактивный',   rank: 5, klass: 'admin-st-inactive' }
};

function formatDaysAgo(days) {
    if (days == null) return 'не было';
    if (days === 0) return 'сегодня';
    if (days === 1) return 'вчера';
    if (days < 5) return days + ' дн назад';
    if (days < 21) return days + ' дн назад';
    var weeks = Math.floor(days / 7);
    return weeks + ' нед назад';
}

// ========== ПЕРЕКЛЮЧАТЕЛЬ КЛИЕНТЫ / ФИНАНСЫ ==========

function switchAdminSection(sectionName) {
    document.querySelectorAll('.admin-section-btn').forEach(function(btn) {
        btn.classList.toggle('active', btn.dataset.adminSection === sectionName);
    });
    document.querySelectorAll('.admin-section').forEach(function(s) {
        s.classList.remove('active');
    });
    var target = document.getElementById('admin-section-' + sectionName);
    if (target) target.classList.add('active');
    if (sectionName === 'finances') { loadFinances(); loadPaymentCalendar(); }
    if (sectionName === 'reports') loadMonthlyReports();
    if (sectionName === 'exercises') loadExerciseMediaLibrary();
}

function initAdminSectionTabs() {
    document.querySelectorAll('.admin-section-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            switchAdminSection(btn.dataset.adminSection);
            if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred('light');
        });
    });
}

// ========== БИБЛИОТЕКА УПРАЖНЕНИЙ (фото/видео техники, тренер сам загружает) ==========

var exerciseMediaData = []; // последний загруженный список из getExerciseMediaLibrary
var exerciseMediaEditingName = ''; // название упражнения, которое сейчас редактируется ('' — новое)
var exerciseMediaPending = {}; // { photo1Base64, photo1Mime, photo2Base64, photo2Mime, removePhoto1, removePhoto2 } — накапливается до сохранения
var exerciseMediaSelectedGroup = ''; // выбранная группа мышц в редакторе (см. openExerciseMediaEditor/_renderExerciseMediaGroupTabs)
// Тот же список, что и KNOWN_MUSCLES (см. ниже, для фильтра библиотеки при
// подборе упражнения клиенту) — держим отдельной переменной здесь, чтобы не
// зависеть от порядка объявления в файле.
var EXERCISE_MEDIA_GROUPS = ['Грудь', 'Спина', 'Плечи', 'Бицепс', 'Трицепс', 'Ноги', 'Ягодицы/ЗПБ', 'Пресс', 'Икры', 'Предплечья', 'Домашняя тренировка'];

function initExerciseMediaLibrary() {
    var search = document.getElementById('ex-media-search');
    if (search) search.addEventListener('input', function() {
        renderExerciseMediaList(search.value.trim().toLowerCase());
    });
    ['1', '2'].forEach(function(slot) {
        var fileInput = document.getElementById('ex-media-photo' + slot + '-file');
        var clearBtn = document.getElementById('ex-media-photo' + slot + '-clear');
        if (fileInput) fileInput.addEventListener('change', function() {
            var file = fileInput.files && fileInput.files[0];
            if (!file) return;
            _compressImageFile(file, 1280, 0.82, function(result) {
                exerciseMediaPending['photo' + slot + 'Base64'] = result.base64;
                exerciseMediaPending['photo' + slot + 'Mime'] = result.mime;
                exerciseMediaPending['removePhoto' + slot] = false;
                var preview = document.getElementById('ex-media-photo' + slot + '-preview');
                if (preview) preview.innerHTML = '<img src="data:' + result.mime + ';base64,' + result.base64 + '">';
            }, function(errMsg) {
                fileInput.value = '';
                tg.showAlert('❌ ' + errMsg);
            });
        });
        if (clearBtn) clearBtn.addEventListener('click', function() {
            exerciseMediaPending['photo' + slot + 'Base64'] = '';
            exerciseMediaPending['removePhoto' + slot] = true;
            if (fileInput) fileInput.value = '';
            var preview = document.getElementById('ex-media-photo' + slot + '-preview');
            if (preview) preview.innerHTML = slot === '1' ? '🏋️' : '💪';
        });
    });
}

async function loadExerciseMediaLibrary() {
    var list = document.getElementById('ex-media-list');
    try {
        var resp = await fetch(APPS_SCRIPT_URL + '?action=getExerciseMediaLibrary');
        var data = await resp.json();
        exerciseMediaData = data.exercises || [];
        renderExerciseMediaList(document.getElementById('ex-media-search') ? document.getElementById('ex-media-search').value.trim().toLowerCase() : '');
    } catch (e) {
        console.error('loadExerciseMediaLibrary failed:', e);
        if (list) list.innerHTML = '<div class="no-data">Не удалось загрузить ❌</div>';
    }
}

function renderExerciseMediaList(filter) {
    var list = document.getElementById('ex-media-list');
    if (!list) return;
    var items = exerciseMediaData.filter(function(ex) {
        return !filter || ex.name.toLowerCase().indexOf(filter) !== -1;
    });
    if (!items.length) {
        list.innerHTML = '<div class="no-data">' + (filter ? 'Ничего не найдено' : 'Упражнений пока нет — добавь первое') + '</div>';
        return;
    }
    list.innerHTML = items.map(function(ex) {
        var thumb1 = ex.photo1 ? '<img src="' + _escHtmlAttr(ex.photo1) + '">' : '🏋️';
        var thumb2 = ex.photo2 ? '<img src="' + _escHtmlAttr(ex.photo2) + '">' : '💪';
        var hasVideo = !!(ex.video || ex.videoVk);
        // Имя кладём в data-атрибут, а не в onclick: у упражнений вроде
        // «"Кошка-корова"» или «"Птичка" bird dog» двойная кавычка закрывала
        // атрибут прямо посреди названия, и карточка переставала нажиматься
        // (жалоба Анны: «на домашнюю тренировку не нажимается»). Экранирования
        // одного апострофа тут мало.
        return '<div class="ex-media-item" data-ex-name="' + _escHtmlAttr(ex.name) + '">' +
            '<div class="ex-media-thumbs">' +
                '<div class="ex-media-thumb">' + thumb1 + '</div>' +
                '<div class="ex-media-thumb">' + thumb2 + '</div>' +
            '</div>' +
            '<div class="ex-media-info">' +
                '<div class="ex-media-name">' + _escHtml(ex.name) + '</div>' +
                '<div class="ex-media-badges">' +
                    (ex.group ? '<span class="ex-media-badge filled">' + _escHtml(ex.group) + '</span>' : '') +
                    '<span class="ex-media-badge ' + (ex.photo1 && ex.photo2 ? 'filled' : '') + '">📷 фото</span>' +
                    '<span class="ex-media-badge ' + (hasVideo ? 'filled' : '') + '">🎬 видео</span>' +
                '</div>' +
            '</div>' +
            '<div class="ex-media-edit-icon">✏️</div>' +
        '</div>';
    }).join('');

    list.querySelectorAll('.ex-media-item').forEach(function(el) {
        el.addEventListener('click', function() {
            openExerciseMediaEditor(el.dataset.exName || '');
        });
    });
}

// Рисует чипы групп мышц в редакторе упражнения — переключение как в
// ex-lib-tab (одиночный выбор), см. exerciseMediaSelectedGroup.
function _renderExerciseMediaGroupTabs(selected) {
    exerciseMediaSelectedGroup = selected || '';
    var box = document.getElementById('ex-media-group-tabs');
    if (!box) return;
    box.innerHTML = EXERCISE_MEDIA_GROUPS.map(function(g) {
        var active = g === exerciseMediaSelectedGroup ? ' active' : '';
        return '<button type="button" class="ex-lib-tab' + active + '" data-group="' + g + '">' + g + '</button>';
    }).join('');
    box.querySelectorAll('.ex-lib-tab').forEach(function(btn) {
        btn.addEventListener('click', function() {
            // Повторный клик по уже выбранной группе — снимает выбор (не обязательно).
            exerciseMediaSelectedGroup = (btn.dataset.group === exerciseMediaSelectedGroup) ? '' : btn.dataset.group;
            box.querySelectorAll('.ex-lib-tab').forEach(function(b) {
                b.classList.toggle('active', b.dataset.group === exerciseMediaSelectedGroup);
            });
        });
    });
}

function openExerciseMediaEditor(name) {
    exerciseMediaEditingName = name || '';
    exerciseMediaPending = {};
    var ex = name ? exerciseMediaData.find(function(e) { return e.name === name; }) : null;

    document.getElementById('ex-media-title').textContent = name ? 'Упражнение' : 'Новое упражнение';
    var nameInput = document.getElementById('ex-media-name');
    nameInput.value = ex ? ex.name : '';
    nameInput.disabled = !!ex; // у существующего упражнения название не трогаем (иначе потеряется связь со старой записью)

    _renderExerciseMediaGroupTabs(ex ? (ex.group || '') : '');

    document.getElementById('ex-media-video').value = ex ? (ex.video || '') : '';
    document.getElementById('ex-media-video-vk').value = ex ? (ex.videoVk || '') : '';

    ['1', '2'].forEach(function(slot) {
        var fileInput = document.getElementById('ex-media-photo' + slot + '-file');
        if (fileInput) fileInput.value = '';
        var preview = document.getElementById('ex-media-photo' + slot + '-preview');
        var url = ex ? ex['photo' + slot] : '';
        if (preview) preview.innerHTML = url ? '<img src="' + url + '">' : (slot === '1' ? '🏋️' : '💪');
    });

    document.getElementById('ex-media-modal').classList.remove('hidden');
    document.body.classList.add('no-scroll');
}

function closeExerciseMediaEditor() {
    document.getElementById('ex-media-modal').classList.add('hidden');
    document.body.classList.remove('no-scroll');
}

async function saveExerciseMediaEntry() {
    var name = (document.getElementById('ex-media-name').value || '').trim();
    if (!name) { tg.showAlert('Укажи название упражнения'); return; }

    var btn = document.getElementById('ex-media-save-btn');
    var origText = btn.textContent;
    btn.disabled = true;
    btn.textContent = '⏳ Сохранение...';

    var payload = Object.assign({
        name: name,
        group: exerciseMediaSelectedGroup,
        video: document.getElementById('ex-media-video').value.trim(),
        videoVk: document.getElementById('ex-media-video-vk').value.trim()
    }, exerciseMediaPending);

    try {
        var resp = await fetch(APPS_SCRIPT_URL + '?action=saveExerciseMedia', {
            method: 'POST',
            body: JSON.stringify(payload)
        });
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось сохранить'));
            btn.disabled = false;
            btn.textContent = origText;
            return;
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        closeExerciseMediaEditor();
        btn.disabled = false;
        btn.textContent = origText;
        await loadExerciseMediaLibrary();
        tg.showAlert('✅ Сохранено');
    } catch (e) {
        console.error('saveExerciseMediaEntry error:', e);
        tg.showAlert('Не удалось сохранить ❌\n\n' + ((e && e.message) || 'нет связи с сервером'));
        btn.disabled = false;
        btn.textContent = origText;
    }
}

// Сжимает фото в браузере перед отправкой (иначе фото с телефона по 5-10 МБ
// будут долго улетать и быстро съедят место в Google Drive). Возвращает через
// callback { base64, mime } — без префикса "data:...;base64,".
// onError — необязательный колбэк, вызывается при сбое (например, HEIC-фото
// с iPhone, которое браузер не может отрисовать через <img>/canvas — тогда
// img.onload молча никогда не срабатывает). Раньше без onError сбой был
// полностью незаметен: файл просто не попадал в форму, а трener видел
// "клиент не прикладывал фото", хотя клиент был уверен, что прикрепил.
function _compressImageFile(file, maxDim, quality, callback, onError) {
    var img = new Image();
    var reader = new FileReader();
    reader.onerror = function() {
        if (onError) onError('Не удалось прочитать файл');
    };
    reader.onload = function(e) {
        img.onerror = function() {
            if (onError) onError('Браузер не смог открыть это фото (часто бывает с форматом HEIC с iPhone) — попробуй выбрать JPG/PNG или пересохранить фото');
        };
        img.onload = function() {
            var w = img.width, h = img.height;
            if (w > maxDim || h > maxDim) {
                if (w > h) { h = Math.round(h * maxDim / w); w = maxDim; }
                else { w = Math.round(w * maxDim / h); h = maxDim; }
            }
            var canvas = document.createElement('canvas');
            canvas.width = w;
            canvas.height = h;
            canvas.getContext('2d').drawImage(img, 0, 0, w, h);
            var dataUrl = canvas.toDataURL('image/jpeg', quality);
            callback({ base64: dataUrl.split(',')[1], mime: 'image/jpeg' });
        };
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}

// ========== ФИНАНСЫ ==========

var financesData = []; // последний загруженный список из getFinances
var allClientsForFinance = []; // полный список клиентов (включая без оплат) из getClients

// ── Календарь оплат ──────────────────────────────────────────────────────
// Список клиентов в «Финансах» отвечает на вопрос «кто сейчас должен», но не
// показывает КОГДА: один платит помесячно, другой сразу за три месяца,
// третий на две недели — и в списке это одинаковые строки. Календарь
// раскладывает то же самое по дням: где оплата, где конец оплаченного срока.
var payCalMonth = null;          // первое число показываемого месяца
var payCalPayments = [];         // платежи, попавшие в этот месяц
var payCalSelectedDay = '';

var MONTH_NAMES_RU = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
    'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];

function _isoDay(d) {
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

function shiftPaymentMonth(delta) {
    var base = payCalMonth || new Date();
    payCalMonth = new Date(base.getFullYear(), base.getMonth() + delta, 1);
    payCalSelectedDay = '';
    loadPaymentCalendar();
}

async function loadPaymentCalendar() {
    var grid = document.getElementById('pay-cal-grid');
    if (!grid) return;
    if (!payCalMonth) {
        var now = new Date();
        payCalMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    }
    var first = payCalMonth;
    var last = new Date(first.getFullYear(), first.getMonth() + 1, 0);
    document.getElementById('pay-cal-title').textContent = MONTH_NAMES_RU[first.getMonth()] + ' ' + first.getFullYear();
    grid.innerHTML = '<div class="no-data">Загрузка…</div>';
    try {
        var resp = await fetch(APPS_SCRIPT_URL + '?action=getPaymentsCalendar' +
            '&start=' + _isoDay(first) + '&end=' + _isoDay(last));
        var data = await resp.json();
        payCalPayments = (data && data.payments) || [];
    } catch (e) {
        console.error('loadPaymentCalendar failed:', e);
        grid.innerHTML = '<div class="no-data">Не удалось загрузить календарь ❌</div>';
        return;
    }
    renderPaymentCalendar();
}

function _payCalDayMap() {
    var map = {};
    var add = function(day, kind, payment) {
        if (!day) return;
        if (!map[day]) map[day] = { paid: [], ends: [] };
        map[day][kind].push(payment);
    };
    payCalPayments.forEach(function(p) {
        add(p.date, 'paid', p);
        add(p.endDate, 'ends', p);
    });
    return map;
}

function renderPaymentCalendar() {
    var grid = document.getElementById('pay-cal-grid');
    if (!grid) return;
    var first = payCalMonth;
    var daysInMonth = new Date(first.getFullYear(), first.getMonth() + 1, 0).getDate();
    // В России неделя начинается с понедельника, а getDay() считает от воскресенья.
    var lead = (first.getDay() + 6) % 7;
    var map = _payCalDayMap();
    var todayIso = _isoDay(new Date());

    var html = '';
    for (var i = 0; i < lead; i++) html += '<div class="pay-cal-cell pay-cal-empty"></div>';
    for (var d = 1; d <= daysInMonth; d++) {
        var iso = _isoDay(new Date(first.getFullYear(), first.getMonth(), d));
        var info = map[iso];
        var dots = '';
        if (info && info.paid.length) dots += '<i class="pay-dot pay-dot-in"></i>';
        if (info && info.ends.length) dots += '<i class="pay-dot pay-dot-end"></i>';
        var cls = 'pay-cal-cell';
        if (iso === todayIso) cls += ' is-today';
        if (iso === payCalSelectedDay) cls += ' is-selected';
        if (info) cls += ' has-events';
        html += '<button type="button" class="' + cls + '" onclick="selectPaymentDay(\'' + iso + '\')">' +
            '<span class="pay-cal-num">' + d + '</span>' +
            '<span class="pay-cal-dots">' + dots + '</span>' +
        '</button>';
    }
    grid.innerHTML = html;
    renderPaymentDayDetails();
}

function selectPaymentDay(iso) {
    payCalSelectedDay = (payCalSelectedDay === iso) ? '' : iso;
    renderPaymentCalendar();
}

function renderPaymentDayDetails() {
    var box = document.getElementById('pay-cal-day-details');
    if (!box) return;
    if (!payCalSelectedDay) {
        var paidCount = 0, endsCount = 0;
        payCalPayments.forEach(function(p) {
            if (p.date) paidCount++;
            if (p.endDate) endsCount++;
        });
        box.innerHTML = payCalPayments.length
            ? '<div class="pay-cal-hint">В этом месяце: ' + paidCount + ' оплат, у ' + endsCount +
              ' клиентов заканчивается срок. Нажми на день — покажу кого.</div>'
            : '<div class="pay-cal-hint">В этом месяце оплат нет</div>';
        return;
    }
    var info = _payCalDayMap()[payCalSelectedDay];
    var human = payCalSelectedDay.split('-').reverse().join('.');
    if (!info) {
        box.innerHTML = '<div class="pay-cal-hint">' + human + ' — ничего не запланировано</div>';
        return;
    }
    var rows = '';
    info.paid.forEach(function(p) {
        rows += '<div class="pay-cal-row">' +
            '<i class="pay-dot pay-dot-in"></i>' +
            '<span class="pay-cal-name">' + _escHtml(p.name) + '</span>' +
            '<span class="pay-cal-meta">оплата ' + Math.round(p.amount) + ' ₽' +
                (p.months ? ' · ' + p.months + ' мес.' : '') + '</span>' +
        '</div>';
    });
    info.ends.forEach(function(p) {
        rows += '<div class="pay-cal-row">' +
            '<i class="pay-dot pay-dot-end"></i>' +
            '<span class="pay-cal-name">' + _escHtml(p.name) + '</span>' +
            '<span class="pay-cal-meta">заканчивается абонемент</span>' +
        '</div>';
    });
    box.innerHTML = '<div class="pay-cal-day-title">' + human + '</div>' + rows;
}

async function loadFinances() {
    var list = document.getElementById('finance-clients-list');
    if (list) list.innerHTML = '<div class="no-data">Загрузка финансов...</div>';
    try {
        // Загружаем параллельно: статусы абонементов + полный список клиентов (для тех у кого ещё нет ни одной оплаты)
        var [finResp, clientsResp] = await Promise.all([
            fetch(APPS_SCRIPT_URL + '?action=getFinances'),
            fetch(APPS_SCRIPT_URL + '?action=getClients')
        ]);
        var finData = await finResp.json();
        var clientsData = await clientsResp.json();
        if (finData.error) {
            if (list) list.innerHTML = '<div class="no-data">Ошибка: ' + finData.error + '</div>';
            return;
        }
        financesData = finData.clients || [];
        allClientsForFinance = (clientsData.clients || []).filter(function(c) { return !c.archived; });

        renderFinanceSummary();
        renderFinanceList();
    } catch (error) {
        console.error('Load finances error:', error);
        if (list) list.innerHTML = '<div class="no-data">Ошибка загрузки</div>';
    }
}

function renderFinanceSummary() {
    var active = 0, expiring = 0, expired = 0;
    financesData.forEach(function(c) {
        if (c.status === 'active') active++;
        else if (c.status === 'expiring_soon' || c.status === 'expiring_week') expiring++;
        else if (c.status === 'expired') expired++;
    });
    document.getElementById('finance-active-count').textContent = active;
    document.getElementById('finance-expiring-count').textContent = expiring;
    document.getElementById('finance-expired-count').textContent = expired;
}

function renderFinanceList() {
    var list = document.getElementById('finance-clients-list');
    if (!list) return;
    // Объединяем: для каждого активного клиента смотрим есть ли оплата.
    // Если есть — берём данные из financesData, иначе показываем как «без оплат».
    var byChatId = {};
    financesData.forEach(function(c) { byChatId[c.chatId] = c; });

    var merged = [];
    allClientsForFinance.forEach(function(c) {
        var fin = byChatId[c.chatId];
        if (fin) {
            merged.push(fin);
        } else {
            merged.push({
                chatId: c.chatId,
                name: c.name,
                status: 'none',
                daysLeft: null,
                endDate: '',
                amount: null,
                lastPayment: ''
            });
        }
    });

    // Сортируем: просрочка → истекает → нет оплат → активные (по убыванию daysLeft)
    var statusOrder = { expired: 0, expiring_soon: 1, expiring_week: 2, none: 3, active: 4 };
    merged.sort(function(a, b) {
        var so = (statusOrder[a.status] || 99) - (statusOrder[b.status] || 99);
        if (so !== 0) return so;
        return (a.daysLeft || 0) - (b.daysLeft || 0);
    });

    if (merged.length === 0) {
        list.innerHTML = '<div class="no-data">Нет активных клиентов</div>';
        return;
    }

    var labels = {
        active: 'активен',
        expiring_week: 'неделя',
        expiring_soon: 'скоро',
        expired: 'истёк',
        none: 'без оплат'
    };

    list.innerHTML = merged.map(function(c) {
        var statusLabel = labels[c.status] || c.status;
        var daysText;
        if (c.status === 'none') {
            daysText = '<span class="fc-info-item">Оплат ещё нет</span>';
        } else if (c.daysLeft === null || c.daysLeft === undefined) {
            daysText = '';
        } else if (c.daysLeft < 0) {
            daysText = '<span class="fc-info-item">Истёк <strong>' + Math.abs(c.daysLeft) + ' дн. назад</strong></span>';
        } else if (c.daysLeft === 0) {
            daysText = '<span class="fc-info-item"><strong>Истекает сегодня</strong></span>';
        } else {
            daysText = '<span class="fc-info-item">Осталось <strong>' + c.daysLeft + ' дн.</strong></span>';
        }
        var endText = c.endDate ? '<span class="fc-info-item">До <strong>' + c.endDate + '</strong></span>' : '';
        var amountText = c.amount ? '<span class="fc-info-item">Последняя оплата: <strong>' + c.amount + ' ₽</strong></span>' : '';
        var safeName = (c.name || '').replace(/'/g, "\\'");
        return '<div class="finance-client-card fc-' + c.status + '">' +
            '<div class="fc-row">' +
                '<div class="fc-name">' + _escHtml(c.name || '—') + '</div>' +
                '<div class="fc-status-badge b-' + c.status + '">' + statusLabel + '</div>' +
            '</div>' +
            '<div class="fc-info">' + daysText + endText + amountText + '</div>' +
            '<div class="fc-actions">' +
                '<button class="fc-pay-btn" onclick="openPaymentModal(\'' + c.chatId + '\', \'' + safeName + '\')">💰 Записать оплату</button>' +
                (c.status !== 'none' ? '<button class="fc-freeze-btn" onclick="openFreezeModal(\'' + c.chatId + '\', \'' + safeName + '\')" title="Заморозить / продлить">❄️</button>' : '') +
                '<button class="fc-delete-btn" onclick="deleteClientCompletely(\'' + c.chatId + '\', \'' + safeName + '\')" title="Удалить клиента">🗑️</button>' +
            '</div>' +
        '</div>';
    }).join('');
}

// Модалка оплаты
var currentPaymentClient = null;

function openPaymentModal(chatId, clientName) {
    currentPaymentClient = { chatId: chatId, name: clientName };
    document.getElementById('payment-modal-title').textContent = '💰 Оплата — ' + clientName;
    document.getElementById('payment-amount').value = '';
    document.getElementById('payment-months').value = '1';
    document.getElementById('payment-comment').value = '';
    // По умолчанию сегодня — как было раньше; менять нужно редко, но деньги
    // нередко заносят не в тот день, когда их получили.
    var dateInput = document.getElementById('payment-date');
    if (dateInput) {
        var now = new Date();
        dateInput.value = now.getFullYear() + '-' +
            String(now.getMonth() + 1).padStart(2, '0') + '-' +
            String(now.getDate()).padStart(2, '0');
    }
    var btn = document.getElementById('payment-save-btn');
    btn.disabled = false;
    btn.textContent = '💾 Записать';
    document.getElementById('payment-modal').classList.remove('hidden');
}

function closePaymentModal() {
    document.getElementById('payment-modal').classList.add('hidden');
    currentPaymentClient = null;
}

async function savePaymentFromModal() {
    if (!currentPaymentClient) return;
    var amount = parseFloat(document.getElementById('payment-amount').value);
    var months = parseInt(document.getElementById('payment-months').value);
    var comment = document.getElementById('payment-comment').value.trim();
    var paidOn = (document.getElementById('payment-date') || {}).value || '';
    if (!amount || amount <= 0) {
        tg.showAlert('Укажи сумму больше 0');
        return;
    }
    if (!months || months <= 0) {
        tg.showAlert('Укажи кол-во месяцев больше 0');
        return;
    }
    var btn = document.getElementById('payment-save-btn');
    btn.disabled = true;
    btn.textContent = '⏳ Сохранение...';
    try {
        var url = APPS_SCRIPT_URL + '?action=savePaymentDirect' +
            '&clientChatId=' + encodeURIComponent(currentPaymentClient.chatId) +
            '&clientName=' + encodeURIComponent(currentPaymentClient.name) +
            '&amount=' + encodeURIComponent(amount) +
            '&months=' + encodeURIComponent(months) +
            '&comment=' + encodeURIComponent(comment) +
            '&date=' + encodeURIComponent(paidOn);
        var resp = await fetch(url);
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось'));
            btn.disabled = false;
            btn.textContent = '💾 Записать';
            return;
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        btn.textContent = '✅ Записано';
        setTimeout(function() {
            closePaymentModal();
            loadFinances();
        }, 600);
    } catch (error) {
        console.error('Save payment error:', error);
        tg.showAlert('Ошибка соединения');
        btn.disabled = false;
        btn.textContent = '💾 Записать';
    }
}

// Модалка заморозки/продления абонемента
var currentFreezeClient = null;

function openFreezeModal(chatId, clientName) {
    currentFreezeClient = { chatId: chatId, name: clientName };
    document.getElementById('freeze-modal-title').textContent = '❄️ Заморозка — ' + clientName;
    document.getElementById('freeze-days').value = '';
    document.getElementById('freeze-comment').value = '';
    var btn = document.getElementById('freeze-save-btn');
    btn.disabled = false;
    btn.textContent = '💾 Сохранить';
    document.getElementById('freeze-modal').classList.remove('hidden');
}

function closeFreezeModal() {
    document.getElementById('freeze-modal').classList.add('hidden');
    currentFreezeClient = null;
}

async function saveFreezeFromModal() {
    if (!currentFreezeClient) return;
    var days = parseInt(document.getElementById('freeze-days').value);
    var comment = document.getElementById('freeze-comment').value.trim();
    if (!days) {
        tg.showAlert('Укажи количество дней (не 0)');
        return;
    }
    var btn = document.getElementById('freeze-save-btn');
    btn.disabled = true;
    btn.textContent = '⏳ Сохранение...';
    try {
        var url = APPS_SCRIPT_URL + '?action=adjustSubscriptionEnd' +
            '&clientChatId=' + encodeURIComponent(currentFreezeClient.chatId) +
            '&days=' + encodeURIComponent(days) +
            '&comment=' + encodeURIComponent(comment);
        var resp = await fetch(url);
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось'));
            btn.disabled = false;
            btn.textContent = '💾 Сохранить';
            return;
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        btn.textContent = '✅ Сохранено';
        setTimeout(function() {
            closeFreezeModal();
            loadFinances();
        }, 600);
    } catch (error) {
        console.error('Adjust subscription error:', error);
        tg.showAlert('Ошибка соединения');
        btn.disabled = false;
        btn.textContent = '💾 Сохранить';
    }
}

// ========== МЕСЯЧНЫЕ ОТЧЁТЫ ==========

var monthlyReports = []; // последний загруженный список превью
var currentReportSendingClient = null; // {chatId, name, msg}

async function loadMonthlyReports() {
    var list = document.getElementById('reports-list');
    if (list) list.innerHTML = '<div class="no-data">Считаю прогресс…</div>';
    try {
        var resp = await fetch(APPS_SCRIPT_URL + '?action=getMonthlyReportsPreview');
        var data = await resp.json();
        if (data.error) {
            if (list) list.innerHTML = '<div class="no-data">Ошибка: ' + data.error + '</div>';
            return;
        }
        monthlyReports = data.reports || [];
        renderMonthlyReports();
    } catch (e) {
        console.error('loadMonthlyReports error:', e);
        if (list) list.innerHTML = '<div class="no-data">Ошибка загрузки</div>';
    }
}

function renderMonthlyReports() {
    var list = document.getElementById('reports-list');
    if (!list) return;
    if (monthlyReports.length === 0) {
        list.innerHTML = '<div class="no-data">Нет активных платящих клиентов</div>';
        return;
    }
    list.innerHTML = monthlyReports.map(function(r, idx) {
        var noData = !r.hasData;
        var safeName = (r.name || '').replace(/'/g, "\\'");
        var statusClass = noData ? 's-empty' : 's-ok';
        var statusText = noData ? 'нет данных' : 'есть прогресс';
        return '<div class="report-card' + (noData ? ' no-data' : '') + '">' +
            '<div class="report-card-name">' + _escHtml(r.name || '—') + '</div>' +
            '<div class="report-card-summary">' + _escHtml(r.summary || '') + '</div>' +
            '<span class="report-card-status ' + statusClass + '">' + statusText + '</span>' +
            '<div class="report-card-actions">' +
                '<button class="report-preview-btn" onclick="previewReport(' + idx + ')">👁 Превью</button>' +
                '<button class="report-send-btn-card" onclick="quickSendReport(' + idx + ')"' + (noData ? ' disabled' : '') + '>📤 Отправить</button>' +
            '</div>' +
        '</div>';
    }).join('');
}

function previewReport(idx) {
    var r = monthlyReports[idx];
    if (!r) return;
    currentReportSendingClient = { chatId: r.chatId, name: r.name };
    document.getElementById('report-preview-title').textContent = '📊 ' + r.name;
    document.getElementById('report-preview-text').textContent = r.msgPreview || '(пусто — нет данных за месяц)';
    var sendBtn = document.getElementById('report-send-btn');
    sendBtn.disabled = !r.hasData;
    sendBtn.textContent = r.hasData ? '📤 Отправить клиенту' : 'Нечего отправлять';
    document.getElementById('report-preview-modal').classList.remove('hidden');
}

function closeReportPreview() {
    document.getElementById('report-preview-modal').classList.add('hidden');
    currentReportSendingClient = null;
}

async function confirmSendReport() {
    if (!currentReportSendingClient) return;
    await _doSendReport(currentReportSendingClient.chatId, currentReportSendingClient.name);
    closeReportPreview();
}

async function quickSendReport(idx) {
    var r = monthlyReports[idx];
    if (!r || !r.hasData) return;
    var confirmed = await tgConfirm('Отправить месячный отчёт клиенту «' + r.name + '»?');
    if (!confirmed) return;
    await _doSendReport(r.chatId, r.name);
}

async function _doSendReport(chatId, clientName) {
    try {
        var url = APPS_SCRIPT_URL + '?action=sendMonthlyReportToClient' +
            '&targetChatId=' + encodeURIComponent(chatId) +
            '&clientName=' + encodeURIComponent(clientName);
        var resp = await fetch(url);
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Не удалось: ' + (data.error || 'ошибка'));
            return;
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        tg.showAlert('Отчёт отправлен клиенту «' + clientName + '» ✅');
    } catch (e) {
        console.error('send report error:', e);
        tg.showAlert('Ошибка соединения');
    }
}

async function deleteClientCompletely(chatId, clientName) {
    var msg = 'Удалить клиента «' + clientName + '» из системы?\n\nОн пропадёт из всех списков и потеряет доступ к боту и мини-аппу. Программа, история и замеры физически остаются в базе — на случай, если понадобится восстановить.';
    var confirmed = await tgConfirm(msg);
    if (!confirmed) return;
    try {
        var url = APPS_SCRIPT_URL + '?action=deleteClient&targetChatId=' + encodeURIComponent(chatId);
        var resp = await fetch(url);
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось'));
            return;
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        loadFinances();
        // Обновим основной список клиентов
        if (typeof loadAdminClients === 'function') loadAdminClients();
    } catch (error) {
        console.error('Delete client error:', error);
        tg.showAlert('Ошибка соединения');
    }
}

async function loadAdminClients() {
    var list = document.getElementById('admin-clients-list');
    if (list) list.innerHTML = '<div class="no-data">Загрузка клиентов...</div>';
    try {
        var url = APPS_SCRIPT_URL + '?action=getAdminClients';
        var response = await fetch(url);
        var data = await response.json();
        if (data.error) {
            if (list) list.innerHTML = '<div class="no-data">Ошибка: ' + data.error + '</div>';
            return;
        }
        adminClients = data.clients || [];
        renderAdminSummary();
        renderAdminClients();
    } catch (error) {
        console.error('Admin clients load error:', error);
        if (list) list.innerHTML = '<div class="no-data">Ошибка загрузки</div>';
    }
}

function renderAdminSummary() {
    // Архивных в сводку не считаем
    var active = adminClients.filter(function(c) { return c.archived !== true; });
    var archivedCount = adminClients.length - active.length;
    var total = active.length;
    var attention = active.filter(function(c) {
        return c.status === 'red' || c.status === 'orange' || c.status === 'yellow';
    }).length;
    var activeWeek = active.filter(function(c) {
        return c.lastWorkoutDaysAgo != null && c.lastWorkoutDaysAgo < 7;
    }).length;
    document.getElementById('admin-total').textContent = total;
    document.getElementById('admin-attention').textContent = attention;
    document.getElementById('admin-active-week').textContent = activeWeek;
    var archCount = document.getElementById('admin-archive-count');
    if (archCount) archCount.textContent = archivedCount > 0 ? '(' + archivedCount + ')' : '';

    // Бейдж на вкладке
    var badge = document.getElementById('admin-badge');
    if (badge) {
        if (attention > 0) { badge.textContent = attention; badge.classList.remove('hidden'); }
        else badge.classList.add('hidden');
    }

    // Дата
    var dateEl = document.getElementById('dashboard-date');
    if (dateEl) {
        dateEl.textContent = new Date().toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' });
    }
}

function initAdminClientsControls() {
    // Поиск
    var search = document.getElementById('admin-search');
    if (search) {
        search.addEventListener('input', function() {
            adminSearch = (search.value || '').toLowerCase().trim();
            renderAdminClients();
        });
    }
    // Сортировка
    var sortEl = document.getElementById('admin-sort');
    if (sortEl) {
        sortEl.addEventListener('change', function() {
            adminSort = sortEl.value;
            renderAdminClients();
        });
    }
    // Фильтры
    document.querySelectorAll('.admin-filter-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.admin-filter-btn').forEach(function(b) { b.classList.remove('active'); });
            btn.classList.add('active');
            adminFilter = btn.dataset.adminFilter;
            renderAdminClients();
            if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred('light');
        });
    });
}

function getFilteredAdminClients() {
    var arr = adminClients.slice();
    // Архив — отдельная "папка". Во всех остальных фильтрах архивных скрываем.
    if (adminFilter === 'archive') {
        arr = arr.filter(function(c) { return c.archived === true; });
    } else {
        arr = arr.filter(function(c) { return c.archived !== true; });
        if (adminFilter === 'attention') {
            arr = arr.filter(function(c) { return c.status === 'red' || c.status === 'orange' || c.status === 'yellow'; });
        } else if (adminFilter === 'active') {
            arr = arr.filter(function(c) { return c.status === 'green'; });
        } else if (adminFilter === 'inactive') {
            arr = arr.filter(function(c) { return c.status === 'inactive'; });
        }
    }
    // Поиск
    if (adminSearch) {
        arr = arr.filter(function(c) { return (c.name || '').toLowerCase().indexOf(adminSearch) >= 0; });
    }
    // Сортировка
    if (adminSort === 'status') {
        arr.sort(function(a, b) {
            var ra = (ADMIN_STATUS_INFO[a.status] || {}).rank || 99;
            var rb = (ADMIN_STATUS_INFO[b.status] || {}).rank || 99;
            if (ra !== rb) return ra - rb;
            return (a.name || '').localeCompare(b.name || '', 'ru');
        });
    } else if (adminSort === 'date') {
        arr.sort(function(a, b) {
            var da = a.lastWorkoutDaysAgo == null ? 99999 : a.lastWorkoutDaysAgo;
            var db = b.lastWorkoutDaysAgo == null ? 99999 : b.lastWorkoutDaysAgo;
            return da - db;
        });
    } else if (adminSort === 'alpha') {
        arr.sort(function(a, b) { return (a.name || '').localeCompare(b.name || '', 'ru'); });
    }
    return arr;
}

function renderAdminClients() {
    var list = document.getElementById('admin-clients-list');
    var tbody = document.getElementById('admin-clients-tbody');
    var arr = getFilteredAdminClients();

    if (arr.length === 0) {
        if (list) list.innerHTML = '<div class="no-data">Нет клиентов в этой категории</div>';
        if (tbody) tbody.innerHTML = '';
        return;
    }

    // ── Мобильные карточки ──
    if (list) {
        list.innerHTML = arr.map(function(c) {
            var info = ADMIN_STATUS_INFO[c.status] || ADMIN_STATUS_INFO.inactive;
            var safeName = (c.name || '').replace(/'/g, "\\'");
            var isArchived = c.archived === true;
            var failBadge = (!isArchived && c.failuresLastWorkout >= 2)
                ? '<span class="admin-card-badge admin-badge-red">⚠️ Провалы в последней</span>' : '';
            var archivedBadge = isArchived
                ? '<span class="admin-card-badge admin-badge-archived">📦 В архиве</span>' : '';
            var importantBadge = c.hasImportantNote
                ? '<span class="admin-card-badge admin-badge-important">⚠️ Есть заметка</span>' : '';
            // Удаление показываем ТОЛЬКО у архивных: архив — это и есть шаг
            // «клиент больше не занимается», и дальше его либо возвращают,
            // либо убирают совсем. У активного клиента корзина рядом с
            // «Открыть» — приглашение к случайному тапу. Раньше удалить можно
            // было лишь из раздела «Финансы», куда архивные не попадают
            // вовсе — то есть архив не разгребался никак.
            var archiveBtn = isArchived
                ? '<button class="admin-card-btn admin-card-btn-restore" onclick="toggleArchiveClient(\'' + c.chatId + '\', false)">↩️ Вернуть</button>' +
                  '<button class="admin-card-btn admin-card-btn-delete" onclick="deleteClientCompletely(\'' + c.chatId + '\', \'' + safeName + '\')">🗑 Удалить</button>'
                : '<button class="admin-card-btn admin-card-btn-archive" onclick="toggleArchiveClient(\'' + c.chatId + '\', true)">📦 В архив</button>';
            return '<div class="admin-client-card ' + info.klass + (isArchived ? ' admin-card-archived' : '') + '" data-chat="' + (c.chatId || '') + '">' +
                '<div class="admin-card-top">' +
                    '<div class="admin-card-status">' + info.icon + '</div>' +
                    '<div class="admin-card-name">' + _escHtml(c.name || 'Клиент') + '</div>' +
                    '<div class="admin-card-status-label">' + info.label + '</div>' +
                '</div>' +
                '<div class="admin-card-meta">' +
                    '<div class="admin-card-meta-item">' +
                        '<span class="admin-card-meta-label">📅 Неделя</span>' +
                        '<span class="admin-card-meta-value">' + _escHtml(c.weekTitle || '—') + '</span>' +
                    '</div>' +
                    '<div class="admin-card-meta-item">' +
                        '<span class="admin-card-meta-label">🏋️ Последняя</span>' +
                        '<span class="admin-card-meta-value">' + formatDaysAgo(c.lastWorkoutDaysAgo) + '</span>' +
                    '</div>' +
                    '<div class="admin-card-meta-item">' +
                        '<span class="admin-card-meta-label">📊 За 7 дней</span>' +
                        '<span class="admin-card-meta-value">' + (c.workouts7Days || 0) + ' трен.</span>' +
                    '</div>' +
                '</div>' +
                archivedBadge +
                importantBadge +
                failBadge +
                '<div class="admin-card-actions">' +
                    '<button class="admin-card-btn admin-card-btn-primary" onclick="openClientCard(\'' + c.chatId + '\')">👁 Открыть</button>' +
                    '<button class="admin-card-btn" onclick="messageClient(\'' + c.chatId + '\', \'' + safeName + '\')">✉️ Написать</button>' +
                    archiveBtn +
                '</div>' +
            '</div>';
        }).join('');
    }

    // ── Десктоп: таблица ──
    if (tbody) {
        tbody.innerHTML = arr.map(function(c) {
            var info = ADMIN_STATUS_INFO[c.status] || ADMIN_STATUS_INFO.inactive;
            var safeName = (c.name || '').replace(/'/g, "\\'");
            var isArchived = c.archived === true;
            var archiveAction = isArchived
                ? '<button class="admin-row-btn" title="Вернуть из архива" onclick="toggleArchiveClient(\'' + c.chatId + '\', false)">↩️</button>' +
                  '<button class="admin-row-btn" title="Удалить клиента" onclick="deleteClientCompletely(\'' + c.chatId + '\', \'' + safeName + '\')">🗑</button>'
                : '<button class="admin-row-btn" title="В архив" onclick="toggleArchiveClient(\'' + c.chatId + '\', true)">📦</button>';
            return '<tr class="' + info.klass + (isArchived ? ' admin-row-archived' : '') + '">' +
                '<td><span class="admin-row-status">' + info.icon + '</span><span class="admin-row-status-label">' + info.label + '</span></td>' +
                '<td class="admin-row-name">' + _escHtml(c.name || 'Клиент') + (isArchived ? ' <span class="admin-row-archive-tag">📦</span>' : '') + '</td>' +
                '<td>' + _escHtml(c.weekTitle || '—') + '</td>' +
                '<td>' + formatDaysAgo(c.lastWorkoutDaysAgo) + '</td>' +
                '<td>' + (c.workouts7Days || 0) + '</td>' +
                '<td class="admin-row-actions">' +
                    '<button class="admin-row-btn" title="Открыть" onclick="openClientCard(\'' + c.chatId + '\')">👁</button>' +
                    '<button class="admin-row-btn" title="Написать" onclick="messageClient(\'' + c.chatId + '\', \'' + safeName + '\')">✉️</button>' +
                    archiveAction +
                '</td>' +
            '</tr>';
        }).join('');
    }
}

// ========== МАСТЕР СОЗДАНИЯ НОВОГО КЛИЕНТА (Фаза 6) ==========

var ncProgramType = 'empty'; // 'empty' | 'copy'

function openNewClientWizard() {
    // Сбросить все поля
    document.getElementById('nc-name').value = '';
    document.getElementById('nc-chatid').value = '';
    var vkRadio = document.querySelector('input[name="nc-platform"][value="vk"]');
    if (vkRadio) vkRadio.checked = true;
    _updateNcChatIdLabel();
    document.querySelectorAll('input[name="nc-gender"]').forEach(function(el) { el.checked = false; });
    document.getElementById('nc-age').value = '';
    document.getElementById('nc-height').value = '';
    document.getElementById('nc-weight').value = '';
    document.getElementById('nc-goal').value = '';
    document.getElementById('nc-level').value = '';
    document.getElementById('nc-frequency').value = '';
    document.querySelectorAll('.nc-limit-cb').forEach(function(cb) { cb.checked = false; });
    document.getElementById('nc-limit-other').value = '';
    document.getElementById('nc-inventory').value = '';
    ncProgramType = 'empty';
    selectProgramOption('empty');

    // Показать
    goToStep1();
    document.getElementById('new-client-wizard').classList.remove('hidden');
    document.body.classList.add('no-scroll');
}

function closeNewClientWizard() {
    document.getElementById('new-client-wizard').classList.add('hidden');
    document.body.classList.remove('no-scroll');
}

function goToStep1() {
    document.getElementById('nc-step-1').classList.add('active');
    document.getElementById('nc-step-2').classList.remove('active');
    document.getElementById('nc-step-meta').textContent = 'Шаг 1 из 2 — Анкета';
}

function goToStep2() {
    // Минимальная валидация
    var name = document.getElementById('nc-name').value.trim();
    var chatId = document.getElementById('nc-chatid').value.trim();
    var platformLabel = _ncSelectedPlatform() === 'telegram' ? 'Telegram chat_id' : 'VK ID клиента';
    if (!name) { tg.showAlert('Укажи имя клиента'); return; }
    if (!chatId || !/^\d+$/.test(chatId)) { tg.showAlert('Укажи ' + platformLabel + ' (число)'); return; }

    // Заполнить список источников копирования (активные клиенты)
    var sources = (adminClients || []).filter(function(c) { return !c.archived; });
    var sel = document.getElementById('nc-source-select');
    sel.innerHTML = '<option value="">— выбери клиента —</option>' + sources.map(function(c) {
        return '<option value="' + (c.sheetName || '').replace(/"/g, '&quot;') + '">' + c.name + '</option>';
    }).join('');

    document.getElementById('nc-step-1').classList.remove('active');
    document.getElementById('nc-step-2').classList.add('active');
    document.getElementById('nc-step-meta').textContent = 'Шаг 2 из 2 — Программа';
}

function selectProgramOption(type) {
    ncProgramType = type;
    document.querySelectorAll('.nc-program-option').forEach(function(el) {
        el.classList.toggle('selected', el.dataset.progType === type);
    });
    document.getElementById('nc-source-wrap').classList.toggle('hidden', type !== 'copy');
}

function _collectNewClientProfile() {
    var gender = '';
    var g = document.querySelector('input[name="nc-gender"]:checked');
    if (g) gender = g.value;

    var limits = [];
    document.querySelectorAll('.nc-limit-cb').forEach(function(cb) {
        if (cb.checked) limits.push(cb.value);
    });
    var other = (document.getElementById('nc-limit-other').value || '').trim();
    if (other) other.split(',').forEach(function(s) {
        var v = s.trim();
        if (v) limits.push(v);
    });

    // Платформа клиента: VK-id уходит на бэк с префиксом "vk_" (тот же формат,
    // что уже понимает _sendNotification/setClientChatId), Telegram — как есть,
    // числом (совместимость со старыми клиентами).
    var rawChatId = document.getElementById('nc-chatid').value.trim();
    var chatId = _ncSelectedPlatform() === 'vk' && rawChatId.indexOf('vk_') !== 0
        ? 'vk_' + rawChatId.replace(/\D/g, '')
        : rawChatId;

    return {
        name: document.getElementById('nc-name').value.trim(),
        chatId: chatId,
        gender: gender,
        age: document.getElementById('nc-age').value.trim(),
        height: document.getElementById('nc-height').value.trim(),
        weight: document.getElementById('nc-weight').value.trim(),
        goal: document.getElementById('nc-goal').value,
        level: document.getElementById('nc-level').value,
        frequency: document.getElementById('nc-frequency').value,
        limitations: limits.join(','),
        inventory: document.getElementById('nc-inventory').value
    };
}

// Создаёт нового клиента (отправляет на бэк, открывает карточку при успехе).
// Переопределяет глобальное имя — но window.createNewClient использует функцию ниже (в Apps Script роутере действие createNewClient).
async function createNewClient() {
    var btn = document.getElementById('nc-create-btn');
    var origText = btn.textContent;
    btn.disabled = true;
    btn.textContent = '⏳ Создание...';

    var profile = _collectNewClientProfile();
    var programOpts = { type: ncProgramType };
    if (ncProgramType === 'copy') {
        var src = document.getElementById('nc-source-select').value;
        if (!src) {
            tg.showAlert('Выбери клиента для копирования программы');
            btn.disabled = false;
            btn.textContent = origText;
            return;
        }
        programOpts.sourceSheetName = src;
    }

    try {
        var qs = 'action=createNewClient' +
            '&profile=' + encodeURIComponent(JSON.stringify(profile)) +
            '&programOpts=' + encodeURIComponent(JSON.stringify(programOpts));
        var resp = await fetch(APPS_SCRIPT_URL + '?' + qs);
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось'));
            btn.disabled = false;
            btn.textContent = origText;
            return;
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        // Перезагружаем список клиентов
        await loadAdminClients();
        closeNewClientWizard();
        btn.disabled = false;
        btn.textContent = origText;
        // Открыть карточку только что созданного клиента
        var newC = (adminClients || []).find(function(c) { return c.chatId === data.chatId; });
        if (newC) {
            setTimeout(function() { openClientCard(data.chatId); }, 200);
        }
        tg.showAlert('✅ Клиент создан: ' + data.name);
    } catch (e) {
        console.error('Create client error:', e);
        tg.showAlert('Ошибка соединения ❌');
        btn.disabled = false;
        btn.textContent = origText;
    }
}

// ========== АРХИВ КЛИЕНТОВ ==========

async function toggleArchiveClient(chatId, archived) {
    var client = adminClients.find(function(c) { return c.chatId === chatId; });
    var name = client ? client.name : 'клиента';
    var action = archived ? ('Убрать ' + name + ' в архив?') : ('Вернуть ' + name + ' из архива?');
    var confirmed = await tgConfirm(action);
    if (!confirmed) return;

    try {
        var url = APPS_SCRIPT_URL + '?action=setClientArchived&targetChatId=' + encodeURIComponent(chatId) + '&archived=' + (archived ? 'true' : 'false');
        var response = await fetch(url);
        var data = await response.json();
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось'));
            return;
        }
        // Обновляем локально, чтобы не делать полный re-fetch
        if (client) client.archived = archived;
        renderAdminSummary();
        renderAdminClients();
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
    } catch (error) {
        console.error('Archive toggle error:', error);
        tg.showAlert('Ошибка соединения ❌');
    }
}

// ========== КАРТОЧКА КЛИЕНТА (Фаза 2A: просмотр программы) ==========

var currentClientCard = null;
// Дни, которые тренер только что создал, но ещё не наполнил упражнениями.
// В новой схеме день — не отдельная сущность, а просто подпись на упражнении
// (см. addClientDay в NEW_API_ACTIONS), поэтому пустой день бэкенду негде
// хранить и в ответе программы его не будет. Держим такие дни здесь, чтобы
// они всё-таки отрисовались и в них было куда нажать «+ Добавить упражнение».
// Живут до перезагрузки страницы или до перехода к другому клиенту — ровно
// столько, сколько нужно, чтобы довести день до первого упражнения.
var pendingEmptyDays = [];

function openClientCard(chatId) {
    var client = adminClients.find(function(c) { return c.chatId === chatId; });
    if (!client) return;
    currentClientCard = client;
    pendingEmptyDays = [];

    document.getElementById('cc-name').textContent = client.name || 'Клиент';
    document.getElementById('cc-meta').textContent =
        (client.weekTitle || 'Программа') +
        ' · последняя: ' + formatDaysAgo(client.lastWorkoutDaysAgo);

    // Кнопка архива в шапке
    var archBtn = document.getElementById('cc-archive-btn');
    if (archBtn) {
        archBtn.textContent = client.archived ? '↩️' : '📦';
        archBtn.title = client.archived ? 'Вернуть из архива' : 'В архив';
    }

    // Открыть экран
    var screen = document.getElementById('client-card-screen');
    screen.classList.remove('hidden');
    document.body.classList.add('no-scroll');

    // При смене клиента сбрасываем все кэши вкладок
    resetClientHistoryCache();
    notesLoadedFor = '';
    profileLoadedFor = '';
    statsLoadedFor = '';

    // Сбросить на вкладку "Программа"
    switchClientCardTab('program');
    loadClientProgram(client.sheetName);
}

async function closeClientCard() {
    var pendingCount = Object.keys(pendingExerciseEdits).length;
    if (pendingCount > 0) {
        var msg = 'Есть несохранённые изменения упражнений: ' + pendingCount + '.\n\nЗакрыть карточку без сохранения?';
        var ok = await tgConfirm(msg);
        if (!ok) return;
        discardPendingExerciseEdits();
    }
    _doCloseClientCard();
}

function _doCloseClientCard() {
    var screen = document.getElementById('client-card-screen');
    screen.classList.add('hidden');
    document.body.classList.remove('no-scroll');
    currentClientCard = null;
    pendingEmptyDays = [];
}

function switchClientCardTab(tabName) {
    document.querySelectorAll('.cc-tab-btn').forEach(function(btn) {
        btn.classList.toggle('active', btn.dataset.ccTab === tabName);
    });
    document.querySelectorAll('.cc-tab-content').forEach(function(content) {
        content.classList.remove('active');
    });
    document.getElementById('cc-' + tabName + '-tab').classList.add('active');

    // Лениво загружаем содержимое вкладки при первом открытии
    if (tabName === 'history' && currentClientCard) {
        loadClientHistory(currentClientCard.name);
    }
    if (tabName === 'notes' && currentClientCard) {
        loadClientNotes(currentClientCard.name);
        loadClientProfile(currentClientCard.chatId);
    }
    if (tabName === 'stats' && currentClientCard) {
        loadClientStats(currentClientCard.name, currentClientCard.chatId);
    }
    if (tabName === 'nutrition' && currentClientCard) {
        loadClientMealPlan(currentClientCard.chatId);
        loadClientFoodLog(currentClientCard.chatId);
    }
}

function initClientCardTabs() {
    document.querySelectorAll('.cc-tab-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            switchClientCardTab(btn.dataset.ccTab);
            if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred('light');
        });
    });
    var measSelect = document.getElementById('stats-meas-select');
    if (measSelect && !statsMeasSelectInitialized) {
        statsMeasSelectInitialized = true;
        measSelect.addEventListener('change', function() {
            statsMeasSelectedKey = measSelect.value;
            renderStatsMeasurements();
        });
    }
}

// Полные замеры клиента в статистике тренера — селектор метрики + график +
// сетка последних значений с разницей от предыдущего (та же логика, что уже
// была только на клиентской странице "Замеры" — раньше тренер видел только вес).
function renderStatsMeasurements() {
    var empty = document.getElementById('stats-meas-empty');
    var canvas = document.getElementById('stats-meas-chart');
    var select = document.getElementById('stats-meas-select');
    var grid = document.getElementById('stats-meas-latest-grid');
    if (!canvas || !empty || !grid) return;

    if (statsMeasChart) { try { statsMeasChart.destroy(); } catch (_) {} statsMeasChart = null; }

    if (statsMeasurements.length === 0) {
        empty.classList.remove('hidden');
        canvas.style.display = 'none';
        grid.innerHTML = '';
        return;
    }
    empty.classList.add('hidden');
    if (select) select.value = statsMeasSelectedKey;

    var filtered = statsMeasurements.filter(function(m) { return m[statsMeasSelectedKey] != null; });
    if (filtered.length < 2) {
        canvas.style.display = 'none';
    } else {
        canvas.style.display = '';
        var colors = {
            weight: '#1565C0', shoulders: '#455A64', chest: '#1565C0', waist: '#F57C00',
            hips: '#7B1FA2', bicep: '#2E7D32', thigh: '#C62828'
        };
        var color = colors[statsMeasSelectedKey] || '#1565C0';
        statsMeasChart = new Chart(canvas.getContext('2d'), {
            type: 'line',
            data: {
                labels: filtered.map(function(m) { return m.dateLabel; }),
                datasets: [{
                    label: MEAS_LABELS[statsMeasSelectedKey],
                    data: filtered.map(function(m) { return m[statsMeasSelectedKey]; }),
                    borderColor: color,
                    backgroundColor: color + '1A',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.3,
                    pointRadius: 4,
                    pointBackgroundColor: color,
                    pointBorderColor: '#fff'
                }]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    y: { ticks: { callback: function(v) { return v + ' ' + MEAS_UNITS[statsMeasSelectedKey]; } } },
                    x: { grid: { display: false } }
                }
            }
        });
    }

    // Сетка последних значений (все замеры разом) + разница от предыдущего.
    var latest = statsMeasurements[statsMeasurements.length - 1];
    var prev = statsMeasurements.length >= 2 ? statsMeasurements[statsMeasurements.length - 2] : null;
    var keys = ['weight', 'shoulders', 'chest', 'waist', 'hips', 'bicep', 'thigh'];
    grid.innerHTML = keys.map(function(key) {
        var val = latest[key];
        var diffHtml = '';
        if (prev && prev[key] != null && val != null) {
            var diff = (val - prev[key]).toFixed(1);
            if (diff > 0) diffHtml = '<span class="stats-meas-diff diff-up">+' + diff + '</span>';
            else if (diff < 0) diffHtml = '<span class="stats-meas-diff diff-down">' + diff + '</span>';
        }
        return '<div class="stats-meas-item">' +
            '<div class="stats-meas-item-value">' + (val != null ? val : '—') + diffHtml + '</div>' +
            '<div class="stats-meas-item-label">' + MEAS_LABELS[key] + '</div>' +
        '</div>';
    }).join('');
}

// ========== ПЛАН ПИТАНИЯ (вкладка "🍽 Питание" в карточке клиента) ==========

var currentMealPlanData = null;   // последний загруженный/сгенерированный план текущего клиента
var MEAL_PLAN_DEFAULT_MEALS = [
    { time: '8:00-9:00',   name: 'Завтрак' },
    { time: '13:00-14:00', name: 'Обед' },
    { time: '19:00-20:00', name: 'Ужин' },
    { time: '',            name: 'Перекус' }
];

// ── Авто-пересчёт КБЖУ в редакторе плана питания ──
// Меняешь калории — белки/жиры/углеводы (и калории/белки в каждом приёме пищи)
// пропорционально подтягиваются. Меняешь белки/жиры/углеводы — калории
// пересчитываются по формуле (белки и углеводы по 4 ккал/г, жиры — 9 ккал/г),
// а белок в приёмах пищи следует за белком (если менялся именно он).
var mpTargetsPrev = null;
var mpAutoCalcInitialized = false;

function initMealPlanAutoCalc() {
    if (mpAutoCalcInitialized) return;
    mpAutoCalcInitialized = true;
    ['calories', 'protein', 'fats', 'carbs'].forEach(function(field) {
        document.getElementById('mp-' + field).addEventListener('change', function() {
            handleMpTargetChange(field);
        });
    });
}

// Поле дневной цели, которое тренер заполнил сам, автопересчёт больше не
// трогает. Без этого получалось так: вписываешь 1900 ккал для выходного дня,
// потом белки — и калории тут же заменяются суммой из формулы (600). Со
// стороны это выглядит как «поле сбрасывается само».
function initMealPlanTargetGuard() {
    ['calories', 'protein', 'fats', 'carbs'].forEach(function(field) {
        var el = document.getElementById('mp-' + field);
        if (!el || el.dataset.guarded === '1') return;
        el.dataset.guarded = '1';
        el.addEventListener('input', function() { el.dataset.manual = '1'; });
    });
}

function _mpTargetIsManual(field) {
    var el = document.getElementById('mp-' + field);
    return !!(el && el.dataset.manual === '1');
}

function handleMpTargetChange(field) {
    var prev = mpTargetsPrev || { calories: 0, protein: 0, fats: 0, carbs: 0 };
    var cur = {
        calories: parseFloat(document.getElementById('mp-calories').value) || 0,
        protein: parseFloat(document.getElementById('mp-protein').value) || 0,
        fats: parseFloat(document.getElementById('mp-fats').value) || 0,
        carbs: parseFloat(document.getElementById('mp-carbs').value) || 0
    };

    if (field === 'calories') {
        var ratio = prev.calories > 0 ? cur.calories / prev.calories : null;
        if (ratio) {
            ['protein', 'fats', 'carbs'].forEach(function(macro) {
                if (_mpTargetIsManual(macro)) return;
                document.getElementById('mp-' + macro).value = Math.round(prev[macro] * ratio) || '';
            });
            _scaleMealFields(ratio, ratio);
        }
    } else {
        // Белки/жиры/углеводы → калории считаем по формуле, а не пропорцией.
        // Но только если калории не вписаны руками: там своя цифра от тренера.
        var newCalories = Math.round(cur.protein * 4 + cur.fats * 9 + cur.carbs * 4);
        if (!_mpTargetIsManual('calories')) {
            document.getElementById('mp-calories').value = newCalories || '';
        } else {
            newCalories = cur.calories;
        }
        var calRatio = prev.calories > 0 ? newCalories / prev.calories : null;
        var proteinRatio = (field === 'protein' && prev.protein > 0) ? cur.protein / prev.protein : null;
        _scaleMealFields(calRatio, proteinRatio);
    }

    // Перечитываем поля начисто — в обеих ветках выше значения могли поменяться
    // (пропорционально или по формуле), снимок должен отражать то, что реально в форме.
    mpTargetsPrev = {
        calories: parseFloat(document.getElementById('mp-calories').value) || 0,
        protein: parseFloat(document.getElementById('mp-protein').value) || 0,
        fats: parseFloat(document.getElementById('mp-fats').value) || 0,
        carbs: parseFloat(document.getElementById('mp-carbs').value) || 0
    };
}

// Пропорциональный пересчёт удобен, когда тренер двигает дневную цель и хочет,
// чтобы приёмы поехали следом. Но если цифру в приёме вписали РУКАМИ — её
// трогать нельзя: именно так и выглядела жалоба «вписываю КБЖУ, а оно не
// сохраняется» — значения молча перемасштабировались под цель. Поле, которого
// человек коснулся, дальше считается его собственным.
function _scaleMealFields(calRatio, proteinRatio) {
    document.querySelectorAll('.mp-meal-block').forEach(function(block) {
        var scale = function(field, ratio) {
            if (!ratio) return;
            var input = block.querySelector('[data-mp="' + field + '"]');
            if (!input || input.dataset.manual === '1') return;
            var val = parseFloat(input.value) || 0;
            if (val) input.value = Math.round(val * ratio);
        };
        scale('calories', calRatio);
        scale('protein', proteinRatio);
    });
}

// Помечаем поле как заполненное вручную. Слушатель один на весь список —
// блоки добавляются и удаляются на ходу, вешать на каждый вход отдельно
// значило бы не забыть сделать это в трёх местах.
function initMealPlanManualGuard() {
    var list = document.getElementById('mp-meals-list');
    if (!list || list.dataset.guarded === '1') return;
    list.dataset.guarded = '1';
    list.addEventListener('input', function(e) {
        var t = e.target;
        if (t && t.dataset && t.dataset.mp) t.dataset.manual = '1';
    });
}

// Собирает читаемое "Состав" из foods[] (для показа/редактирования одной строкой) —
// AI присылает продукты по отдельности, а для ручного ввода это одна строка текста.
function _mealFoodsToText(foods) {
    return (foods || []).map(function(f) {
        return f.name + (f.grams ? ' (' + f.grams + 'г)' : '');
    }).join(', ');
}

// Планов у клиента два: тренировочный день и день без тренировки —
// калорийность в них разная. Второй заводить необязательно: пока он пустой,
// переключателя нет вовсе и всё выглядит как раньше, с одним планом.
var MEAL_DAY_TYPES = [
    { key: 'workout', label: '🏋 Тренировочный день' },
    { key: 'rest',    label: '😌 День без тренировки' }
];
var currentMealPlanByDay = { workout: null, rest: null };
var mealPlanViewDay = 'workout';

function _mealDayLabel(key) {
    var t = MEAL_DAY_TYPES.filter(function(d) { return d.key === key; })[0];
    return t ? t.label : key;
}

function _fetchMealPlanForDay(chatId, dayType) {
    return fetch(APPS_SCRIPT_URL + '?action=getMealPlanForClient&targetChatId=' +
            encodeURIComponent(chatId) + '&dayType=' + encodeURIComponent(dayType))
        .then(function(r) { return r.json(); })
        .catch(function() { return { error: 'network' }; });
}

async function loadClientMealPlan(chatId) {
    var box = document.getElementById('mp-summary');
    box.innerHTML = '<div class="no-data">Загрузка плана питания...</div>';
    currentMealPlanData = null;
    currentMealPlanByDay = { workout: null, rest: null };
    try {
        var both = await Promise.all([
            _fetchMealPlanForDay(chatId, 'workout'),
            _fetchMealPlanForDay(chatId, 'rest')
        ]);
        if (both[0] && both[0].error && both[1] && both[1].error) {
            box.innerHTML = '<div class="no-data">Не удалось загрузить ❌</div>';
            return;
        }
        currentMealPlanByDay.workout = (both[0] && both[0].exists) ? both[0] : null;
        currentMealPlanByDay.rest = (both[1] && both[1].exists) ? both[1] : null;
        if (!currentMealPlanByDay.workout && !currentMealPlanByDay.rest) {
            box.innerHTML = '<div class="no-data">Плана питания пока нет — составь вручную или сгенерируй через ИИ</div>';
            return;
        }
        // Остаёмся на том дне, который смотрели: иначе после сохранения плана
        // для выходного экран прыгал на тренировочный, показывал ЕГО цифры, и
        // это выглядело как «выходной день не сохранился». Если у выбранного
        // дня плана нет — открываем заполненный, чтобы не упираться в пустую
        // вкладку (у большинства тренеров второго плана не будет никогда).
        if (!currentMealPlanByDay[mealPlanViewDay]) {
            mealPlanViewDay = currentMealPlanByDay.workout ? 'workout' : 'rest';
        }
        renderMealPlanView();
    } catch (e) {
        console.error('loadClientMealPlan failed:', e);
        box.innerHTML = '<div class="no-data">Не удалось загрузить ❌</div>';
    }
}

function switchMealPlanDay(dayType) {
    mealPlanViewDay = dayType;
    renderMealPlanView();
}

function renderMealPlanView() {
    var box = document.getElementById('mp-summary');
    var hasBoth = !!(currentMealPlanByDay.workout && currentMealPlanByDay.rest);
    var head = '';
    if (hasBoth) {
        head = '<div class="mp-day-switch">' + MEAL_DAY_TYPES.map(function(d) {
            return '<button type="button" class="mp-day-btn' + (d.key === mealPlanViewDay ? ' active' : '') +
                '" onclick="switchMealPlanDay(\'' + d.key + '\')">' + d.label + '</button>';
        }).join('') + '</div>';
    }
    var data = currentMealPlanByDay[mealPlanViewDay];
    currentMealPlanData = data;
    if (!data) {
        box.innerHTML = head + '<div class="no-data">Для этого дня плана пока нет</div>';
        return;
    }
    box.innerHTML = head + (hasBoth ? '' : '<div class="mp-day-tag">' + _mealDayLabel(mealPlanViewDay) + '</div>') +
        renderMealPlanSummary(data);
}

function renderMealPlanSummary(data) {
    var html = '<div class="mp-macro-grid">' +
        '<div class="mp-macro-card"><div class="mp-macro-value">' + (data.target_calories || 0) + '</div><div class="mp-macro-label">ккал</div></div>' +
        '<div class="mp-macro-card"><div class="mp-macro-value">' + (data.target_protein || 0) + '</div><div class="mp-macro-label">белки</div></div>' +
        '<div class="mp-macro-card"><div class="mp-macro-value">' + (data.target_fats || 0) + '</div><div class="mp-macro-label">жиры</div></div>' +
        '<div class="mp-macro-card"><div class="mp-macro-value">' + (data.target_carbs || 0) + '</div><div class="mp-macro-label">углеводы</div></div>' +
    '</div>';
    (data.meals || []).forEach(function(meal) {
        html += '<div class="mp-meal-summary-item">' +
            '<div class="mp-meal-summary-name">' + _escHtml(meal.name || 'Приём пищи') + '</div>' +
            '<div class="mp-meal-summary-meta">' + (meal.time || '') +
                (meal.total_calories ? ' · ' + meal.total_calories + ' ккал' : '') +
                (meal.total_protein ? ' · Б: ' + meal.total_protein + 'г' : '') +
                (meal.total_fats ? ' · Ж: ' + meal.total_fats + 'г' : '') +
                (meal.total_carbs ? ' · У: ' + meal.total_carbs + 'г' : '') + '</div>' +
            (meal.foods && meal.foods.length ? '<div class="mp-meal-summary-desc">' + _mealFoodsToText(meal.foods) + '</div>' : '') +
        '</div>';
    });
    if (data.notes) {
        html += '<div class="mp-notes-summary">💬 ' + _escHtml(data.notes) + '</div>';
    }
    // Возвращаем разметку, а не пишем в DOM: над ней ещё встаёт переключатель
    // дня (см. renderMealPlanView), и собирать страницу должен кто-то один.
    html += '<div class="mp-macro-hint">Показаны цифры за день · ' + _mealDayLabel(data.dayType || 'workout') + '</div>';
    return html;
}

var mpEditorDay = 'workout';
var mpEditorDrafts = { workout: null, rest: null };

function _fillMealPlanForm(d) {
    // Пометки «вписано руками» принадлежат КОНКРЕТНОМУ дню: при переключении
    // на другой план их надо снять, иначе автопересчёт замолчит и там, где
    // тренер ничего не трогал.
    ['calories', 'protein', 'fats', 'carbs'].forEach(function(field) {
        var el = document.getElementById('mp-' + field);
        if (el) delete el.dataset.manual;
    });
    document.getElementById('mp-calories').value = d ? (d.target_calories || '') : '';
    document.getElementById('mp-protein').value = d ? (d.target_protein || '') : '';
    document.getElementById('mp-fats').value = d ? (d.target_fats || '') : '';
    document.getElementById('mp-carbs').value = d ? (d.target_carbs || '') : '';
    document.getElementById('mp-notes').value = d ? (d.notes || '') : '';
    mpTargetsPrev = {
        calories: (d && d.target_calories) || 0,
        protein: (d && d.target_protein) || 0,
        fats: (d && d.target_fats) || 0,
        carbs: (d && d.target_carbs) || 0
    };
    var meals = (d && d.meals && d.meals.length) ? d.meals : MEAL_PLAN_DEFAULT_MEALS;
    var list = document.getElementById('mp-meals-list');
    list.innerHTML = meals.map(_mealBlockHtml).join('');
    _renumberMealBlocks();
}

// Всё, что сейчас в форме — как объект плана. Нужна и при сохранении, и при
// переключении дня: иначе набранное в тренировочном дне терялось бы, стоило
// заглянуть во второй.
function _collectMealPlanForm() {
    var meals = [];
    document.querySelectorAll('#mp-meals-list .mp-meal-block').forEach(function(block) {
        var val = function(f) { return block.querySelector('[data-mp="' + f + '"]').value.trim(); };
        var num = function(f) { return parseInt(val(f), 10) || 0; };
        var name = val('name');
        var calories = num('calories');
        var desc = val('desc');
        // Одно название без цифр и состава — не приём пищи, а подпись из
        // заготовки формы. Раньше такие уходили на сервер, и клиенту в боте
        // приходил список «Завтрак — 0 ккал, Обед — 0 ккал»: тренер задал
        // только цели на день, а выглядело как недописанный план.
        if (!calories && !desc) return;
        meals.push({
            name: name || 'Приём пищи',
            time: val('time'),
            foods: desc ? [{ name: desc, grams: 0, calories: calories, protein: num('protein'), fats: num('fats'), carbs: num('carbs') }] : [],
            total_calories: calories,
            total_protein: num('protein'),
            total_fats: num('fats'),
            total_carbs: num('carbs')
        });
    });
    return {
        target_calories: parseInt(document.getElementById('mp-calories').value, 10) || 0,
        target_protein: parseInt(document.getElementById('mp-protein').value, 10) || 0,
        target_fats: parseInt(document.getElementById('mp-fats').value, 10) || 0,
        target_carbs: parseInt(document.getElementById('mp-carbs').value, 10) || 0,
        meals: meals,
        notes: document.getElementById('mp-notes').value.trim()
    };
}

// Пустой день не сохраняем: иначе у клиента, которому второй план не нужен,
// в базе появлялся бы план-пустышка, а в мини-аппе — вкладка ни с чем.
// Пересчёт приёмов под изменённые цели дня. Появилось из живого случая:
// ИИ выдал рацион, тренер поднял БЖУ — а приёмы пищи остались прежними, и
// по граммовкам видно, что еды меньше, чем в целях. Считаем коэффициент по
// калориям (сумма приёмов → цель) и применяем его ко всему: КБЖУ приёма и
// граммовкам продуктов в составе.
function _scaleGramsInText(text, ratio) {
    // "Овсянка (60г), Яйца куриные (120г)" → те же продукты с новым весом.
    // Трогаем только числа перед «г» в скобках: остальные цифры в названии
    // («Творог 5%», «Хлеб 2 куска») — не вес, и менять их нельзя.
    return (text || '').replace(/\((\d+(?:[.,]\d+)?)\s*г\)/gi, function(_, num) {
        var v = parseFloat(String(num).replace(',', '.')) * ratio;
        return '(' + (v >= 10 ? Math.round(v) : Math.round(v * 10) / 10) + 'г)';
    });
}

function recalcMealsToTargets() {
    var targetCalories = parseInt(document.getElementById('mp-calories').value, 10) || 0;
    if (!targetCalories) {
        tg.showAlert('Сначала укажи калории на день');
        return;
    }
    var blocks = Array.prototype.slice.call(document.querySelectorAll('#mp-meals-list .mp-meal-block'));
    var sum = blocks.reduce(function(acc, b) {
        return acc + (parseFloat(b.querySelector('[data-mp="calories"]').value) || 0);
    }, 0);
    if (!sum) {
        tg.showAlert('Нечего пересчитывать: в приёмах пищи не проставлены калории');
        return;
    }
    var ratio = targetCalories / sum;
    blocks.forEach(function(block) {
        ['calories', 'protein', 'fats', 'carbs'].forEach(function(field) {
            var input = block.querySelector('[data-mp="' + field + '"]');
            var val = parseFloat(input.value) || 0;
            if (val) input.value = Math.round(val * ratio);
        });
        var desc = block.querySelector('[data-mp="desc"]');
        if (desc && desc.value) desc.value = _scaleGramsInText(desc.value, ratio);
    });
    if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
    var pct = Math.round((ratio - 1) * 100);
    tg.showAlert(pct === 0
        ? 'Приёмы уже сходятся с целью'
        : ('Порции ' + (pct > 0 ? 'увеличены' : 'уменьшены') + ' на ' + Math.abs(pct) + '% — проверь и сохрани'));
}

function _mealPlanIsEmpty(plan) {
    return !plan || (!plan.target_calories && !plan.notes && !(plan.meals || []).length);
}

function _renderMealPlanEditorTabs() {
    var box = document.getElementById('mp-editor-tabs');
    if (!box) return;
    box.innerHTML = MEAL_DAY_TYPES.map(function(d) {
        var filled = !_mealPlanIsEmpty(mpEditorDrafts[d.key]) ? ' filled' : '';
        return '<button type="button" class="mp-day-btn' + (d.key === mpEditorDay ? ' active' : '') + filled +
            '" onclick="switchMealPlanEditorDay(\'' + d.key + '\')">' + d.label + '</button>';
    }).join('');
}

function switchMealPlanEditorDay(dayType) {
    if (dayType === mpEditorDay) return;
    mpEditorDrafts[mpEditorDay] = _collectMealPlanForm();
    mpEditorDay = dayType;
    _fillMealPlanForm(mpEditorDrafts[dayType]);
    _renderMealPlanEditorTabs();
}

// seedPlan — готовый план, который надо положить в форму вместо
// сохранённого: так возвращается результат ИИ-генерации. Без этого он
// открывал редактор со СТАРЫМ планом, тренер жал «Сохранить» — и старые
// цифры уезжали во второй день, выглядело как «один план затирает другой».
function openMealPlanEditor(seedPlan) {
    mpEditorDrafts = {
        workout: currentMealPlanByDay.workout,
        rest: currentMealPlanByDay.rest
    };
    mpEditorDay = mealPlanViewDay || 'workout';
    if (seedPlan) mpEditorDrafts[mpEditorDay] = seedPlan;
    initMealPlanAutoCalc();
    initMealPlanManualGuard();
    initMealPlanTargetGuard();
    _renderMealPlanEditorTabs();
    _fillMealPlanForm(mpEditorDrafts[mpEditorDay]);

    document.getElementById('mp-editor-modal').classList.remove('hidden');
    document.body.classList.add('no-scroll');
}

// Приём пищи: КБЖУ целиком, а не только калории и белки. Жиры с углеводами
// раньше в форме отсутствовали и уходили на сервер нулями — тренер вписывал
// цифры в план, а обратно получал прочерки (жалоба Анны «КБЖУ не
// сохраняется»). Хранилище тут ни при чём: meals лежит в JSONB, лишние поля
// принимает без всякой миграции.
function _mealBlockHtml(meal) {
    meal = meal || {};
    var esc = function(v) { return String(v == null ? '' : v).replace(/"/g, '&quot;'); };
    return '<div class="mp-meal-block">' +
        '<div class="mp-meal-block-head">' +
            '<div class="mp-meal-block-title"></div>' +
            '<button type="button" class="mp-meal-del" onclick="removeMealBlock(this)" title="Убрать приём пищи">✕</button>' +
        '</div>' +
        '<div class="mp-meal-row">' +
            '<input type="text" class="ex-editor-input" data-mp="name" placeholder="Название" value="' + esc(meal.name) + '">' +
            '<input type="text" class="ex-editor-input" data-mp="time" placeholder="Время" value="' + esc(meal.time) + '">' +
        '</div>' +
        '<div class="mp-meal-row">' +
            '<input type="number" inputmode="numeric" class="ex-editor-input" data-mp="calories" placeholder="Калории" value="' + esc(meal.total_calories || '') + '">' +
            '<input type="number" inputmode="numeric" class="ex-editor-input" data-mp="protein" placeholder="Белки, г" value="' + esc(meal.total_protein || '') + '">' +
        '</div>' +
        '<div class="mp-meal-row">' +
            '<input type="number" inputmode="numeric" class="ex-editor-input" data-mp="fats" placeholder="Жиры, г" value="' + esc(meal.total_fats || '') + '">' +
            '<input type="number" inputmode="numeric" class="ex-editor-input" data-mp="carbs" placeholder="Углеводы, г" value="' + esc(meal.total_carbs || '') + '">' +
        '</div>' +
        '<textarea class="ex-editor-textarea" data-mp="desc" rows="2" placeholder="Состав (например: Овсянка 80г, банан 1шт)">' +
            (meal.foods ? _mealFoodsToText(meal.foods) : '') +
        '</textarea>' +
    '</div>';
}

// Нумерация — не в разметке блока, иначе после добавления или удаления
// приёма подписи разъезжаются («Приём пищи 2, 4, 5»).
function _renumberMealBlocks() {
    document.querySelectorAll('#mp-meals-list .mp-meal-block').forEach(function(block, i) {
        block.querySelector('.mp-meal-block-title').textContent = 'Приём пищи ' + (i + 1);
    });
}

// Приёмов бывает и шесть: при инсулинорезистентности едят чаще, и жёсткие
// четыре блока такому клиенту просто не подходят (просьба Анны).
function addMealBlock() {
    var list = document.getElementById('mp-meals-list');
    list.insertAdjacentHTML('beforeend', _mealBlockHtml({}));
    _renumberMealBlocks();
    var added = list.lastElementChild;
    if (added) {
        added.scrollIntoView({ behavior: 'smooth', block: 'center' });
        added.querySelector('[data-mp="name"]').focus();
    }
}

function removeMealBlock(btn) {
    var block = btn.closest('.mp-meal-block');
    if (block) block.remove();
    _renumberMealBlocks();
}

function closeMealPlanEditor() {
    document.getElementById('mp-editor-modal').classList.add('hidden');
    document.body.classList.remove('no-scroll');
}

async function saveMealPlanFromEditor() {
    if (!currentClientCard) return;
    var btn = document.getElementById('mp-save-btn');
    var origText = btn.textContent;
    btn.disabled = true;
    btn.textContent = '⏳ Сохранение...';

    mpEditorDrafts[mpEditorDay] = _collectMealPlanForm();

    // Сохраняем оба дня одним действием: тренер мог поправить тренировочный,
    // переключиться на выходной и нажать «Сохранить» там — ожидание, что
    // сохранилось всё, а не только видимая вкладка.
    var toSave = MEAL_DAY_TYPES.map(function(d) { return d.key; }).filter(function(key) {
        var draft = mpEditorDrafts[key];
        if (_mealPlanIsEmpty(draft)) return false;
        return true;
    });

    if (!toSave.length) {
        tg.showAlert('Нечего сохранять — заполни цели или приёмы пищи');
        btn.disabled = false;
        btn.textContent = origText;
        return;
    }

    try {
        var myChatId = _myChatId();
        for (var i = 0; i < toSave.length; i++) {
            var dayType = toSave[i];
            var plan = mpEditorDrafts[dayType];
            plan.dayType = dayType;
            var resp = await fetch(APPS_SCRIPT_URL + '?action=saveMealPlan&chatId=' + encodeURIComponent(myChatId), {
                method: 'POST',
                body: JSON.stringify({
                    client_name: currentClientCard.name,
                    plan: plan,
                    client_data: { weight: '', height: '', age: '', goal: '', allergies: '' }
                })
            });
            var data = await resp.json();
            if (!data.success) {
                tg.showAlert('Ошибка (' + _mealDayLabel(dayType) + '): ' + (data.error || 'не удалось сохранить'));
                btn.disabled = false;
                btn.textContent = origText;
                return;
            }
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        closeMealPlanEditor();
        btn.disabled = false;
        btn.textContent = origText;
        // Показываем тот день, который только что правили.
        mealPlanViewDay = mpEditorDay;
        await loadClientMealPlan(currentClientCard.chatId);
        tg.showAlert(toSave.length > 1
            ? '✅ Сохранены оба плана: тренировочный день и день без тренировки'
            : ('✅ Сохранён план: ' + _mealDayLabel(toSave[0])));
    } catch (e) {
        console.error('saveMealPlanFromEditor error:', e);
        tg.showAlert('Ошибка соединения ❌');
        btn.disabled = false;
        btn.textContent = origText;
    }
}

async function openMealPlanAiForm() {
    if (!currentClientCard) return;
    // Какой именно день сейчас составляем — иначе тренер, стоя на выходном
    // дне, не поймёт, куда уедет сгенерированный план.
    var dayHint = document.getElementById('mp-ai-day');
    if (dayHint) dayHint.textContent = 'План для: ' + _mealDayLabel(mealPlanViewDay || 'workout');
    document.getElementById('mp-ai-weight').value = '';
    document.getElementById('mp-ai-height').value = '';
    document.getElementById('mp-ai-age').value = '';
    document.getElementById('mp-ai-goal').value = '';
    document.getElementById('mp-ai-allergies').value = '';
    try {
        var resp = await fetch(APPS_SCRIPT_URL + '?action=getClientProfile&targetChatId=' + encodeURIComponent(currentClientCard.chatId));
        var p = await resp.json();
        if (!p.error) {
            document.getElementById('mp-ai-weight').value = p.weight || '';
            document.getElementById('mp-ai-height').value = p.height || '';
            document.getElementById('mp-ai-age').value = p.age || '';
            var goalLabels = { loss: 'Похудение', mass: 'Набор массы', tone: 'Тонус / поддержание', strength: 'Сила' };
            document.getElementById('mp-ai-goal').value = goalLabels[p.goal] || p.goal || '';
        }
    } catch (e) { /* анкета не обязательна — просто оставим поля пустыми */ }

    document.getElementById('mp-ai-modal').classList.remove('hidden');
    document.body.classList.add('no-scroll');
}

function closeMealPlanAiForm() {
    document.getElementById('mp-ai-modal').classList.add('hidden');
    document.body.classList.remove('no-scroll');
}

async function runMealPlanAiGeneration() {
    if (!currentClientCard) return;
    var btn = document.getElementById('mp-ai-generate-btn');
    var origText = btn.textContent;
    btn.disabled = true;
    btn.textContent = '🤖 Генерирую... (~30 сек)';

    var payload = {
        clientName: currentClientCard.name,
        weight: document.getElementById('mp-ai-weight').value.trim(),
        height: document.getElementById('mp-ai-height').value.trim(),
        age: document.getElementById('mp-ai-age').value.trim(),
        goal: document.getElementById('mp-ai-goal').value.trim(),
        allergies: document.getElementById('mp-ai-allergies').value.trim()
    };

    try {
        var resp = await fetch(APPS_SCRIPT_URL + '?action=generateMealPlanAI', {
            method: 'POST',
            body: JSON.stringify(payload)
        });
        var data = await resp.json();
        btn.disabled = false;
        btn.textContent = origText;
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось сгенерировать'));
            return;
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        closeMealPlanAiForm();
        // Открываем редактор сразу с результатом ИИ — тренер проверяет/правит
        // перед сохранением. План кладётся в тот день, который сейчас открыт
        // (тренировочный или выходной), а не поверх обоих.
        openMealPlanEditor(Object.assign({}, data.plan));
    } catch (e) {
        console.error('runMealPlanAiGeneration error:', e);
        tg.showAlert('Ошибка соединения ❌');
        btn.disabled = false;
        btn.textContent = origText;
    }
}

function toggleArchiveFromCard() {
    if (!currentClientCard) return;
    var newState = !currentClientCard.archived;
    toggleArchiveClient(currentClientCard.chatId, newState).then(function() {
        // После архивирования закрываем карточку (клиент исчез из основного списка)
        if (newState) closeClientCard();
        else {
            // Обновим кнопку
            var archBtn = document.getElementById('cc-archive-btn');
            if (archBtn) {
                archBtn.textContent = currentClientCard.archived ? '↩️' : '📦';
                archBtn.title = currentClientCard.archived ? 'Вернуть из архива' : 'В архив';
            }
        }
    });
}

async function loadClientProgram(sheetName) {
    var container = document.getElementById('cc-program-container');
    container.innerHTML = '<div class="no-data">Загрузка программы...</div>';
    try {
        var url = APPS_SCRIPT_URL + '?action=readClientProgram&sheetName=' + encodeURIComponent(sheetName);
        var response = await fetch(url);
        var data = await response.json();
        if (data.error) {
            container.innerHTML = '<div class="no-data">Ошибка: ' + data.error + '</div>';
            return;
        }
        renderClientProgram(data);
        // После рендера DOM пересоздан — заново подсвечиваем строки, у которых остались
        // не сохранённые правки (на случай если очередь не была пуста перед reload'ом).
        Object.keys(pendingExerciseEdits).forEach(function(rowIdx) {
            markExerciseDirty(rowIdx);
        });
        updateBulkSaveBar();
    } catch (error) {
        console.error('Load client program error:', error);
        container.innerHTML = '<div class="no-data">Ошибка загрузки программы</div>';
    }
}

// Префикс «СЕТ:» — суперсет (2 упражнения подряд).
// Префикс «ТРИСЕТ:» — трисет (3 упражнения подряд).
// Префикс «КРУГОВАЯ N:» — круг из N упражнений (обычно 4–8). Число в самом
// префиксе не для красоты: у суперсета и трисета размер известен заранее, а
// у круга — нет, и без него непонятно, где связка заканчивается и начинается
// обычное упражнение.
// Блоки с произвольным числом упражнений: круг, разминка, заминка. Размер
// пишется в самом префиксе («КРУГОВАЯ 5:»), потому что заранее он неизвестен —
// в отличие от суперсета и трисета, где длина связки задана названием.
var NUMBERED_BLOCKS = [
    { type: 'circuit',  prefix: 'КРУГОВАЯ', re: /^кругова[яй]\s*(\d+)?\s*:/i, label: '🔄 Круговая',  short: 'Круговая',  defaultSize: 5 },
    { type: 'warmup',   prefix: 'РАЗМИНКА', re: /^разминка\s*(\d+)?\s*:/i,     label: '🤸 Разминка',  short: 'Разминка',  defaultSize: 4 },
    { type: 'cooldown', prefix: 'ЗАМИНКА',  re: /^заминка\s*(\d+)?\s*:/i,      label: '🧘 Заминка',   short: 'Заминка',   defaultSize: 4 }
];

function blockTypeInfo(type) {
    return NUMBERED_BLOCKS.filter(function(b) { return b.type === type; })[0] || null;
}

// {type, size} у упражнения, открывающего блок, иначе null.
function numberedBlockStart(ex) {
    var name = (ex && ex.exercise ? ex.exercise : '').toString().trim();
    for (var i = 0; i < NUMBERED_BLOCKS.length; i++) {
        var b = NUMBERED_BLOCKS[i];
        var m = b.re.exec(name);
        if (!m) continue;
        var n = parseInt(m[1], 10);
        // Без числа (тренер написал префикс руками) — размер по умолчанию.
        return { type: b.type, size: (n && n >= 2) ? n : b.defaultSize };
    }
    return null;
}

// Оставлено для совместимости с прежними вызовами.
function circuitSize(ex) {
    var start = numberedBlockStart(ex);
    return (start && start.type === 'circuit') ? start.size : 0;
}

function isSupersetStart(ex) {
    var name = (ex && ex.exercise ? ex.exercise : '').toString().trim();
    return /^сет\s*:/i.test(name);
}

function isTrisetStart(ex) {
    var name = (ex && ex.exercise ? ex.exercise : '').toString().trim();
    return /^трисет\s*:/i.test(name);
}

function cleanExerciseName(name) {
    return (name || '').toString()
        .replace(/^\s*кругова[яй]\s*\d*\s*:\s*/i, '')
        .replace(/^\s*разминка\s*\d*\s*:\s*/i, '')
        .replace(/^\s*заминка\s*\d*\s*:\s*/i, '')
        .replace(/^\s*трисет\s*:\s*/i, '')
        .replace(/^\s*сет\s*:\s*/i, '')
        .trim();
}

// Превращает плоский список упражнений в массив групп:
// { type: 'single' | 'superset' | 'triset' | 'circuit', exercises: [...], number: <номер для отображения> }
function groupExercises(exercises) {
    var groups = [];
    var displayNum = 0;
    var i = 0;
    while (i < exercises.length) {
        var ex = exercises[i];
        var block = numberedBlockStart(ex);
        if (block && i + 1 < exercises.length) {
            // Берём не больше, чем реально осталось в дне: упражнение из блока
            // могли удалить, и уводить группировку за край списка нельзя.
            var take = Math.min(block.size, exercises.length - i);
            // 2026-08-31 (M-4). И не больше, чем до начала СЛЕДУЮЩЕГО блока.
            // Если тренер написал «КРУГОВАЯ 5», а в круге по факту три
            // упражнения, блок молча забирал два следующих — в том числе
            // начало разминки или заминки — и подписывал их как часть круга.
            // Данные при этом не терялись, но структура тренировки на экране
            // у клиента была не та, что расписал тренер, и заметить это было
            // невозможно. Теперь блок останавливается на границе следующего.
            for (var k = 1; k < take; k++) {
                if (numberedBlockStart(exercises[i + k])) { take = k; break; }
            }
            displayNum++;
            groups.push({
                type: block.type, exercises: exercises.slice(i, i + take), number: displayNum,
                // Сколько тренер ЗАЯВИЛ в названии блока — нужно, чтобы
                // показать ему расхождение (см. M-4 в карточке клиента).
                declaredSize: block.size
            });
            i += take;
        } else if (isTrisetStart(ex) && i + 2 < exercises.length) {
            displayNum++;
            groups.push({ type: 'triset', exercises: [exercises[i], exercises[i + 1], exercises[i + 2]], number: displayNum });
            i += 3;
        } else if (isSupersetStart(ex) && i + 1 < exercises.length) {
            displayNum++;
            groups.push({ type: 'superset', exercises: [exercises[i], exercises[i + 1]], number: displayNum });
            i += 2;
        } else {
            displayNum++;
            groups.push({ type: 'single', exercises: [ex], number: displayNum });
            i += 1;
        }
    }
    return groups;
}

// Кэш всех упражнений текущей программы (для лёгкого поиска по rowIndex)
var currentProgramExercisesByRow = {};

// Экранируем кавычки для безопасной вставки в onclick=""
function escAttr(s) { return (s == null ? '' : s.toString()).replace(/"/g, '&quot;').replace(/'/g, "\\'"); }

// Рендер одного упражнения внутри блока (без обёртки cc-exercise — для суперсета используется cc-exercise-inner)
function renderExerciseRow(ex, label) {
    var weightPlan = (ex.weightPlan !== '' && ex.weightPlan != null) ? ex.weightPlan : '—';
    var reps = (ex.reps !== '' && ex.reps != null) ? ex.reps : '—';
    var sets = (ex.sets !== '' && ex.sets != null) ? ex.sets : '—';
    var rpe = (ex.rpe !== '' && ex.rpe != null) ? ex.rpe : '—';
    var done = (ex.weightFact !== '' && ex.weightFact != null && ex.weightFact !== 0)
        || (ex.repsFact !== '' && ex.repsFact != null && ex.repsFact !== 0);
    var factHtml = done
        ? '<div class="cc-ex-fact">Факт: ' + _escHtml(ex.weightFact || '—') + ' кг × ' + _escHtml(ex.repsFact || '—') + '</div>'
        : '';
    var noteHtml = (ex.note && ex.note.toString().trim())
        ? '<div class="cc-ex-note">' + _escHtml(ex.note) + '</div>' : '';
    var labelHtml = label
        ? '<span class="cc-ex-suplabel">' + label + '</span>' : '';
    var editBtn = ex.rowIndex
        ? '<button class="cc-ex-edit-btn" onclick="openExerciseEditor(' + ex.rowIndex + ')" title="Редактировать">✏️</button>'
        : '';
    return '<div class="cc-ex-row">' +
        '<div class="cc-ex-name-row">' +
            '<div class="cc-ex-name">' + labelHtml + _escHtml(cleanExerciseName(ex.exercise)) + '</div>' +
            editBtn +
        '</div>' +
        '<div class="cc-ex-grid">' +
            '<div class="cc-ex-cell"><div class="cc-cell-label">Вес</div><div class="cc-cell-value">' + weightPlan + ' кг</div></div>' +
            '<div class="cc-ex-cell"><div class="cc-cell-label">Повт.</div><div class="cc-cell-value">' + reps + '</div></div>' +
            '<div class="cc-ex-cell"><div class="cc-cell-label">Подх.</div><div class="cc-cell-value">' + sets + '</div></div>' +
            '<div class="cc-ex-cell"><div class="cc-cell-label">RPE</div><div class="cc-cell-value">' + rpe + '</div></div>' +
        '</div>' +
        factHtml +
        noteHtml +
    '</div>';
}

// ========== ДЕЙСТВИЯ С ПРОГРАММОЙ КЛИЕНТА (Фаза 2F) ==========

// Дублировать неделю — план остаётся, факты стираются, заголовок инкрементируется
// (автоподбор весов временно отключён, подключим в следующей итерации через ИИ)
function duplicateWeekFlow() {
    if (!currentClientCard) return;
    var name = currentClientCard.name || 'клиента';
    document.getElementById('new-week-client-line').textContent =
        'Для ' + name + '. План упражнений остаётся тем же, факты прошлой недели будут стёрты.';
    document.getElementById('new-week-autoprogress').checked = true;
    document.getElementById('new-week-modal').classList.remove('hidden');
    document.body.classList.add('no-scroll');
}

function closeNewWeekModal() {
    document.getElementById('new-week-modal').classList.add('hidden');
    document.body.classList.remove('no-scroll');
}

async function confirmNewWeek() {
    if (!currentClientCard) return;
    var autoProgress = document.getElementById('new-week-autoprogress').checked;
    var btn = document.getElementById('new-week-create-btn');
    var origText = btn.textContent;
    btn.disabled = true;
    btn.textContent = '⏳ Создание...';

    try {
        var url = APPS_SCRIPT_URL + '?action=duplicateClientWeek' +
            '&sheetName=' + encodeURIComponent(currentClientCard.sheetName) +
            '&autoProgress=' + (autoProgress ? 'true' : 'false');
        var resp = await fetch(url);
        var data = await resp.json();
        btn.disabled = false;
        btn.textContent = origText;
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось'));
            return;
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        closeNewWeekModal();
        if (data.newTitle) {
            currentClientCard.weekTitle = data.newTitle;
            document.getElementById('cc-meta').textContent = data.newTitle;
        }
        await loadClientProgram(currentClientCard.sheetName);
        tg.showAlert('✅ Новая неделя создана: ' + (data.newTitle || '') +
            (autoProgress ? '\n\nВеса подобраны автоматически — проверь и поправь при желании.' : ''));
    } catch (error) {
        console.error('Duplicate week error:', error);
        btn.disabled = false;
        btn.textContent = origText;
        tg.showAlert('Ошибка соединения ❌');
    }
}

// Отправить клиенту уведомление о том, что программа обновлена
async function notifyClientFlow() {
    if (!currentClientCard || !currentClientCard.chatId) return;
    var name = currentClientCard.name || 'клиенту';
    var confirmed = await tgConfirm('Отправить ' + name + ' уведомление о том, что программа обновлена?');
    if (!confirmed) return;

    try {
        var url = APPS_SCRIPT_URL + '?action=notifyClient' +
            '&targetChatId=' + encodeURIComponent(currentClientCard.chatId);
        var resp = await fetch(url);
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось отправить'));
            return;
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        tg.showAlert('✅ Уведомление отправлено');
    } catch (error) {
        console.error('Notify error:', error);
        // Текст ошибки в самом сообщении: «ошибка соединения» без подробностей
        // невозможно диагностировать по скриншоту, а именно скриншот и
        // присылают, когда что-то не отправилось.
        tg.showAlert('Не удалось отправить ❌\n\n' + ((error && error.message) || 'нет связи с сервером'));
    }
}

// Объединить упражнение с идущим сразу за ним в сет/трисет — задним числом,
// без специальной формы добавления. Суперсет/трисет в этом коде — это просто
// префикс "Сет:"/"Трисет:" у ПЕРВОГО упражнения группы + соседние строки
// (см. isSupersetStart/isTrisetStart/groupExercises выше), так что достаточно
// переписать название через уже существующее updateClientExercise.
async function mergeExercises(rowIndex, isUpgradeToTriset) {
    var ex = currentProgramExercisesByRow[rowIndex];
    if (!ex || !currentClientCard) return;
    var currentName = cleanExerciseName(ex.exercise);
    var newPrefix = isUpgradeToTriset ? 'Трисет: ' : 'Сет: ';
    var msg = isUpgradeToTriset
        ? 'Сделать трисет из «' + currentName + '» и следующего упражнения?'
        : 'Объединить «' + currentName + '» со следующим упражнением в сет?';
    var confirmed = await tgConfirm(msg);
    if (!confirmed) return;
    try {
        var url = APPS_SCRIPT_URL + '?action=updateClientExercise' +
            '&sheetName=' + encodeURIComponent(currentClientCard.sheetName) +
            '&rowIndex=' + rowIndex +
            '&exercise=' + encodeURIComponent(newPrefix + currentName);
        var resp = await fetch(url);
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось'));
            return;
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        await loadClientProgram(currentClientCard.sheetName);
    } catch (e) {
        tg.showAlert('Ошибка соединения ❌');
    }
}

// Разъединить сет/трисет обратно на отдельные упражнения — убираем префикс у
// первого упражнения группы, остальные строки не трогаем (они и так обычные).
async function splitGroup(firstRowIndex) {
    var ex = currentProgramExercisesByRow[firstRowIndex];
    if (!ex || !currentClientCard) return;
    var confirmed = await tgConfirm('Разъединить группу обратно на отдельные упражнения?');
    if (!confirmed) return;
    try {
        var url = APPS_SCRIPT_URL + '?action=updateClientExercise' +
            '&sheetName=' + encodeURIComponent(currentClientCard.sheetName) +
            '&rowIndex=' + firstRowIndex +
            '&exercise=' + encodeURIComponent(cleanExerciseName(ex.exercise));
        var resp = await fetch(url);
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось'));
            return;
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        await loadClientProgram(currentClientCard.sheetName);
    } catch (e) {
        tg.showAlert('Ошибка соединения ❌');
    }
}

function renderClientProgram(data) {
    var container = document.getElementById('cc-program-container');
    var days = (data.days || []).slice();
    // Дни, созданные только что и ещё пустые, бэкенд не вернёт — добавляем их
    // сами. Если в день уже успели положить упражнение, он придёт с бэкенда,
    // и дубликат тут не появится.
    pendingEmptyDays.forEach(function(name) {
        var already = days.some(function(d) { return (d.day || '') === name; });
        if (!already) days.push({ day: name, exercises: [] });
    });
    // Заполняем кэш rowIndex → упражнение, чтобы редактор мог быстро взять данные
    currentProgramExercisesByRow = {};
    days.forEach(function(day) {
        (day.exercises || []).forEach(function(ex) {
            if (ex.rowIndex) currentProgramExercisesByRow[ex.rowIndex] = ex;
        });
    });
    if (days.length === 0) {
        container.innerHTML = '<div class="no-data">В программе пока нет упражнений</div>' +
            '<button class="cc-add-day-btn" onclick="showAddDayDialog()">+ Добавить день тренировки</button>';
        return;
    }

    // Также запоминаем "день" для каждого упражнения (для фильтра библиотеки по группе мышц)
    days.forEach(function(day) {
        (day.exercises || []).forEach(function(ex) {
            if (ex.rowIndex && currentProgramExercisesByRow[ex.rowIndex]) {
                currentProgramExercisesByRow[ex.rowIndex].__dayName = day.day || '';
            }
        });
    });

    container.innerHTML = days.map(function(day, dayIdx) {
        var groups = groupExercises(day.exercises || []);
        var groupsHtml = groups.map(function(group, gi) {
            var nextGroup = groups[gi + 1];
            var firstRowIdx = group.exercises[0].rowIndex;
            // Объединять/разъединять можно только соседние группы — суперсет/трисет и так
            // определяются исключительно соседством строк, ничего другого не нужно.
            var actionsHtml = '';
            if (group.type === 'single' && nextGroup && nextGroup.type === 'single' && firstRowIdx) {
                actionsHtml = '<button class="cc-group-action-btn" onclick="mergeExercises(' + firstRowIdx + ', false)">🔗 Объединить со следующим</button>';
            } else if (group.type === 'superset' && nextGroup && nextGroup.type === 'single' && firstRowIdx) {
                actionsHtml = '<button class="cc-group-action-btn" onclick="mergeExercises(' + firstRowIdx + ', true)">🔗+ Сделать трисет</button>';
            } else if ((group.type === 'superset' || group.type === 'triset' || blockTypeInfo(group.type)) && firstRowIdx) {
                actionsHtml = '<button class="cc-group-action-btn cc-group-action-split" onclick="splitGroup(' + firstRowIdx + ')">✂️ Разъединить</button>';
            }
            var numbered = blockTypeInfo(group.type);
            if (numbered) {
                var circuitRowIdxs = group.exercises.map(function(ex) { return ex.rowIndex; }).filter(function(r) { return r; }).join(',');
                var circuitBody = group.exercises.map(function(ex, idx) {
                    return (idx ? '<div class="cc-superset-divider"></div>' : '') +
                        renderExerciseRow(ex, String.fromCharCode(65 + idx));
                }).join('');
                return '<div class="cc-exercise cc-superset cc-block-' + group.type + '" data-row-indexes="' + circuitRowIdxs + '">' +
                    '<div class="cc-drag-handle">⋮⋮</div>' +
                    '<div class="cc-ex-num">' + group.number + '</div>' +
                    '<div class="cc-ex-info">' +
                        '<div class="cc-superset-header cc-block-header cc-block-header-' + group.type + '">' +
                            numbered.short + ' · ' + group.exercises.length + ' упр.' +
                            // M-4: в названии блока стоит одно число, а
                            // упражнений в нём другое — тренер об этом раньше
                            // не узнавал: блок просто забирал соседние
                            // упражнения себе. Теперь говорим прямо, здесь же.
                            (group.declaredSize && group.declaredSize !== group.exercises.length
                                ? ' <span class="cc-block-warn" title="В названии блока указано ' +
                                  group.declaredSize + ', а упражнений ' + group.exercises.length +
                                  '. Поправь число в названии первого упражнения.">⚠ указано ' +
                                  group.declaredSize + '</span>'
                                : '') +
                        '</div>' +
                        '<div class="cc-superset-body">' + circuitBody + '</div>' +
                        actionsHtml +
                    '</div>' +
                '</div>';
            }
            if (group.type === 'triset') {
                var rowIdxs = group.exercises.map(function(ex) { return ex.rowIndex; }).filter(function(r) { return r; }).join(',');
                return '<div class="cc-exercise cc-superset cc-triset" data-row-indexes="' + rowIdxs + '">' +
                    '<div class="cc-drag-handle">⋮⋮</div>' +
                    '<div class="cc-ex-num">' + group.number + '</div>' +
                    '<div class="cc-ex-info">' +
                        '<div class="cc-superset-header cc-triset-header">Трисет</div>' +
                        '<div class="cc-superset-body">' +
                            renderExerciseRow(group.exercises[0], 'A') +
                            '<div class="cc-superset-divider"></div>' +
                            renderExerciseRow(group.exercises[1], 'B') +
                            '<div class="cc-superset-divider"></div>' +
                            renderExerciseRow(group.exercises[2], 'C') +
                        '</div>' +
                        actionsHtml +
                    '</div>' +
                '</div>';
            }
            if (group.type === 'superset') {
                var rowIdxs2 = group.exercises.map(function(ex) { return ex.rowIndex; }).filter(function(r) { return r; }).join(',');
                return '<div class="cc-exercise cc-superset" data-row-indexes="' + rowIdxs2 + '">' +
                    '<div class="cc-drag-handle">⋮⋮</div>' +
                    '<div class="cc-ex-num">' + group.number + '</div>' +
                    '<div class="cc-ex-info">' +
                        '<div class="cc-superset-header">Суперсет</div>' +
                        '<div class="cc-superset-body">' +
                            renderExerciseRow(group.exercises[0], 'A') +
                            '<div class="cc-superset-divider"></div>' +
                            renderExerciseRow(group.exercises[1], 'B') +
                        '</div>' +
                        actionsHtml +
                    '</div>' +
                '</div>';
            }
            // single
            var singleRowIdx = group.exercises[0].rowIndex || '';
            return '<div class="cc-exercise" data-row-indexes="' + singleRowIdx + '">' +
                '<div class="cc-drag-handle">⋮⋮</div>' +
                '<div class="cc-ex-num">' + group.number + '</div>' +
                '<div class="cc-ex-info">' +
                    renderExerciseRow(group.exercises[0], '') +
                    actionsHtml +
                '</div>' +
            '</div>';
        }).join('');

        var safeDay = (day.day || '').replace(/'/g, "\\'").replace(/"/g, '&quot;');
        return '<div class="cc-day-block">' +
            '<div class="cc-day-title-row">' +
                '<div class="cc-day-title">' + _escHtml(day.day || 'Тренировка ' + (dayIdx + 1)) + '</div>' +
                '<button class="cc-day-menu-btn" onclick="showDayActionsDialog(\'' + safeDay + '\')" title="Действия с днём">⋯</button>' +
            '</div>' +
            '<div class="cc-day-exercises" data-day-name="' + safeDay + '">' +
                (groupsHtml || '<div class="no-data">Пока пусто — день сохранится, когда добавишь первое упражнение</div>') +
            '</div>' +
            '<button class="cc-add-ex-btn" onclick="showAddTypeDialog(\'' + safeDay + '\')">+ Добавить упражнение</button>' +
        '</div>';
    }).join('');

    // После списка дней — кнопка «+ Добавить день»
    container.innerHTML += '<button class="cc-add-day-btn" onclick="showAddDayDialog()">+ Добавить день тренировки</button>';

    // Инициализируем drag-and-drop для каждого дня (только внутри одного дня — перенос между днями отключён)
    initDayDragDrop();
}

// ========== ПЕРЕТАСКИВАНИЕ УПРАЖНЕНИЙ (Фаза 2E) ==========

var sortableInstances = [];

function initDayDragDrop() {
    if (typeof Sortable === 'undefined') {
        console.warn('SortableJS not loaded');
        return;
    }
    // Удалим старые инстансы перед перерендером
    sortableInstances.forEach(function(s) { try { s.destroy(); } catch (_) {} });
    sortableInstances = [];

    document.querySelectorAll('.cc-day-exercises').forEach(function(container, dayIdx) {
        var s = Sortable.create(container, {
            group: 'day-' + dayIdx, // разные группы — нельзя перетаскивать между днями
            animation: 180,
            handle: '.cc-drag-handle',
            chosenClass: 'cc-sortable-chosen',
            ghostClass: 'cc-sortable-ghost',
            dragClass: 'cc-sortable-drag',
            forceFallback: true, // надёжнее на iOS
            fallbackTolerance: 5,
            // forceFallback перехватывает касания по всему элементу, и тап по
            // кнопке внутри карточки уходил в несостоявшееся перетаскивание:
            // карандаш «просто не нажимался» (жалоба Анны). Кнопки и поля
            // исключаем из захвата, preventOnFilter: false — чтобы нажатие
            // дошло до самой кнопки, а не было погашено.
            filter: 'button, a, input, textarea, select',
            preventOnFilter: false,
            onEnd: function(evt) {
                if (evt.oldIndex === evt.newIndex) return; // ничего не изменилось
                handleDayReorder(container);
            }
        });
        sortableInstances.push(s);
    });
}

async function handleDayReorder(container) {
    if (!currentClientCard) return;

    // Собираем новый порядок rowIndex'ов (для суперсетов — оба row подряд)
    var rowIndexes = [];
    container.querySelectorAll('[data-row-indexes]').forEach(function(el) {
        var ids = (el.dataset.rowIndexes || '').split(',').map(function(s) { return parseInt(s.trim(), 10); }).filter(function(n) { return !isNaN(n); });
        ids.forEach(function(n) { rowIndexes.push(n); });
    });

    if (rowIndexes.length === 0) return;

    if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred('medium');

    try {
        var url = APPS_SCRIPT_URL + '?action=reorderDayExercises' +
            '&sheetName=' + encodeURIComponent(currentClientCard.sheetName) +
            '&order=' + encodeURIComponent(rowIndexes.join(','));
        var resp = await fetch(url);
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Не удалось переставить: ' + (data.error || ''));
            // Восстановим из бэка чтобы UI не врал
            await loadClientProgram(currentClientCard.sheetName);
            return;
        }
        // Перезагрузим — пересчитаются номера и rowIndex'ы
        await loadClientProgram(currentClientCard.sheetName);
    } catch (error) {
        console.error('Reorder error:', error);
        tg.showAlert('Ошибка соединения ❌');
        await loadClientProgram(currentClientCard.sheetName);
    }
}

// ========== ВКЛАДКА «ИСТОРИЯ» (Фаза 3) ==========

// Кэш истории по имени клиента (на случай переключения вкладок туда-сюда)
var clientHistoryCache = {};
var clientHistoryLoadedFor = '';

async function loadClientHistory(clientName) {
    if (!clientName) return;
    var container = document.getElementById('cc-history-container');
    if (!container) return;

    // Если уже грузили для этого клиента — просто перерендерим из кэша
    if (clientHistoryLoadedFor === clientName && clientHistoryCache[clientName]) {
        renderClientHistory(clientHistoryCache[clientName]);
        return;
    }

    container.innerHTML = '<div class="no-data">Загрузка истории...</div>';
    try {
        var url = APPS_SCRIPT_URL + '?action=getClientHistory' +
            '&clientName=' + encodeURIComponent(clientName) +
            '&limit=60';
        var resp = await fetch(url);
        var data = await resp.json();
        if (data.error) {
            container.innerHTML = '<div class="no-data">Ошибка: ' + data.error + '</div>';
            return;
        }
        clientHistoryCache[clientName] = data.history || [];
        clientHistoryLoadedFor = clientName;
        renderClientHistory(data.history || []);
    } catch (error) {
        console.error('Load history error:', error);
        container.innerHTML = '<div class="no-data">Ошибка загрузки истории</div>';
    }
}

// Названия дней недели для даты
var WEEKDAYS_RU = ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'];
var MONTHS_RU = ['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];

function formatHistoryDate(displayDateStr, dateObj) {
    // displayDateStr — «dd.MM.yyyy»; добавим день недели и месяц словом
    try {
        var d = new Date(dateObj);
        var dayNum = d.getDate();
        var month = MONTHS_RU[d.getMonth()];
        var weekday = WEEKDAYS_RU[d.getDay()];
        return dayNum + ' ' + month + ', ' + weekday;
    } catch (_) { return displayDateStr; }
}

// «Дней назад»
function daysAgoLabel(dateObj) {
    var now = new Date();
    var today0 = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    var d = new Date(dateObj);
    var d0 = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
    var days = Math.round((today0 - d0) / (24 * 60 * 60 * 1000));
    if (days === 0) return 'сегодня';
    if (days === 1) return 'вчера';
    if (days < 7) return days + ' дн назад';
    var weeks = Math.floor(days / 7);
    if (weeks < 5) return weeks + ' нед назад';
    var months = Math.floor(days / 30);
    return months + ' мес назад';
}

// Иконка оценки по её коду — тот же набор, что на экране тренировки.
var HH_FB_ICONS = { easy: 'smile', normal: 'dumbbell', hard: 'flame', failed: 'x' };

function renderClientHistory(history, containerId) {
    var container = document.getElementById(containerId || 'cc-history-container');
    if (!container) return;
    // Эта функция рисует историю в ДВУХ местах: на клиентской вкладке и в
    // карточке клиента у тренера. Отличаем их по контейнеру: у клиента
    // интерфейс переведён на дизайн-систему и эмодзи в нём не используются,
    // у тренера всё остаётся как было. Данные и разметка в остальном общие.
    var isClient = (containerId === 'client-history-container');
    var ico = function(name) { return isClient ? _homeIcon(name) : ''; };

    if (!history || history.length === 0) {
        container.innerHTML = '<div class="no-data">' +
            (isClient ? 'Пока нет завершённых тренировок' : '📅 У клиента пока нет завершённых тренировок') +
            '</div>';
        return;
    }

    container.innerHTML = history.map(function(day, idx) {
        var dateLabel = formatHistoryDate(day.date, day.dateObj);
        var agoLabel = daysAgoLabel(day.dateObj);
        var isOpen = idx === 0; // самая свежая открыта по умолчанию

        // Группа по неделям/дням внутри одной даты — берём первую неделю и название дня (если есть)
        var weekInfo = '';
        if (day.exercises && day.exercises.length) {
            var firstEx = day.exercises[0];
            var parts = [];
            if (firstEx.week) parts.push(firstEx.week);
            if (firstEx.day) parts.push(firstEx.day);
            if (parts.length) weekInfo = '<div class="hh-week">' + parts.join(' · ') + '</div>';
        }

        // Рендер упражнений
        var exHtml = (day.exercises || []).map(function(ex) {
            // Защита: ISO-дата иногда попадает в reps/weightPlan
            var repsClean = ex.reps;
            if (typeof repsClean === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(repsClean)) repsClean = '';
            var weightPlanClean = ex.weightPlan;
            if (typeof weightPlanClean === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(weightPlanClean)) weightPlanClean = '';

            var fact = '';
            if (ex.weightFact !== '' && ex.weightFact != null) {
                fact = ex.weightFact + ' кг';
                if (ex.repsFact !== '' && ex.repsFact != null) fact += ' × ' + ex.repsFact;
            }

            // Бейдж с фидбэком (Легко/Норм/Тяжело/Не вытянул) — приходит с бэка
            var feedbackHtml = '';
            if (ex.feedback && ex.feedback.label) {
                feedbackHtml = '<span class="hh-ex-feedback hh-fb-' + ex.feedback.code + '">' +
                    (isClient
                        ? ico(HH_FB_ICONS[ex.feedback.code] || 'smile')
                        : ex.feedback.emoji + ' ') +
                    '<span>' + ex.feedback.label + '</span>' +
                '</span>';
            }

            var rpeText = (ex.rpe !== '' && ex.rpe != null) ? ' · RPE ' + ex.rpe : '';

            var commentHtml = (ex.comment && ex.comment.toString().trim())
                ? '<div class="hh-ex-comment">' +
                      (isClient ? ico('comment') : '💬 ') +
                      '<span>' + _escHtml(ex.comment) + '</span>' +
                  '</div>'
                : '';

            var planText = '';
            if (weightPlanClean) {
                var repsPart = repsClean ? ' × ' + repsClean : '';
                planText = '<span class="hh-ex-plan">план: ' + weightPlanClean + repsPart + '</span>';
            }
            return '<div class="hh-ex">' +
                '<div class="hh-ex-name">' + _escHtml(cleanExerciseName(ex.exercise)) + '</div>' +
                '<div class="hh-ex-fact-row">' +
                    (fact ? '<span class="hh-ex-fact-value">' + fact + '</span>' : '<span class="hh-ex-skipped">не выполнено</span>') +
                    '<span class="hh-ex-rpe">' + rpeText + '</span>' +
                    feedbackHtml +
                '</div>' +
                planText +
                commentHtml +
            '</div>';
        }).join('');

        return '<details class="hh-day"' + (isOpen ? ' open' : '') + '>' +
            '<summary class="hh-day-summary">' +
                '<div class="hh-day-head">' +
                    '<div class="hh-date">' + (isClient ? '' : '📅 ') + dateLabel + '</div>' +
                    '<div class="hh-ago">' + agoLabel + '</div>' +
                '</div>' +
                weekInfo +
                '<div class="hh-count">' + day.exercises.length + ' упр.</div>' +
            '</summary>' +
            '<div class="hh-day-body">' + exHtml + '</div>' +
        '</details>';
    }).join('');
}

// При смене клиента — сбрасываем кэш истории
function resetClientHistoryCache() {
    clientHistoryLoadedFor = '';
}

// ========== ВКЛАДКА «СТАТИСТИКА» (Фаза 5) ==========

var statsLoadedFor = '';
var statsWeightChart = null;
var statsMeasChart = null;
var statsMeasSelectedKey = 'weight';
var statsMeasSelectInitialized = false;
var statsMeasurements = []; // [{dateLabel, dateObj, weight, shoulders, chest, waist, hips, bicep, thigh}]
var statsPhotoCompareMode = false;
var statsPhotoCompareSelected = []; // индексы в statsProgressPhotos, максимум 3

function toggleStatsPhotoCompare() {
    statsPhotoCompareMode = !statsPhotoCompareMode;
    statsPhotoCompareSelected = [];
    document.getElementById('stats-compare-toggle').textContent = statsPhotoCompareMode ? '✕ Отмена' : '🔍 Сравнить';
    document.getElementById('stats-compare-hint').classList.toggle('hidden', !statsPhotoCompareMode);
    renderStatsPhotoCompareStrip();
    renderClientStats();
}

function toggleStatsPhotoSelect(i) {
    var idx = statsPhotoCompareSelected.indexOf(i);
    if (idx !== -1) {
        statsPhotoCompareSelected.splice(idx, 1);
    } else {
        if (statsPhotoCompareSelected.length >= 3) statsPhotoCompareSelected.shift(); // максимум 3 — старейшее вылетает
        statsPhotoCompareSelected.push(i);
    }
    renderStatsPhotoCompareStrip();
    renderClientStats();
}

// Полоса сравнения — выбранные фото рядом в хронологическом порядке, с датой,
// весом (если есть за эту дату) и промежутком между соседними датами — тот
// же стиль, что коллега Matvey показывал ("каждые 6 недель согласно датам").
function renderStatsPhotoCompareStrip() {
    var strip = document.getElementById('stats-compare-strip');
    if (!strip) return;
    if (!statsPhotoCompareMode || statsPhotoCompareSelected.length < 2) {
        strip.innerHTML = '';
        strip.classList.remove('active');
        return;
    }
    strip.classList.add('active');
    var items = statsPhotoCompareSelected
        .map(function(i) { return statsProgressPhotos[i]; })
        .filter(Boolean)
        .sort(function(a, b) { return a.dateObj - b.dateObj; });

    strip.innerHTML = items.map(function(p, i) {
        var gapHtml = '';
        if (i > 0 && p.dateObj && items[i - 1].dateObj) {
            var days = Math.round((p.dateObj - items[i - 1].dateObj) / 86400000);
            gapHtml = '<div class="stats-compare-gap">→ ' + days + ' дн.</div>';
        }
        return (gapHtml ? gapHtml : '') +
            '<div class="stats-compare-item">' +
                '<img src="' + _escHtmlAttr(p.url) + '">' +
                '<div class="stats-compare-date">' + p.date + '</div>' +
                (p.weight ? '<div class="stats-compare-weight">' + p.weight + ' кг</div>' : '') +
            '</div>';
    }).join('');
}
var statsVolumeChart = null;
var statsBodyWeights = []; // [{date, weight}]
var statsProgressPhotos = []; // [{date, url}]

async function loadClientStats(clientName, chatId) {
    if (!clientName) return;
    if (statsLoadedFor === clientName) return; // уже посчитано

    // Сначала убеждаемся что есть история (для PR/объёма/consistency)
    if (clientHistoryLoadedFor !== clientName) {
        await loadClientHistory(clientName);
    }
    // Также подгружаем замеры (для графика веса тела и фото прогресса)
    statsBodyWeights = [];
    statsProgressPhotos = [];
    statsMeasurements = [];
    statsPhotoCompareMode = false;
    statsPhotoCompareSelected = [];
    if (chatId) {
        try {
            var url = APPS_SCRIPT_URL + '?action=getMeasurements&chatId=' + encodeURIComponent(chatId);
            var resp = await fetch(url);
            var data = await resp.json();
            if (data && data.measurements) {
                statsBodyWeights = (data.measurements || [])
                    .filter(function(m) { return m && m.weight != null && parseFloat(m.weight) > 0; })
                    .map(function(m) {
                        // m.date может быть «dd.MM.yyyy» — конвертируем в Date
                        var d = _parseDateRu(m.date);
                        return { dateLabel: formatDate(m.date), dateObj: d ? d.getTime() : 0, weight: parseFloat(m.weight) };
                    })
                    .filter(function(x) { return x.dateObj > 0; })
                    .sort(function(a, b) { return a.dateObj - b.dateObj; });
                statsProgressPhotos = (data.measurements || [])
                    .filter(function(m) { return m && m.photoUrl; })
                    .map(function(m) {
                        var d = _parseDateRu(m.date);
                        return {
                            date: formatDate(m.date), dateObj: d ? d.getTime() : 0, url: m.photoUrl,
                            weight: m.weight != null ? parseFloat(m.weight) : null
                        };
                    })
                    .reverse(); // свежие сверху
                // Полный набор замеров (не только вес) — для селектора графика ниже.
                statsMeasurements = (data.measurements || [])
                    .map(function(m) {
                        var d = _parseDateRu(m.date);
                        return {
                            dateLabel: formatDate(m.date), dateObj: d ? d.getTime() : 0,
                            weight: m.weight != null ? parseFloat(m.weight) : null,
                            shoulders: m.shoulders != null ? parseFloat(m.shoulders) : null,
                            chest: m.chest != null ? parseFloat(m.chest) : null,
                            waist: m.waist != null ? parseFloat(m.waist) : null,
                            hips: m.hips != null ? parseFloat(m.hips) : null,
                            bicep: m.bicep != null ? parseFloat(m.bicep) : null,
                            thigh: m.thigh != null ? parseFloat(m.thigh) : null
                        };
                    })
                    .filter(function(x) { return x.dateObj > 0; })
                    .sort(function(a, b) { return a.dateObj - b.dateObj; });
            }
        } catch (_) {}
    }

    statsLoadedFor = clientName;
    renderClientStats();
}

function _parseDateRu(s) {
    if (!s) return null;
    var str = s.toString().trim();
    if (str.indexOf('.') !== -1) {
        var parts = str.split('.');
        if (parts.length >= 3) {
            return new Date(parseInt(parts[2], 10), parseInt(parts[1], 10) - 1, parseInt(parts[0], 10));
        }
    }
    var d = new Date(str);
    return isNaN(d.getTime()) ? null : d;
}

function _isoWeekKey(d) {
    // Возвращает 'yyyy-WW' (ISO week)
    var tmp = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    var dayNum = tmp.getUTCDay() || 7;
    tmp.setUTCDate(tmp.getUTCDate() + 4 - dayNum);
    var yearStart = new Date(Date.UTC(tmp.getUTCFullYear(), 0, 1));
    var weekNo = Math.ceil((((tmp - yearStart) / 86400000) + 1) / 7);
    return tmp.getUTCFullYear() + '-W' + (weekNo < 10 ? '0' + weekNo : weekNo);
}

function renderClientStats() {
    var history = (clientHistoryCache[currentClientCard.name] || []).slice();
    var now = Date.now();
    var msDay = 24 * 60 * 60 * 1000;

    // ── 1. Регулярность за 4 недели ──
    var period = 28 * msDay;
    var datesIn4Weeks = {};
    history.forEach(function(day) {
        if (now - day.dateObj <= period) {
            // Используем YYYY-MM-DD как ключ
            var d = new Date(day.dateObj);
            var k = d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
            datesIn4Weeks[k] = true;
        }
    });
    var actual = Object.keys(datesIn4Weeks).length;

    // Ожидаемое: из анкеты freq × 4 (если есть), иначе средняя частота за всю историю
    var expected = 0;
    var freqField = document.getElementById('prof-frequency');
    var freqVal = freqField ? parseInt(freqField.value, 10) : 0;
    if (freqVal > 0) {
        expected = freqVal * 4;
    } else if (history.length > 0) {
        // средняя за всю историю: уник дат / (диапазон в днях / 28)
        var firstDate = history[history.length - 1].dateObj;
        var spanDays = Math.max(1, (now - firstDate) / msDay);
        // считаем уникальные даты во всей истории
        var allDates = {};
        history.forEach(function(day) {
            var d = new Date(day.dateObj);
            var k = d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
            allDates[k] = true;
        });
        var avgPer28 = Object.keys(allDates).length / spanDays * 28;
        expected = Math.max(8, Math.round(avgPer28)); // минимум 8 (≈ 2 раза в неделю)
    } else {
        expected = 12; // дефолт
    }

    var percent = expected > 0 ? Math.round(actual / expected * 100) : 0;
    if (percent > 100) percent = 100;

    document.getElementById('stats-consistency-percent').textContent = percent + '%';
    var subTxt = actual + ' тренировок из ~' + expected + ' ожидаемых';
    if (freqVal > 0) subTxt += ' (по анкете ' + freqVal + ' в неделю)';
    document.getElementById('stats-consistency-sub').textContent = subTxt;
    var fill = document.getElementById('stats-consistency-fill');
    fill.style.width = Math.max(2, percent) + '%';
    fill.className = 'stats-consistency-fill';
    if (percent >= 85)      fill.classList.add('cc-fill-good');
    else if (percent >= 60) fill.classList.add('cc-fill-mid');
    else                    fill.classList.add('cc-fill-low');

    // ── 2. Топ-3 рекорда ──
    var bestByExercise = {};
    history.forEach(function(day) {
        day.exercises.forEach(function(ex) {
            var name = cleanExerciseName(ex.exercise);
            if (!name) return;
            var w = parseFloat(ex.weightFact);
            var r = parseFloat(ex.repsFact);
            if (isNaN(w) || w <= 0) return;
            var cur = bestByExercise[name];
            if (!cur || w > cur.weight || (w === cur.weight && (r || 0) > (cur.reps || 0))) {
                bestByExercise[name] = { weight: w, reps: r || 0, date: day.date };
            }
        });
    });
    var prs = Object.keys(bestByExercise).map(function(name) {
        var b = bestByExercise[name];
        return { name: name, weight: b.weight, reps: b.reps, date: b.date };
    });
    prs.sort(function(a, b) { return b.weight - a.weight; });
    prs = prs.slice(0, 3);

    var prsEl = document.getElementById('stats-prs-list');
    if (prs.length === 0) {
        prsEl.innerHTML = '<div class="no-data">Нет данных</div>';
    } else {
        prsEl.innerHTML = prs.map(function(pr, idx) {
            var medal = ['🥇', '🥈', '🥉'][idx] || '🏅';
            var repsTxt = pr.reps ? ' × ' + pr.reps : '';
            return '<div class="stats-pr-row">' +
                '<div class="stats-pr-medal">' + medal + '</div>' +
                '<div class="stats-pr-info">' +
                    '<div class="stats-pr-name">' + _escHtml(pr.name) + '</div>' +
                    '<div class="stats-pr-date">' + pr.date + '</div>' +
                '</div>' +
                '<div class="stats-pr-weight">' + pr.weight + ' кг' + repsTxt + '</div>' +
            '</div>';
        }).join('');
    }

    // ── 3. График веса тела ──
    var wEmpty = document.getElementById('stats-weight-empty');
    var wCanvas = document.getElementById('stats-weight-chart');
    if (statsWeightChart) { try { statsWeightChart.destroy(); } catch (_) {} statsWeightChart = null; }
    if (statsBodyWeights.length < 2) {
        wEmpty.classList.remove('hidden');
        wCanvas.style.display = 'none';
        if (statsBodyWeights.length === 1) {
            wEmpty.textContent = 'Только один замер: ' + statsBodyWeights[0].weight + ' кг (' + statsBodyWeights[0].dateLabel + ')';
        } else {
            wEmpty.textContent = 'Клиент ещё не вносил замеры веса';
        }
    } else {
        wEmpty.classList.add('hidden');
        wCanvas.style.display = '';
        statsWeightChart = new Chart(wCanvas.getContext('2d'), {
            type: 'line',
            data: {
                labels: statsBodyWeights.map(function(x) { return x.dateLabel; }),
                datasets: [{
                    label: 'Вес',
                    data: statsBodyWeights.map(function(x) { return x.weight; }),
                    borderColor: '#1565C0',
                    backgroundColor: 'rgba(21,101,192,0.10)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.3,
                    pointRadius: 4,
                    pointBackgroundColor: '#1565C0',
                    pointBorderColor: '#fff'
                }]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    y: { ticks: { callback: function(v) { return v + ' кг'; } } },
                    x: { grid: { display: false } }
                }
            }
        });
    }

    // ── 3a2. Полные замеры (селектор + график, не только вес) ──
    renderStatsMeasurements();

    // ── 3b. Фото прогресса ──
    var pGrid = document.getElementById('stats-photos-grid');
    var pEmpty = document.getElementById('stats-photos-empty');
    var compareToggle = document.getElementById('stats-compare-toggle');
    if (compareToggle) compareToggle.classList.toggle('hidden', statsProgressPhotos.length < 2);
    renderStatsPhotoCompareStrip();
    if (statsProgressPhotos.length === 0) {
        pGrid.innerHTML = '';
        pEmpty.classList.remove('hidden');
    } else {
        pEmpty.classList.add('hidden');
        pGrid.innerHTML = statsProgressPhotos.map(function(p, i) {
            var selected = statsPhotoCompareMode && statsPhotoCompareSelected.indexOf(i) !== -1;
            var clickHandler = statsPhotoCompareMode
                ? 'toggleStatsPhotoSelect(' + i + ')'
                : 'tg.openLink(\'' + p.url + '\')';
            return '<div class="stats-photo-item' + (selected ? ' selected' : '') + '" onclick="' + clickHandler + '">' +
                '<img src="' + _escHtmlAttr(p.url) + '">' +
                (selected ? '<div class="stats-photo-check">✓</div>' : '') +
                '<div class="stats-photo-date">' + p.date + (p.weight ? ' · ' + p.weight + 'кг' : '') + '</div>' +
            '</div>';
        }).join('');
    }

    // ── 4. Объём по неделям ──
    var volumeByWeek = {};   // 'YYYY-WW' → { volume, weekStart }
    history.forEach(function(day) {
        var d = new Date(day.dateObj);
        var key = _isoWeekKey(d);
        if (!volumeByWeek[key]) volumeByWeek[key] = { volume: 0, weekStart: d.getTime() };
        else if (d.getTime() < volumeByWeek[key].weekStart) volumeByWeek[key].weekStart = d.getTime();
        day.exercises.forEach(function(ex) {
            var w = parseFloat(ex.weightFact) || 0;
            var r = parseFloat(ex.repsFact) || 0;
            var s = parseFloat(ex.sets) || 1;
            if (w > 0 && r > 0) volumeByWeek[key].volume += w * r * s;
        });
    });
    var volList = Object.keys(volumeByWeek).map(function(k) {
        return { week: k, volume: Math.round(volumeByWeek[k].volume), start: volumeByWeek[k].weekStart };
    });
    volList.sort(function(a, b) { return a.start - b.start; });
    volList = volList.slice(-12);

    var vEmpty = document.getElementById('stats-volume-empty');
    var vCanvas = document.getElementById('stats-volume-chart');
    if (statsVolumeChart) { try { statsVolumeChart.destroy(); } catch (_) {} statsVolumeChart = null; }
    if (volList.length === 0) {
        vEmpty.classList.remove('hidden');
        vCanvas.style.display = 'none';
    } else {
        vEmpty.classList.add('hidden');
        vCanvas.style.display = '';
        statsVolumeChart = new Chart(vCanvas.getContext('2d'), {
            type: 'bar',
            data: {
                labels: volList.map(function(v) {
                    var d = new Date(v.start);
                    return d.getDate() + '.' + (d.getMonth() + 1);
                }),
                datasets: [{
                    label: 'Тоннаж',
                    data: volList.map(function(v) { return v.volume; }),
                    backgroundColor: 'rgba(67,160,71,0.65)',
                    borderColor: '#43A047',
                    borderWidth: 1.5,
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function(ctx2) { return ctx2.parsed.y.toLocaleString('ru-RU') + ' кг'; }
                        }
                    }
                },
                scales: {
                    y: { beginAtZero: true, ticks: { callback: function(v) { return (v / 1000).toFixed(1) + 'т'; } } },
                    x: { grid: { display: false } }
                }
            }
        });
    }

    // ── 5. Прогресс по упражнениям (последние 30 vs предыдущие 30) ──
    var thirty = 30 * msDay;
    var sixty  = 60 * msDay;
    var bestRecent = {}, bestPrev = {};
    history.forEach(function(day) {
        var age = now - day.dateObj;
        day.exercises.forEach(function(ex) {
            var name = cleanExerciseName(ex.exercise);
            if (!name) return;
            var w = parseFloat(ex.weightFact);
            if (isNaN(w) || w <= 0) return;
            if (age <= thirty) {
                if (!bestRecent[name] || w > bestRecent[name]) bestRecent[name] = w;
            } else if (age <= sixty) {
                if (!bestPrev[name] || w > bestPrev[name]) bestPrev[name] = w;
            }
        });
    });
    var progress = Object.keys(bestRecent).filter(function(name) {
        return bestPrev[name] != null;
    }).map(function(name) {
        return { name: name, recent: bestRecent[name], prev: bestPrev[name], gain: bestRecent[name] - bestPrev[name] };
    });
    progress.sort(function(a, b) { return b.gain - a.gain; });
    progress = progress.slice(0, 5);

    var progEl = document.getElementById('stats-progress-list');
    if (progress.length === 0) {
        progEl.innerHTML = '<div class="no-data">Недостаточно данных за два периода по 30 дней</div>';
    } else {
        progEl.innerHTML = progress.map(function(p) {
            var sign = p.gain > 0 ? '+' : '';
            var cls = p.gain > 0 ? 'stats-progress-up' : (p.gain < 0 ? 'stats-progress-down' : 'stats-progress-flat');
            var arrow = p.gain > 0 ? '▲' : (p.gain < 0 ? '▼' : '◆');
            return '<div class="stats-progress-row">' +
                '<div class="stats-progress-name">' + _escHtml(p.name) + '</div>' +
                '<div class="stats-progress-values">' +
                    '<span class="stats-progress-prev">' + p.prev + ' кг</span> → ' +
                    '<strong>' + p.recent + ' кг</strong>' +
                '</div>' +
                '<div class="stats-progress-gain ' + cls + '">' + arrow + ' ' + sign + p.gain.toFixed(1) + ' кг</div>' +
            '</div>';
        }).join('');
    }
}

// ========== ВКЛАДКА «ЗАМЕТКИ» (Фаза 4) ==========

var notesLoadedFor = '';
var profileLoadedFor = '';

async function loadClientNotes(clientName) {
    if (!clientName) return;
    var list = document.getElementById('notes-list');
    if (!list) return;
    if (notesLoadedFor === clientName) return; // уже загружено
    list.innerHTML = '<div class="no-data">Загрузка заметок...</div>';
    try {
        var url = APPS_SCRIPT_URL + '?action=getClientNotes&clientName=' + encodeURIComponent(clientName);
        var resp = await fetch(url);
        var data = await resp.json();
        if (data.error) {
            list.innerHTML = '<div class="no-data">Ошибка: ' + data.error + '</div>';
            return;
        }
        notesLoadedFor = clientName;
        renderNotesList(data.notes || []);
    } catch (e) {
        list.innerHTML = '<div class="no-data">Ошибка загрузки</div>';
    }
}

function renderNotesList(notes) {
    var list = document.getElementById('notes-list');
    if (!list) return;
    if (!notes || notes.length === 0) {
        list.innerHTML = '<div class="no-data">Пока нет заметок</div>';
        return;
    }
    list.innerHTML = notes.map(function(n) {
        var flag = n.important ? '<span class="notes-flag">⚠️</span>' : '';
        var safeName = (currentClientCard ? currentClientCard.name : '').replace(/'/g, "\\'");
        var text = _escHtml(n.text || '').replace(/\n/g, '<br>');
        return '<div class="notes-item' + (n.important ? ' notes-item-important' : '') + '">' +
            '<div class="notes-item-head">' +
                '<span class="notes-item-date">📅 ' + n.date + '</span>' +
                flag +
                '<button class="notes-item-del" onclick="deleteClientNoteFlow(' + n.ts + ')" title="Удалить">🗑</button>' +
            '</div>' +
            '<div class="notes-item-text">' + text + '</div>' +
        '</div>';
    }).join('');
}

async function saveNewNote() {
    if (!currentClientCard) return;
    var textEl = document.getElementById('notes-new-text');
    var impEl = document.getElementById('notes-new-important');
    var text = (textEl.value || '').trim();
    if (!text) {
        tg.showAlert('Напиши текст заметки');
        return;
    }
    try {
        var url = APPS_SCRIPT_URL + '?action=addClientNote' +
            '&clientName=' + encodeURIComponent(currentClientCard.name) +
            '&text=' + encodeURIComponent(text) +
            '&important=' + (impEl.checked ? 'true' : 'false');
        var resp = await fetch(url);
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось'));
            return;
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        textEl.value = '';
        impEl.checked = false;
        notesLoadedFor = ''; // сброс кэша, перезагрузим
        await loadClientNotes(currentClientCard.name);
    } catch (e) {
        console.error('Save note error:', e);
        tg.showAlert('Ошибка соединения ❌');
    }
}

async function deleteClientNoteFlow(ts) {
    if (!currentClientCard || !ts) return;
    var confirmed = await tgConfirm('Удалить заметку?');
    if (!confirmed) return;
    try {
        var url = APPS_SCRIPT_URL + '?action=deleteClientNote' +
            '&clientName=' + encodeURIComponent(currentClientCard.name) +
            '&ts=' + ts;
        var resp = await fetch(url);
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось'));
            return;
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        notesLoadedFor = '';
        await loadClientNotes(currentClientCard.name);
    } catch (e) {
        tg.showAlert('Ошибка соединения ❌');
    }
}

// ── Анкета клиента ──

async function loadClientProfile(chatId) {
    if (!chatId) return;
    var chatIdField = document.getElementById('prof-chatid');
    if (chatIdField) chatIdField.value = chatId;
    if (profileLoadedFor === chatId) return;
    try {
        var url = APPS_SCRIPT_URL + '?action=getClientProfile&targetChatId=' + encodeURIComponent(chatId);
        var resp = await fetch(url);
        var data = await resp.json();
        if (data.error) return;
        profileLoadedFor = chatId;
        fillProfileForm(data);
    } catch (e) { console.error('Load profile error:', e); }
}

function fillProfileForm(p) {
    // Пол
    document.querySelectorAll('input[name="prof-gender"]').forEach(function(el) {
        el.checked = (el.value === p.gender);
    });
    document.getElementById('prof-age').value = p.age || '';
    document.getElementById('prof-height').value = p.height || '';
    document.getElementById('prof-weight').value = p.weight || '';
    document.getElementById('prof-goal').value = p.goal || '';
    document.getElementById('prof-level').value = p.level || '';
    document.getElementById('prof-frequency').value = p.frequency || '';
    document.getElementById('prof-inventory').value = p.inventory || '';

    // Ограничения: CSV в hidden, чекбоксы для стандартных + free-text «Другое»
    var lim = (p.limitations || '').toString();
    var known = ['knee', 'back', 'shoulder', 'wrist'];
    var arr = lim.split(',').map(function(s) { return s.trim(); }).filter(Boolean);
    var other = [];
    document.querySelectorAll('.prof-limit-cb').forEach(function(cb) {
        cb.checked = arr.indexOf(cb.value) >= 0;
    });
    arr.forEach(function(v) { if (known.indexOf(v) < 0) other.push(v); });
    document.getElementById('prof-limit-other').value = other.join(', ');
}

function collectProfileForm() {
    var gender = '';
    var g = document.querySelector('input[name="prof-gender"]:checked');
    if (g) gender = g.value;

    var limits = [];
    document.querySelectorAll('.prof-limit-cb').forEach(function(cb) {
        if (cb.checked) limits.push(cb.value);
    });
    var other = (document.getElementById('prof-limit-other').value || '').trim();
    if (other) other.split(',').forEach(function(s) {
        var v = s.trim();
        if (v) limits.push(v);
    });

    return {
        gender: gender,
        age: document.getElementById('prof-age').value.trim(),
        height: document.getElementById('prof-height').value.trim(),
        weight: document.getElementById('prof-weight').value.trim(),
        goal: document.getElementById('prof-goal').value,
        level: document.getElementById('prof-level').value,
        frequency: document.getElementById('prof-frequency').value,
        limitations: limits.join(','),
        inventory: document.getElementById('prof-inventory').value
    };
}

async function saveClientProfile() {
    if (!currentClientCard) return;
    var fields = collectProfileForm();
    var qs = 'action=updateClientProfile&targetChatId=' + encodeURIComponent(currentClientCard.chatId);
    Object.keys(fields).forEach(function(k) {
        qs += '&' + k + '=' + encodeURIComponent(fields[k]);
    });
    try {
        var resp = await fetch(APPS_SCRIPT_URL + '?' + qs);
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось'));
            return;
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        tg.showAlert('✅ Анкета сохранена');
    } catch (e) {
        tg.showAlert('Ошибка соединения ❌');
    }
}

async function saveClientChatId() {
    if (!currentClientCard) return;
    var input = document.getElementById('prof-chatid');
    var newChatId = (input.value || '').trim();
    if (!newChatId || newChatId === currentClientCard.chatId) return;
    var ok = await tgConfirm(
        'Поменять ID клиента с ' + currentClientCard.chatId + ' на ' + newChatId + '? ' +
        'Если ошибёшься — клиент потеряет доступ к боту/мини-аппу.'
    );
    if (!ok) { input.value = currentClientCard.chatId; return; }
    try {
        var url = APPS_SCRIPT_URL + '?action=renameClientChatId&oldChatId=' +
            encodeURIComponent(currentClientCard.chatId) + '&newChatId=' + encodeURIComponent(newChatId);
        var resp = await fetch(url);
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось'));
            return;
        }
        currentClientCard.chatId = newChatId;
        profileLoadedFor = null; // чтобы следующий заход в анкету перечитал данные по новому id
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        tg.showAlert('✅ ID обновлён');
        loadAdminClients();
    } catch (e) {
        tg.showAlert('Ошибка соединения ❌');
    }
}

// ========== ИСТОРИЯ ПО КОНКРЕТНОМУ УПРАЖНЕНИЮ ==========

var exStatChart = null;
var exStatSelectedName = '';

// Собирает уникальный список упражнений из текущей истории клиента (по очищенным именам)
function _getUniqueExercisesFromHistory(history) {
    var seen = {};
    var list = [];
    (history || []).forEach(function(day) {
        (day.exercises || []).forEach(function(ex) {
            var name = cleanExerciseName(ex.exercise);
            if (!name) return;
            if (seen[name]) return;
            seen[name] = true;
            list.push(name);
        });
    });
    list.sort(function(a, b) { return a.localeCompare(b, 'ru'); });
    return list;
}

// Собирает массив попыток (только с фактом) для конкретного упражнения, отсортированных по дате (по возрастанию для графика)
function _collectExerciseAttempts(history, exerciseName) {
    var target = cleanExerciseName(exerciseName);
    var attempts = [];
    (history || []).forEach(function(day) {
        (day.exercises || []).forEach(function(ex) {
            if (cleanExerciseName(ex.exercise) !== target) return;
            var wFact = parseFloat(ex.weightFact);
            var rFact = parseFloat(ex.repsFact);
            // Без факта неинтересно (план не делал)
            if (isNaN(wFact) && isNaN(rFact)) return;
            attempts.push({
                date: day.date,
                dateObj: day.dateObj,
                weightFact: isNaN(wFact) ? null : wFact,
                repsFact: isNaN(rFact) ? null : rFact,
                rpe: ex.rpe || '',
                feedback: ex.feedback || null,
                comment: ex.comment || '',
                weightPlan: ex.weightPlan || '',
                reps: ex.reps || ''
            });
        });
    });
    attempts.sort(function(a, b) { return a.dateObj - b.dateObj; });
    return attempts;
}

function openExerciseStats() {
    if (!currentClientCard) return;
    var history = clientHistoryCache[currentClientCard.name] || [];
    if (history.length === 0) {
        tg.showAlert('Сначала открой вкладку «История» — нужно загрузить данные');
        return;
    }

    document.getElementById('ex-stat-client-name').textContent = currentClientCard.name;
    document.body.classList.add('no-scroll');
    document.getElementById('ex-stat-modal').classList.remove('hidden');

    var list = _getUniqueExercisesFromHistory(history);
    var sel = document.getElementById('ex-stat-select');
    sel.innerHTML = list.map(function(name) {
        return '<option value="' + name.replace(/"/g, '&quot;') + '">' + name + '</option>';
    }).join('');

    // Выбираем первое (или ранее выбранное, если осталось в списке)
    if (exStatSelectedName && list.indexOf(exStatSelectedName) >= 0) {
        sel.value = exStatSelectedName;
    } else if (list.length > 0) {
        sel.value = list[0];
        exStatSelectedName = list[0];
    }

    // Навешиваем обработчик один раз
    if (!sel.dataset.bound) {
        sel.addEventListener('change', function() {
            exStatSelectedName = sel.value;
            renderExerciseStats(currentClientCard.name, sel.value);
        });
        sel.dataset.bound = '1';
    }

    if (exStatSelectedName) renderExerciseStats(currentClientCard.name, exStatSelectedName);
}

function closeExerciseStats() {
    document.getElementById('ex-stat-modal').classList.add('hidden');
    document.body.classList.remove('no-scroll');
    if (exStatChart) {
        try { exStatChart.destroy(); } catch (_) {}
        exStatChart = null;
    }
}

function renderExerciseStats(clientName, exerciseName) {
    var history = clientHistoryCache[clientName] || [];
    var attempts = _collectExerciseAttempts(history, exerciseName);

    // ── Личный рекорд ──
    var prEl = document.getElementById('ex-stat-pr');
    if (attempts.length === 0) {
        prEl.innerHTML = '🏆 Личный рекорд: <span class="ex-stat-empty">нет данных</span>';
    } else {
        var pr = attempts.reduce(function(acc, a) {
            if (acc == null) return a;
            if ((a.weightFact || 0) > (acc.weightFact || 0)) return a;
            // При равном весе — больше повторов лучше
            if ((a.weightFact || 0) === (acc.weightFact || 0) && (a.repsFact || 0) > (acc.repsFact || 0)) return a;
            return acc;
        }, null);
        var repsTxt = pr.repsFact ? ' × ' + pr.repsFact : '';
        prEl.innerHTML = '🏆 Личный рекорд: <strong>' + (pr.weightFact != null ? pr.weightFact + ' кг' : '—') + repsTxt + '</strong> <span class="ex-stat-pr-date">(' + pr.date + ')</span>';
    }

    // ── График ──
    var canvas = document.getElementById('ex-stat-chart');
    if (exStatChart) {
        try { exStatChart.destroy(); } catch (_) {}
        exStatChart = null;
    }
    if (attempts.length === 0) {
        canvas.style.display = 'none';
    } else {
        canvas.style.display = '';
        var ctx = canvas.getContext('2d');
        var labels = attempts.map(function(a) {
            // Короткая дата dd.MM
            var p = (a.date || '').split('.');
            return p.length >= 2 ? p[0] + '.' + p[1] : a.date;
        });
        var weights = attempts.map(function(a) { return a.weightFact; });

        // Цвета точек по фидбэку
        var pointColors = attempts.map(function(a) {
            if (a.feedback && a.feedback.code) {
                if (a.feedback.code === 'easy')   return '#43A047';
                if (a.feedback.code === 'normal') return '#1565C0';
                if (a.feedback.code === 'hard')   return '#E65100';
                if (a.feedback.code === 'failed') return '#C62828';
            }
            return '#1a1a2e';
        });

        exStatChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Вес, кг',
                    data: weights,
                    borderColor: '#1a1a2e',
                    backgroundColor: 'rgba(26,26,46,0.08)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.3,
                    pointRadius: 6,
                    pointBackgroundColor: pointColors,
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointHoverRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#1a1a2e',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        padding: 10,
                        cornerRadius: 8,
                        displayColors: false,
                        callbacks: {
                            label: function(ctx2) {
                                var i = ctx2.dataIndex;
                                var a = attempts[i];
                                var parts = [];
                                if (a.weightFact != null) parts.push(a.weightFact + ' кг');
                                if (a.repsFact != null) parts.push(a.repsFact + ' повт');
                                if (a.rpe) parts.push('RPE ' + a.rpe);
                                if (a.feedback) parts.push(a.feedback.emoji + ' ' + a.feedback.label);
                                return parts.join(' · ');
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false,
                        ticks: { callback: function(v) { return v + ' кг'; } },
                        grid: { color: '#f0f0f0' }
                    },
                    x: { grid: { display: false } }
                }
            }
        });
    }

    // ── Таблица ──
    var table = document.getElementById('ex-stat-table');
    if (attempts.length === 0) {
        table.innerHTML = '<div class="no-data">Нет фактических попыток</div>';
        return;
    }
    // В таблице — по убыванию даты (свежие сверху)
    var rev = attempts.slice().reverse();
    table.innerHTML = rev.map(function(a) {
        var fb = a.feedback
            ? '<span class="hh-ex-feedback hh-fb-' + a.feedback.code + '">' + a.feedback.emoji + ' ' + a.feedback.label + '</span>'
            : '';
        var repsTxt = a.repsFact != null ? ' × ' + a.repsFact : '';
        var rpeTxt = a.rpe ? ' · RPE ' + a.rpe : '';
        return '<div class="ex-stat-row">' +
            '<div class="ex-stat-row-date">' + a.date + '</div>' +
            '<div class="ex-stat-row-value">' +
                '<strong>' + (a.weightFact != null ? a.weightFact + ' кг' : '—') + repsTxt + '</strong>' +
                '<span class="ex-stat-row-rpe">' + rpeTxt + '</span>' +
            '</div>' +
            fb +
        '</div>';
    }).join('');
}

// ========== РЕДАКТОР УПРАЖНЕНИЯ (Фаза 2B + 2C) ==========

var currentEditingRow = null;
var currentEditingMode = 'edit'; // 'edit' | 'add'
var currentAddDay = '';          // используется в режиме 'add'
var currentEditingPrefix = '';   // 'СЕТ: ' / 'ТРИСЕТ: ' / '' — чтобы не потерять при сохранении
var currentSetType = 'single';   // 'single' | 'superset' | 'triset' (только в режиме add)

// Очередь несохранённых правок упражнений: { rowIndex: paramsForApi }
// Когда тренер редактирует упражнения через модалку — изменения не уходят сразу в Google Sheets,
// а копятся здесь. Финальный коммит делает кнопка «💾 Сохранить изменения» внизу программы.
var pendingExerciseEdits = {};
var activeNameInputId = 'ex-edit-name'; // какое поле «Название» сейчас активно для библиотеки

function openExerciseEditor(rowIndex) {
    var ex = currentProgramExercisesByRow[rowIndex];
    if (!ex || !currentClientCard) return;
    currentEditingRow = rowIndex;
    currentEditingMode = 'edit';
    currentAddDay = '';
    currentSetType = 'single';

    // Запоминаем префикс «СЕТ:»/«ТРИСЕТ:» — чтобы при сохранении не разрушить связку
    var rawName = (ex.exercise || '').toString();
    var startedBlock = numberedBlockStart({ exercise: rawName });
    if (startedBlock) {
        currentEditingPrefix = blockTypeInfo(startedBlock.type).prefix + ' ' + startedBlock.size + ': ';
    }
    else if (/^\s*трисет\s*:/i.test(rawName)) currentEditingPrefix = 'ТРИСЕТ: ';
    else if (/^\s*сет\s*:/i.test(rawName)) currentEditingPrefix = 'СЕТ: ';
    else currentEditingPrefix = '';

    // Скрываем переключатель типа и блоки B/C при редактировании одного упражнения
    document.getElementById('ex-type-switch').classList.add('hidden');
    document.getElementById('ex-block-B').classList.add('hidden');
    document.getElementById('ex-block-C').classList.add('hidden');
    document.getElementById('ex-block-A-title').classList.add('hidden');

    document.getElementById('ex-editor-title').textContent = cleanExerciseName(ex.exercise) || 'Упражнение';
    document.getElementById('ex-edit-name').value = cleanExerciseName(ex.exercise) || '';
    document.getElementById('ex-edit-weight').value = ex.weightPlan != null ? ex.weightPlan : '';
    document.getElementById('ex-edit-reps').value = ex.reps != null ? ex.reps : '';
    document.getElementById('ex-edit-sets').value = ex.sets != null ? ex.sets : '';
    document.getElementById('ex-edit-rpe').value = ex.rpe != null ? ex.rpe : '';
    document.getElementById('ex-edit-note').value = ex.note != null ? ex.note : '';

    // Кнопка «Удалить» — только в режиме редактирования
    var delBtn = document.getElementById('ex-edit-delete-btn');
    if (delBtn) delBtn.classList.remove('hidden');
    var saveBtn = document.getElementById('ex-edit-save-btn');
    if (saveBtn) saveBtn.textContent = '✅ Применить';

    // Подсказка «Последний раз» — сначала покажем из текущей программы, потом обогатим данными из истории
    showLastResultHint({
        weightFact: ex.weightFact,
        repsFact: ex.repsFact,
        rpe: ex.rpe,
        date: '' // в текущей программе нет даты
    });
    // Параллельно запрашиваем самое свежее из истории (если упражнение не пустое)
    loadAndShowLastResult(cleanExerciseName(ex.exercise));

    document.getElementById('ex-editor-modal').classList.remove('hidden');

    // Готовим библиотеку и сбрасываем фильтр на "Этот день"
    libraryFilterMuscle = 'day';
    librarySearchText = '';
    closeExerciseLibrary();
    loadExerciseLibrary(); // фоном — потом откроется быстро по фокусу
}

// Показать подсказку «Последний раз» с переданными значениями
function showLastResultHint(data) {
    var hint = document.getElementById('ex-edit-history-hint');
    if (!hint) return;
    var w = data.weightFact, r = data.repsFact, rpe = data.rpe;
    var hasFact = (w !== '' && w != null && w !== 0) || (r !== '' && r != null && r !== 0);
    if (!hasFact) {
        hint.textContent = '';
        hint.classList.add('hidden');
        return;
    }
    var parts = [];
    if (w) parts.push(w + ' кг');
    if (r) parts.push('× ' + r);
    if (rpe) parts.push('RPE ' + rpe);
    if (data.feedback && data.feedback.label) {
        parts.push(data.feedback.emoji + ' ' + data.feedback.label);
    }
    var dateTxt = data.date ? ' (' + data.date + ')' : '';
    hint.classList.remove('hidden');
    hint.classList.remove('ex-hint-empty');
    hint.classList.remove('ex-hint-loading');
    hint.innerHTML = '💪 Последний раз: <strong>' + parts.join(' · ') + '</strong>' + dateTxt;
}

// Сообщение «Это упражнение клиент ещё не выполнял»
function showLastResultEmpty() {
    var hint = document.getElementById('ex-edit-history-hint');
    if (!hint) return;
    hint.classList.remove('hidden');
    hint.classList.remove('ex-hint-loading');
    hint.classList.add('ex-hint-empty');
    hint.textContent = 'ℹ️ Это упражнение клиент ещё не выполнял';
}

function showLastResultLoading() {
    var hint = document.getElementById('ex-edit-history-hint');
    if (!hint) return;
    hint.classList.remove('hidden');
    hint.classList.remove('ex-hint-empty');
    hint.classList.add('ex-hint-loading');
    hint.textContent = '⏳ Ищу последний результат…';
}

// Кэш: clientName||exerciseName → result | 'empty'
var lastResultCache = {};
var lastResultDebounceTimer = null;

// Главная функция: подгружает и показывает последний результат клиента по упражнению.
// Вызывается при открытии редактора, при выборе из библиотеки, при ручном вводе названия.
function loadAndShowLastResult(exerciseName) {
    if (!currentClientCard) return;
    var name = (exerciseName || '').toString().trim();
    var hint = document.getElementById('ex-edit-history-hint');
    if (!name) {
        hint.textContent = '';
        hint.classList.add('hidden');
        return;
    }
    var key = currentClientCard.name + '||' + name;
    if (lastResultCache[key] !== undefined) {
        var cached = lastResultCache[key];
        if (cached === 'empty') showLastResultEmpty();
        else showLastResultHint(cached);
        return;
    }

    showLastResultLoading();
    if (lastResultDebounceTimer) clearTimeout(lastResultDebounceTimer);
    lastResultDebounceTimer = setTimeout(function() {
        var url = APPS_SCRIPT_URL + '?action=getLastExerciseResult' +
            '&clientName=' + encodeURIComponent(currentClientCard.name) +
            '&exerciseName=' + encodeURIComponent(name);
        fetch(url).then(function(r) { return r.json(); }).then(function(data) {
            if (data && !data.empty && !data.error) {
                lastResultCache[key] = {
                    weightFact: data.weightFact,
                    repsFact: data.repsFact,
                    rpe: data.rpe,
                    feedback: data.feedback,
                    date: data.date
                };
                showLastResultHint(lastResultCache[key]);
            } else {
                lastResultCache[key] = 'empty';
                showLastResultEmpty();
            }
        }).catch(function() {
            // Тихо — оставляем как есть
            hint.classList.add('hidden');
        });
    }, 280);
}

// Открыть модалку для ДОБАВЛЕНИЯ нового упражнения / суперсета / трисета в указанный день
function openAddExerciseModal(dayName) {
    if (!currentClientCard) return;
    currentEditingRow = null;
    currentEditingMode = 'add';
    currentAddDay = dayName || '';
    currentSetType = 'single';
    currentEditingPrefix = '';

    document.getElementById('ex-editor-title').textContent = '+ Новое упражнение' + (dayName ? ' · ' + dayName : '');

    // Скрываем переключатель типа и блоки B/C — для одиночного режима они не нужны
    // (для суперсета/трисета используется отдельная модалка #ex-block-modal через showAddTypeDialog)
    var typeSwitch = document.getElementById('ex-type-switch'); if (typeSwitch) typeSwitch.classList.add('hidden');
    var bB = document.getElementById('ex-block-B'); if (bB) bB.classList.add('hidden');
    var bC = document.getElementById('ex-block-C'); if (bC) bC.classList.add('hidden');
    var tA = document.getElementById('ex-block-A-title'); if (tA) tA.classList.add('hidden');
    currentSetType = 'single';

    // Очищаем поля (блок A — единственный в одиночном режиме)
    document.getElementById('ex-edit-name').value = '';
    document.getElementById('ex-edit-weight').value = '';
    document.getElementById('ex-edit-reps').value = '';
    document.getElementById('ex-edit-sets').value = '4';
    document.getElementById('ex-edit-rpe').value = '8';
    document.getElementById('ex-edit-note').value = '';

    // Скрываем кнопку «Удалить» и подсказку фактов (имя пустое — нечего показывать)
    var delBtn = document.getElementById('ex-edit-delete-btn');
    if (delBtn) delBtn.classList.add('hidden');
    var saveBtn = document.getElementById('ex-edit-save-btn');
    if (saveBtn) saveBtn.textContent = '➕ Добавить';
    var hint = document.getElementById('ex-edit-history-hint');
    hint.textContent = '';
    hint.classList.add('hidden');
    hint.classList.remove('ex-hint-empty', 'ex-hint-loading');

    document.getElementById('ex-editor-modal').classList.remove('hidden');

    // Готовим библиотеку
    libraryFilterMuscle = 'day';
    librarySearchText = '';
    activeNameInputId = 'ex-edit-name';
    closeExerciseLibrary();
    loadExerciseLibrary();
    setTimeout(function() {
        var nameInput = document.getElementById('ex-edit-name');
        if (nameInput) nameInput.focus();
    }, 200);
}

// Переключение типа набора: single / superset / triset
function setSetType(type) {
    currentSetType = type;
    var blockB = document.getElementById('ex-block-B');
    var blockC = document.getElementById('ex-block-C');
    var titleA = document.getElementById('ex-block-A-title');

    if (type === 'single') {
        blockB.classList.add('hidden');
        blockC.classList.add('hidden');
        titleA.classList.add('hidden');
    } else if (type === 'superset') {
        blockB.classList.remove('hidden');
        blockC.classList.add('hidden');
        titleA.classList.remove('hidden');
    } else if (type === 'triset') {
        blockB.classList.remove('hidden');
        blockC.classList.remove('hidden');
        titleA.classList.remove('hidden');
    }

    // Обновим визуально активную кнопку переключателя
    document.querySelectorAll('.ex-type-btn').forEach(function(btn) {
        btn.classList.toggle('active', btn.dataset.setType === type);
    });

    // Закроем библиотеку если была открыта (контекст полей сменился)
    closeExerciseLibrary();
}

function initSetTypeSwitch() {
    document.querySelectorAll('.ex-type-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            setSetType(btn.dataset.setType);
            if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred('light');
        });
    });
}

function closeExerciseEditor() {
    document.getElementById('ex-editor-modal').classList.add('hidden');
    closeExerciseLibrary();
    currentEditingRow = null;
}

async function saveExerciseEdit() {
    if (!currentClientCard) return;
    var saveBtn = document.getElementById('ex-edit-save-btn');
    var origText = saveBtn.textContent;

    var nameVal = document.getElementById('ex-edit-name').value.trim();
    if (!nameVal) {
        tg.showAlert('Укажи название упражнения');
        return;
    }

    // ── РЕЖИМ ДОБАВЛЕНИЯ — оставляем как было, сразу сохраняем и перегружаем программу ──
    if (currentEditingMode === 'add') {
        saveBtn.disabled = true;
        saveBtn.textContent = '⏳ Сохранение...';

        var params = {
            action: 'addClientExercise',
            sheetName: currentClientCard.sheetName,
            dayName: currentAddDay,
            exercise: nameVal,
            weightPlan: document.getElementById('ex-edit-weight').value.trim(),
            reps: document.getElementById('ex-edit-reps').value.trim(),
            sets: document.getElementById('ex-edit-sets').value.trim(),
            rpe: document.getElementById('ex-edit-rpe').value.trim(),
            note: document.getElementById('ex-edit-note').value.trim()
        };

        // Если есть несохранённые правки — сначала сливаем их, иначе порядковые rowIndex'ы могут уехать
        if (Object.keys(pendingExerciseEdits).length > 0) {
            saveBtn.textContent = '⏳ Сохраняю прошлые изменения...';
            var flushOk = await flushPendingExerciseEdits();
            if (!flushOk) {
                tg.showAlert('Не удалось сохранить прошлые изменения — добавление отменено.');
                saveBtn.disabled = false;
                saveBtn.textContent = origText;
                return;
            }
        }

        try {
            var query = Object.keys(params).map(function(k) {
                return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]);
            }).join('&');
            var response = await fetch(APPS_SCRIPT_URL + '?' + query);
            var data = await response.json();
            if (!data.success) {
                tg.showAlert('Ошибка сохранения: ' + (data.error || 'не удалось'));
                saveBtn.disabled = false;
                saveBtn.textContent = origText;
                return;
            }
            saveBtn.textContent = '✅ Добавлено';
            if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
            await loadClientProgram(currentClientCard.sheetName);
            setTimeout(function() {
                closeExerciseEditor();
                saveBtn.disabled = false;
                saveBtn.textContent = origText;
            }, 400);
        } catch (error) {
            console.error('Save exercise error:', error);
            tg.showAlert('Ошибка соединения ❌');
            saveBtn.disabled = false;
            saveBtn.textContent = origText;
        }
        return;
    }

    // ── РЕЖИМ РЕДАКТИРОВАНИЯ — кладём в очередь, не дёргаем API ──
    if (!currentEditingRow) return;
    // Восстанавливаем префикс «СЕТ:»/«ТРИСЕТ:» если упражнение было частью связки
    var nameWithPrefix = currentEditingPrefix ? (currentEditingPrefix + nameVal) : nameVal;
    var editParams = {
        action: 'updateClientExercise',
        sheetName: currentClientCard.sheetName,
        rowIndex: currentEditingRow,
        exercise: nameWithPrefix,
        weightPlan: document.getElementById('ex-edit-weight').value.trim(),
        reps: document.getElementById('ex-edit-reps').value.trim(),
        sets: document.getElementById('ex-edit-sets').value.trim(),
        rpe: document.getElementById('ex-edit-rpe').value.trim(),
        note: document.getElementById('ex-edit-note').value.trim()
    };

    // 1. Запоминаем правку в очередь (overwrite если ту же строку уже редактировали)
    pendingExerciseEdits[currentEditingRow] = editParams;

    // 2. Обновляем DOM оптимистично — клиент видит новые значения сразу
    updateExerciseInDOM(currentEditingRow, editParams);

    // 3. Обновляем кэш чтоб при повторном открытии модалки были свежие данные
    var cached = currentProgramExercisesByRow[currentEditingRow];
    if (cached) {
        cached.exercise = editParams.exercise;
        cached.weightPlan = editParams.weightPlan;
        cached.reps = editParams.reps;
        cached.sets = editParams.sets;
        cached.rpe = editParams.rpe;
        cached.note = editParams.note;
    }

    // 4. Помечаем строку как «есть несохранённое изменение»
    markExerciseDirty(currentEditingRow);

    // 5. Показываем/обновляем плавающую кнопку «Сохранить изменения (N)»
    updateBulkSaveBar();

    if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred('light');
    closeExerciseEditor();
}


// Поставить визуальную метку «есть несохранённое изменение» на строку упражнения
function markExerciseDirty(rowIndex) {
    if (!rowIndex) return;
    var editBtn = document.querySelector('.cc-ex-edit-btn[onclick*="openExerciseEditor(' + rowIndex + ')"]');
    if (!editBtn) return;
    var row = editBtn.closest('.cc-ex-row');
    if (row) row.classList.add('cc-ex-pending');
}

function unmarkExerciseDirty(rowIndex) {
    if (!rowIndex) return;
    var editBtn = document.querySelector('.cc-ex-edit-btn[onclick*="openExerciseEditor(' + rowIndex + ')"]');
    if (!editBtn) return;
    var row = editBtn.closest('.cc-ex-row');
    if (row) row.classList.remove('cc-ex-pending');
}

// Показать/скрыть плавающую кнопку «Сохранить изменения», обновить счётчик
function updateBulkSaveBar() {
    var bar = document.getElementById('cc-bulk-save-bar');
    if (!bar) return;
    var count = Object.keys(pendingExerciseEdits).length;
    var btn = document.getElementById('cc-bulk-save-btn');
    if (count === 0) {
        bar.classList.add('hidden');
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '💾 Сохранить изменения';
        }
        return;
    }
    bar.classList.remove('hidden');
    if (btn && !btn.disabled) {
        btn.innerHTML = '💾 Сохранить изменения (' + count + ')';
    }
}

// Сохранить все накопленные правки одним проходом (вызывается из плавающей кнопки)
async function saveAllPendingEdits() {
    var keys = Object.keys(pendingExerciseEdits);
    if (keys.length === 0) return;
    var btn = document.getElementById('cc-bulk-save-btn');
    if (!btn) return;
    btn.disabled = true;

    var total = keys.length;
    var saved = 0, failed = 0;
    for (var i = 0; i < keys.length; i++) {
        var rowIdx = keys[i];
        var params = pendingExerciseEdits[rowIdx];
        btn.innerHTML = '⏳ Сохранение ' + (i + 1) + '/' + total + '...';
        try {
            var query = Object.keys(params).map(function(k) {
                return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]);
            }).join('&');
            var resp = await fetch(APPS_SCRIPT_URL + '?' + query);
            var data = await resp.json();
            if (data.success) {
                saved++;
                delete pendingExerciseEdits[rowIdx];
                unmarkExerciseDirty(rowIdx);
            } else {
                failed++;
                console.error('Bulk save failed for row ' + rowIdx, data.error);
            }
        } catch (err) {
            failed++;
            console.error('Bulk save network error for row ' + rowIdx, err);
        }
    }

    if (failed === 0) {
        btn.innerHTML = '✅ Сохранено!';
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        setTimeout(function() {
            updateBulkSaveBar();
        }, 1200);
    } else {
        tg.showAlert('Сохранено: ' + saved + '\nОшибок: ' + failed + '\n\nНеудачные правки остались в очереди — попробуй сохранить ещё раз.');
        btn.disabled = false;
        updateBulkSaveBar();
    }
}

// Утилита: синхронно дождаться сохранения очереди (используется перед add/delete/reload).
// Возвращает true если очередь пустая или всё сохранилось без ошибок.
async function flushPendingExerciseEdits() {
    if (Object.keys(pendingExerciseEdits).length === 0) return true;
    await saveAllPendingEdits();
    return Object.keys(pendingExerciseEdits).length === 0;
}

// Сбросить очередь (например при закрытии карточки без сохранения)
function discardPendingExerciseEdits() {
    var keys = Object.keys(pendingExerciseEdits);
    keys.forEach(function(k) { unmarkExerciseDirty(k); });
    pendingExerciseEdits = {};
    updateBulkSaveBar();
}

async function deleteExerciseEdit() {
    if (!currentEditingRow || !currentClientCard) return;
    var ex = currentProgramExercisesByRow[currentEditingRow];
    var name = ex ? cleanExerciseName(ex.exercise) : 'упражнение';
    var confirmed = await tgConfirm('Удалить «' + name + '» из программы?');
    if (!confirmed) return;

    var delBtn = document.getElementById('ex-edit-delete-btn');
    var origText = delBtn.textContent;
    delBtn.disabled = true;
    delBtn.textContent = '⏳ Удаление...';

    // Удаление сдвигает rowIndex'ы — сначала сливаем все накопленные правки,
    // иначе они применятся не к тем упражнениям.
    if (Object.keys(pendingExerciseEdits).length > 0) {
        delBtn.textContent = '⏳ Сохраняю прошлые правки...';
        var flushOk = await flushPendingExerciseEdits();
        if (!flushOk) {
            tg.showAlert('Не удалось сохранить прошлые изменения — удаление отменено.');
            delBtn.disabled = false;
            delBtn.textContent = origText;
            return;
        }
        delBtn.textContent = '⏳ Удаление...';
    }

    try {
        var url = APPS_SCRIPT_URL + '?action=deleteClientExercise' +
            '&sheetName=' + encodeURIComponent(currentClientCard.sheetName) +
            '&rowIndex=' + currentEditingRow;
        var response = await fetch(url);
        var data = await response.json();
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось'));
            delBtn.disabled = false;
            delBtn.textContent = origText;
            return;
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        if (data.alreadyGone) tg.showAlert('Это упражнение уже удалено — обновляю программу.');
        await loadClientProgram(currentClientCard.sheetName);
        closeExerciseEditor();
        delBtn.disabled = false;
        delBtn.textContent = origText;
    } catch (error) {
        console.error('Delete exercise error:', error);
        tg.showAlert('Ошибка соединения ❌');
        delBtn.disabled = false;
        delBtn.textContent = origText;
    }
}

// Точечно обновить значения упражнения в DOM без полного перерендера программы.
// fields: { exercise, weightPlan, reps, sets, rpe, note } — все поля как в params для бэка.
function updateExerciseInDOM(rowIndex, fields) {
    if (!rowIndex) return;
    // Находим кнопку ✏️ с этим rowIndex — оттуда поднимаемся к .cc-ex-row
    var editBtn = document.querySelector('.cc-ex-edit-btn[onclick*="openExerciseEditor(' + rowIndex + ')"]');
    if (!editBtn) return;
    var row = editBtn.closest('.cc-ex-row');
    if (!row) return;

    // ── Имя ──
    if (fields.exercise !== undefined) {
        var nameEl = row.querySelector('.cc-ex-name');
        if (nameEl) {
            // Сохраняем bind-метку A/B/C если есть
            var labelEl = nameEl.querySelector('.cc-ex-suplabel');
            var labelHtml = labelEl ? labelEl.outerHTML : '';
            nameEl.innerHTML = labelHtml + cleanExerciseName(fields.exercise);
        }
    }

    // ── Ячейки Вес / Повт. / Подх. / RPE ──
    var cells = row.querySelectorAll('.cc-ex-cell .cc-cell-value');
    if (cells.length >= 4) {
        if (fields.weightPlan !== undefined) {
            var v = fields.weightPlan;
            cells[0].textContent = (v !== '' && v != null ? v : '—') + ' кг';
        }
        if (fields.reps !== undefined) {
            cells[1].textContent = (fields.reps !== '' && fields.reps != null) ? fields.reps : '—';
        }
        if (fields.sets !== undefined) {
            cells[2].textContent = (fields.sets !== '' && fields.sets != null) ? fields.sets : '—';
        }
        if (fields.rpe !== undefined) {
            cells[3].textContent = (fields.rpe !== '' && fields.rpe != null) ? fields.rpe : '—';
        }
    }

    // ── Заметка ──
    if (fields.note !== undefined) {
        var existingNote = row.querySelector('.cc-ex-note');
        var noteText = (fields.note || '').toString().trim();
        if (noteText) {
            if (existingNote) {
                existingNote.textContent = noteText;
            } else {
                var noteDiv = document.createElement('div');
                noteDiv.className = 'cc-ex-note';
                noteDiv.textContent = noteText;
                row.appendChild(noteDiv);
            }
        } else if (existingNote) {
            existingNote.remove();
        }
    }
}

function initExerciseEditor() {
    var saveBtn = document.getElementById('ex-edit-save-btn');
    var delBtn = document.getElementById('ex-edit-delete-btn');
    if (saveBtn) saveBtn.addEventListener('click', saveExerciseEdit);
    if (delBtn) delBtn.addEventListener('click', deleteExerciseEdit);

    initSetTypeSwitch();

    // Поля «Название» (A, B, C): фокус → открыть библиотеку, ввод → фильтр
    document.querySelectorAll('.ex-name-field').forEach(function(input) {
        input.addEventListener('focus', function() {
            activeNameInputId = input.id;
            openExerciseLibrary();
        });
        input.addEventListener('input', function() {
            // Активным считается тот, в кого вводят
            activeNameInputId = input.id;
            librarySearchText = (input.value || '').toLowerCase().trim();
            renderLibraryList();
            // Для главного поля «Название» (блок A) — обновим подсказку с последним результатом
            if (input.id === 'ex-edit-name') {
                loadAndShowLastResult(input.value);
            }
        });
    });
}

// ========== БИБЛИОТЕКА УПРАЖНЕНИЙ (Фаза 2B+) ==========

var exerciseLibrary = [];
var exerciseLibraryLoaded = false;
var libraryFilterMuscle = 'day';  // 'day' | 'all' | <название мышцы>
var librarySearchText = '';

// Известные группы мышц (в нижнем регистре) для парсинга имён дней.
// Соответствует значениям колонки E листа «Упражнения».
// «Домашняя тренировка» — не мышца, а вид занятия, но живёт в том же списке
// намеренно: и чипы дня, и фильтр библиотеки работают по полю group у
// упражнения, а тренеру нужно отобрать «то, что можно делать дома» ровно
// так же, как отбирают ноги или спину. Стоит последней — чтобы длинная
// подпись не разрывала ряд коротких.
var KNOWN_MUSCLES = ['грудь', 'спина', 'плечи', 'бицепс', 'трицепс', 'ноги', 'ягодицы', 'пресс', 'икры', 'предплечья', 'домашняя тренировка'];

// Подписи, которые нельзя получить простым «первая буква заглавная».
var MUSCLE_LABELS = { 'ягодицы': 'Ягодицы / ЗПБ' };

// Одна группа — несколько написаний. Ягодицы и заднюю поверхность бедра
// тренируют вместе и одними и теми же упражнениями, поэтому в интерфейсе это
// одна кнопка. Но в базе у части упражнений уже проставлено «Ягодицы», у
// части «ЗПБ», а дни называют и так, и так — значит по одной кнопке должны
// находиться оба написания, иначе половина упражнений пропала бы из фильтра.
var MUSCLE_ALIASES = { 'ягодицы': ['ягодицы', 'зпб'] };

function muscleAliases(m) {
    return MUSCLE_ALIASES[m] || [m];
}

function muscleLabel(m) {
    return MUSCLE_LABELS[m] || (m.charAt(0).toUpperCase() + m.slice(1));
}

// Проверяет, относится ли упражнение к указанной мышце.
// Только по полю group из листа «Упражнения» — никаких эвристик по названию.
function exerciseHitsMuscle(ex, muscle) {
    var g = (ex.group || '').toLowerCase().trim();
    if (!g) return false;
    return muscleAliases(muscle).some(function(alias) { return g.indexOf(alias) >= 0; });
}

async function loadExerciseLibrary() {
    if (exerciseLibraryLoaded) return;
    try {
        var url = APPS_SCRIPT_URL + '?action=getExerciseLibrary';
        var resp = await fetch(url);
        var data = await resp.json();
        if (data && !data.error) {
            exerciseLibrary = data.exercises || [];
            exerciseLibraryLoaded = true;
        }
    } catch (e) {
        console.error('Library load error:', e);
    }
}

// Достаёт мышцы из названия дня тренировки (например "Пн Спина-Грудь-Плечи")
function getMusclesFromDay(dayName) {
    var name = (dayName || '').toLowerCase();
    return KNOWN_MUSCLES.filter(function(m) {
        return muscleAliases(m).some(function(alias) { return name.indexOf(alias) >= 0; });
    });
}

// Совпадает ли упражнение с заданным набором групп мышц (хотя бы одной)
function exerciseMatchesMuscles(ex, muscles) {
    if (!muscles || muscles.length === 0) return true;
    return muscles.some(function(m) { return exerciseHitsMuscle(ex, m); });
}

async function openExerciseLibrary() {
    var panel = document.getElementById('ex-library-panel');
    if (!panel) return;
    // Панель библиотеки — один общий элемент на два модальных окна (одиночное
    // упражнение и суперсет/трисет). Физически она живёт внутри #ex-editor-modal;
    // когда открыт #ex-block-modal, тот спрятан (display:none у родителя), и
    // просто снять .hidden с самой панели недостаточно — надо перенести её узел
    // в слот нужной модалки, иначе выпадающий список не будет виден вообще.
    var targetSlot = currentSetType === 'single'
        ? document.querySelector('#ex-editor-modal .ex-editor-body')
        : document.getElementById('ex-block-library-slot');
    if (targetSlot && panel.parentElement !== targetSlot) {
        targetSlot.appendChild(panel);
    }
    panel.classList.remove('hidden');
    librarySearchText = '';

    // Показываем для какого блока сейчас выбираем (только если виден переключатель — режим add с супер/трисетом)
    var ctx = document.getElementById('ex-library-context');
    if (ctx) {
        if (currentSetType !== 'single') {
            var activeInput = document.getElementById(activeNameInputId);
            var blockLabel = activeInput ? activeInput.dataset.block : '';
            var label = blockLabel === 'A' ? 'А — первое' : (blockLabel === 'B' ? 'Б — второе' : 'В — третье');
            ctx.textContent = 'Выбираешь для: ' + label;
            ctx.classList.remove('hidden');
        } else {
            ctx.classList.add('hidden');
        }
    }

    if (!exerciseLibraryLoaded) {
        document.getElementById('ex-library-list').innerHTML = '<div class="ex-library-loading">Загрузка библиотеки...</div>';
        await loadExerciseLibrary();
    }
    renderLibraryTabs();
    renderLibraryList();
}

function closeExerciseLibrary() {
    var panel = document.getElementById('ex-library-panel');
    if (panel) panel.classList.add('hidden');
}

// Текущий «день» для фильтра библиотеки — берём из редактируемого упражнения или из режима добавления.
function getCurrentDayForLibrary() {
    if (currentEditingMode === 'add') return currentAddDay || '';
    var ex = currentEditingRow ? currentProgramExercisesByRow[currentEditingRow] : null;
    return ex ? (ex.__dayName || '') : '';
}

function renderLibraryTabs() {
    var tabsEl = document.getElementById('ex-library-tabs');
    if (!tabsEl) return;
    var dayName = getCurrentDayForLibrary();
    var muscles = getMusclesFromDay(dayName);

    var tabs = [];
    if (muscles.length > 0) {
        tabs.push({ key: 'day', label: 'Этот день' });
    } else {
        // Если в названии дня не нашли мышц — фолбэк на "Все" по умолчанию
        libraryFilterMuscle = 'all';
    }
    tabs.push({ key: 'all', label: 'Все' });
    muscles.forEach(function(m) {
        tabs.push({ key: m, label: muscleLabel(m) });
    });

    tabsEl.innerHTML = tabs.map(function(t) {
        var active = t.key === libraryFilterMuscle ? ' active' : '';
        return '<button type="button" class="ex-lib-tab' + active + '" data-muscle="' + t.key + '">' + t.label + '</button>';
    }).join('');

    tabsEl.querySelectorAll('.ex-lib-tab').forEach(function(btn) {
        btn.addEventListener('click', function() {
            tabsEl.querySelectorAll('.ex-lib-tab').forEach(function(b) { b.classList.remove('active'); });
            btn.classList.add('active');
            libraryFilterMuscle = btn.dataset.muscle;
            renderLibraryList();
        });
    });
}

function renderLibraryList() {
    var listEl = document.getElementById('ex-library-list');
    if (!listEl) return;
    var dayName = getCurrentDayForLibrary();
    var dayMuscles = getMusclesFromDay(dayName);

    var filtered = exerciseLibrary.filter(function(item) {
        // По мышцам
        if (libraryFilterMuscle === 'all') { /* без фильтра */ }
        else if (libraryFilterMuscle === 'day') {
            if (!exerciseMatchesMuscles(item, dayMuscles)) return false;
        } else {
            if (!exerciseMatchesMuscles(item, [libraryFilterMuscle])) return false;
        }
        // По строке поиска
        if (librarySearchText && item.name.toLowerCase().indexOf(librarySearchText) < 0) return false;
        return true;
    });

    if (filtered.length === 0) {
        listEl.innerHTML = '<div class="ex-library-empty">Ничего не найдено</div>';
        return;
    }

    listEl.innerHTML = filtered.slice(0, 80).map(function(item) {
        var safe = (item.name || '').replace(/'/g, "\\'").replace(/"/g, '&quot;');
        var groupHtml = item.group ? '<div class="ex-lib-item-group">' + item.group + '</div>' : '';
        return '<button type="button" class="ex-lib-item" onclick="selectExerciseFromLibrary(\'' + safe + '\')">' +
            '<div class="ex-lib-item-name">' + _escHtml(item.name) + '</div>' +
            groupHtml +
        '</button>';
    }).join('');
}

function selectExerciseFromLibrary(name) {
    var input = document.getElementById(activeNameInputId) || document.getElementById('ex-edit-name');
    if (input) input.value = name;
    closeExerciseLibrary();
    if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred('light');
    // После выбора упражнения — подгрузить «Последний раз» (только для главного поля A)
    if (input && input.id === 'ex-edit-name') {
        loadAndShowLastResult(name);
    }
}

// ========== ДОБАВЛЕНИЕ БЛОКА (суперсет / трисет) ==========

var currentBlockType = 'superset';
var currentCircuitCount = 5;   // сколько упражнений в круге — задаёт тренер при создании
var currentBlockDay = '';

// Кастомный диалог выбора типа добавления — стилизованный, единообразный на всех платформах
var pendingAddDay = '';

function showAddTypeDialog(dayName) {
    if (!currentClientCard) return;
    pendingAddDay = dayName || '';
    var subtitle = document.getElementById('ex-add-type-subtitle');
    if (subtitle) subtitle.textContent = dayName ? ('в день: ' + dayName) : '';
    document.getElementById('ex-add-type-modal').classList.remove('hidden');
}

// Сколько упражнений в круге — спрашиваем сразу, до формы: от этого зависит,
// сколько секций рисовать, а дорисовывать их на ходу в этой форме нечем.
var pendingBlockType = 'circuit';

function askBlockSize(dayName, type) {
    pendingBlockType = type;
    var info = blockTypeInfo(type) || blockTypeInfo('circuit');
    var box = document.getElementById('circuit-size-modal');
    var row = document.getElementById('circuit-size-row');
    row.innerHTML = [2, 3, 4, 5, 6, 7, 8, 10, 12, 14, 16].map(function(n) {
        return '<button type="button" class="add-day-chip" onclick="startCircuit(\'' +
            String(dayName || '').replace(/'/g, "\\'") + '\', ' + n + ')">' + n + '</button>';
    }).join('');
    document.getElementById('circuit-size-title').textContent = 'Сколько упражнений: ' + info.short.toLowerCase() + '?';
    document.getElementById('circuit-size-subtitle').textContent = dayName ? ('в день: ' + dayName) : '';
    box.classList.remove('hidden');
}

// Старое имя — на случай вызова из закэшированной разметки.
function askCircuitSize(dayName) {
    askBlockSize(dayName, 'circuit');
}

function closeCircuitSizeModal() {
    document.getElementById('circuit-size-modal').classList.add('hidden');
}

function startCircuit(dayName, count) {
    closeCircuitSizeModal();
    openBlockModal(dayName, pendingBlockType, count);
}

function closeAddTypeDialog() {
    document.getElementById('ex-add-type-modal').classList.add('hidden');
}

function initAddTypeDialog() {
    document.querySelectorAll('.ex-add-type-option').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var type = btn.dataset.type;
            closeAddTypeDialog();
            if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred('light');
            if (type === 'single')        openAddExerciseModal(pendingAddDay);
            else if (type === 'superset') openBlockModal(pendingAddDay, 'superset');
            else if (type === 'triset')   openBlockModal(pendingAddDay, 'triset');
            else if (blockTypeInfo(type)) askBlockSize(pendingAddDay, type);
        });
    });
}

// ========== УПРАВЛЕНИЕ ДНЯМИ ТРЕНИРОВКИ (Фаза C) ==========

// Диалог действий с днём — переименовать или удалить
function showDayActionsDialog(dayName) {
    if (!currentClientCard || !dayName) return;
    document.getElementById('day-actions-name').textContent = dayName;
    document.getElementById('day-actions-modal').dataset.dayName = dayName;
    document.getElementById('day-actions-modal').classList.remove('hidden');
}

function closeDayActionsDialog() {
    document.getElementById('day-actions-modal').classList.add('hidden');
}

async function renameCurrentDay() {
    var modal = document.getElementById('day-actions-modal');
    var oldName = modal.dataset.dayName;
    closeDayActionsDialog();
    if (!oldName || !currentClientCard) return;

    var newName = await new Promise(function(resolve) {
        if (tg && typeof tg.showPopup === 'function' && false) {
            // showPopup не умеет принимать ввод текста — используем JS prompt
        }
        resolve(prompt('Новое название дня:', oldName));
    });
    if (!newName || newName.trim() === '' || newName.trim() === oldName) return;

    try {
        var url = APPS_SCRIPT_URL + '?action=renameClientDay' +
            '&sheetName=' + encodeURIComponent(currentClientCard.sheetName) +
            '&oldDayName=' + encodeURIComponent(oldName) +
            '&newDayName=' + encodeURIComponent(newName.trim());
        var resp = await fetch(url);
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось'));
            return;
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        await loadClientProgram(currentClientCard.sheetName);
    } catch (error) {
        console.error('Rename day error:', error);
        tg.showAlert('Ошибка соединения ❌');
    }
}

async function deleteCurrentDay() {
    var modal = document.getElementById('day-actions-modal');
    var dayName = modal.dataset.dayName;
    closeDayActionsDialog();
    if (!dayName || !currentClientCard) return;

    var confirmed = await tgConfirm('Удалить день «' + dayName + '» вместе со всеми упражнениями внутри?');
    if (!confirmed) return;

    try {
        var url = APPS_SCRIPT_URL + '?action=deleteClientDay' +
            '&sheetName=' + encodeURIComponent(currentClientCard.sheetName) +
            '&dayName=' + encodeURIComponent(dayName);
        var resp = await fetch(url);
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось'));
            return;
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        await loadClientProgram(currentClientCard.sheetName);
    } catch (error) {
        console.error('Delete day error:', error);
        tg.showAlert('Ошибка соединения ❌');
    }
}

// День недели (один) + группы мышц (несколько) галочками — вместо ручного
// набора текста вида "Пт Грудь-Трицепс". Итоговая строка собирается сама и
// уходит в addClientDay тем же способом, что и раньше.
var ADD_DAY_WEEKDAYS = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
var addDaySelectedWeekday = '';
var addDaySelectedMuscles = [];

function _capitalizeMuscle(m) {
    return muscleLabel(m);
}

function showAddDayDialog() {
    if (!currentClientCard) return;
    addDaySelectedWeekday = '';
    addDaySelectedMuscles = [];

    var weekdayRow = document.getElementById('add-day-weekday-row');
    weekdayRow.innerHTML = ADD_DAY_WEEKDAYS.map(function(d) {
        return '<button type="button" class="add-day-chip" data-day="' + d + '" onclick="selectAddDayWeekday(\'' + d + '\')">' + d + '</button>';
    }).join('');

    var muscleGrid = document.getElementById('add-day-muscle-grid');
    muscleGrid.innerHTML = KNOWN_MUSCLES.map(function(m) {
        return '<button type="button" class="add-day-chip" data-muscle="' + m + '" onclick="toggleAddDayMuscle(\'' + m + '\')">' + _capitalizeMuscle(m) + '</button>';
    }).join('');

    updateAddDayPreview();
    document.getElementById('add-day-modal').classList.remove('hidden');
}

function closeAddDayModal() {
    document.getElementById('add-day-modal').classList.add('hidden');
}

function selectAddDayWeekday(day) {
    addDaySelectedWeekday = day;
    document.querySelectorAll('#add-day-weekday-row .add-day-chip').forEach(function(btn) {
        btn.classList.toggle('active', btn.dataset.day === day);
    });
    updateAddDayPreview();
}

function toggleAddDayMuscle(muscle) {
    var idx = addDaySelectedMuscles.indexOf(muscle);
    if (idx === -1) addDaySelectedMuscles.push(muscle); else addDaySelectedMuscles.splice(idx, 1);
    document.querySelectorAll('#add-day-muscle-grid .add-day-chip').forEach(function(btn) {
        btn.classList.toggle('active', addDaySelectedMuscles.indexOf(btn.dataset.muscle) !== -1);
    });
    updateAddDayPreview();
}

function updateAddDayPreview() {
    var muscleLabel = addDaySelectedMuscles.map(_capitalizeMuscle).join('-');
    document.getElementById('add-day-preview').value = (addDaySelectedWeekday + ' ' + muscleLabel).trim();
}

async function submitAddDay() {
    if (!currentClientCard) return;
    var dayName = (document.getElementById('add-day-preview').value || '').trim();
    if (!dayName) {
        tg.showAlert('Выбери день недели и хотя бы одну группу мышц (или впиши название вручную в поле выше)');
        return;
    }
    var btn = document.getElementById('add-day-save-btn');
    var origText = btn.textContent;
    btn.disabled = true;
    btn.textContent = '⏳ Добавление...';
    try {
        var url = APPS_SCRIPT_URL + '?action=addClientDay' +
            '&sheetName=' + encodeURIComponent(currentClientCard.sheetName) +
            '&dayName=' + encodeURIComponent(dayName);
        var resp = await fetch(url);
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось'));
            return;
        }
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        if (pendingEmptyDays.indexOf(dayName) === -1) pendingEmptyDays.push(dayName);
        closeAddDayModal();
        await loadClientProgram(currentClientCard.sheetName);
    } catch (error) {
        console.error('Add day error:', error);
        tg.showAlert('Ошибка соединения ❌');
    } finally {
        btn.disabled = false;
        btn.textContent = origText;
    }
}

function openBlockModal(dayName, type, circuitCount) {
    currentBlockType = type;
    currentBlockDay = dayName || '';
    // Чтобы библиотека упражнений знала, для какого дня показывать фильтр "Этот день"
    currentEditingMode = 'add';
    currentAddDay = dayName || '';
    currentSetType = type; // 'superset' | 'triset' | 'circuit'
    // У круга размер задаёт тренер (обычно 5–6 упражнений), у остальных он
    // известен заранее.
    var numbered = blockTypeInfo(type);
    var count = numbered ? (circuitCount || numbered.defaultSize) : (type === 'triset' ? 3 : 2);
    currentCircuitCount = count;
    var title = numbered ? ('+ ' + numbered.short + ' (' + count + ' упр.)')
        : (type === 'triset' ? '+ Новый трисет (3 упр.)' : '+ Новый суперсет (2 упр.)');
    document.getElementById('ex-block-title').textContent = title + (dayName ? ' · ' + dayName : '');

    // Рендерим N секций. Каждому полю «Название» даём уникальный id и data-block,
    // чтобы оно подключалось к выпадающему списку упражнений (как в одиночном режиме).
    var html = '';
    for (var i = 0; i < count; i++) {
        var label = String.fromCharCode(65 + i); // A, B, C
        var nameInputId = 'ex-block-name-' + i;
        html +=
            '<div class="ex-block-section" data-block-idx="' + i + '">' +
                '<div class="ex-block-section-title">' + label + ' — упражнение ' + (i + 1) + '</div>' +
                '<div class="ex-editor-field">' +
                    '<label class="ex-editor-label">Название</label>' +
                    '<input type="text" id="' + nameInputId + '" class="ex-editor-input ex-block-name ex-name-field" data-idx="' + i + '" data-block="' + label + '" placeholder="Например: Жим штанги лёжа" autocomplete="off">' +
                '</div>' +
                '<div class="ex-editor-row">' +
                    '<div class="ex-editor-field">' +
                        '<label class="ex-editor-label">Вес</label>' +
                        '<input type="text" class="ex-editor-input ex-block-weight" data-idx="' + i + '" placeholder="60 или 60-70">' +
                    '</div>' +
                    '<div class="ex-editor-field">' +
                        '<label class="ex-editor-label">Повторы</label>' +
                        '<input type="text" class="ex-editor-input ex-block-reps" data-idx="' + i + '" placeholder="8 или 8-10">' +
                    '</div>' +
                '</div>' +
                '<div class="ex-editor-row">' +
                    '<div class="ex-editor-field">' +
                        '<label class="ex-editor-label">Подходы</label>' +
                        '<input type="number" inputmode="numeric" class="ex-editor-input ex-block-sets" data-idx="' + i + '" placeholder="4" value="4">' +
                    '</div>' +
                    '<div class="ex-editor-field">' +
                        '<label class="ex-editor-label">Target RPE</label>' +
                        '<input type="number" inputmode="decimal" step="0.5" min="1" max="10" class="ex-editor-input ex-block-rpe" data-idx="' + i + '" placeholder="8" value="8">' +
                    '</div>' +
                '</div>' +
                '<div class="ex-editor-field">' +
                    '<label class="ex-editor-label">Заметка тренера</label>' +
                    '<textarea class="ex-editor-textarea ex-block-note" data-idx="' + i + '" rows="1" placeholder="(опционально)"></textarea>' +
                '</div>' +
            '</div>';
    }
    document.getElementById('ex-block-body').innerHTML = html;
    document.getElementById('ex-block-modal').classList.remove('hidden');

    // Подключаем слушатели к новым полям «Название» — на focus открываем библиотеку
    document.querySelectorAll('#ex-block-body .ex-block-name').forEach(function(input) {
        input.addEventListener('focus', function() {
            activeNameInputId = input.id;
            // Сбрасываем фильтр на «Этот день» при каждом фокусе, чтобы упражнения релевантные дню были видны сразу
            libraryFilterMuscle = 'day';
            openExerciseLibrary();
        });
        input.addEventListener('input', function() {
            activeNameInputId = input.id;
            librarySearchText = (input.value || '').toLowerCase().trim();
            renderLibraryList();
        });
    });

    // Прогреваем библиотеку в фоне, чтобы первый клик открыл её без задержки
    libraryFilterMuscle = 'day';
    closeExerciseLibrary();
    loadExerciseLibrary();
}

function closeBlockModal() {
    document.getElementById('ex-block-modal').classList.add('hidden');
    closeExerciseLibrary();
}

async function saveBlock() {
    if (!currentClientCard) return;
    var saveBtn = document.getElementById('ex-block-save-btn');
    var origText = saveBtn.textContent;
    saveBtn.disabled = true;
    saveBtn.textContent = '⏳ Добавление...';

    // Собираем все секции
    var sections = document.querySelectorAll('#ex-block-body .ex-block-section');
    var exercises = [];
    for (var i = 0; i < sections.length; i++) {
        var s = sections[i];
        var name = s.querySelector('.ex-block-name').value.trim();
        if (!name) {
            tg.showAlert('Заполни название упражнения ' + String.fromCharCode(65 + i));
            saveBtn.disabled = false;
            saveBtn.textContent = origText;
            return;
        }
        // Префикс «СЕТ:» / «ТРИСЕТ:» только у первого
        if (i === 0) {
            // У круга в префикс уходит и размер — по нему потом восстанавливается
            // граница связки (см. circuitSize).
            var blockInfo = blockTypeInfo(currentBlockType);
            var prefix = blockInfo ? (blockInfo.prefix + ' ' + sections.length + ': ')
                : (currentBlockType === 'triset' ? 'ТРИСЕТ: ' : 'СЕТ: ');
            name = prefix + name;
        }
        exercises.push({
            exercise: name,
            weightPlan: s.querySelector('.ex-block-weight').value.trim(),
            reps: s.querySelector('.ex-block-reps').value.trim(),
            sets: s.querySelector('.ex-block-sets').value.trim(),
            rpe: s.querySelector('.ex-block-rpe').value.trim(),
            note: s.querySelector('.ex-block-note').value.trim()
        });
    }

    try {
        var url = APPS_SCRIPT_URL +
            '?action=addClientExercises&sheetName=' + encodeURIComponent(currentClientCard.sheetName) +
            '&dayName=' + encodeURIComponent(currentBlockDay);
        var resp = await fetch(url, {
            method: 'POST',
            body: JSON.stringify({ exercises: exercises })
        });
        var data = await resp.json();
        if (!data.success) {
            tg.showAlert('Ошибка: ' + (data.error || 'не удалось'));
            saveBtn.disabled = false;
            saveBtn.textContent = origText;
            return;
        }
        saveBtn.textContent = '✅ Добавлено';
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
        await loadClientProgram(currentClientCard.sheetName);
        setTimeout(function() {
            closeBlockModal();
            saveBtn.disabled = false;
            saveBtn.textContent = origText;
        }, 400);
    } catch (error) {
        console.error('Save block error:', error);
        tg.showAlert('Ошибка соединения ❌');
        saveBtn.disabled = false;
        saveBtn.textContent = origText;
    }
}

function initBlockModal() {
    var saveBtn = document.getElementById('ex-block-save-btn');
    if (saveBtn) saveBtn.addEventListener('click', saveBlock);
}

// ========== MEASUREMENTS TAB ==========

var measurementsData = [];
var measurementsChart = null;
var measSelectInitialized = false;

var MEAS_LABELS = {
    weight: 'Вес', shoulders: 'Плечи', chest: 'Грудь', waist: 'Талия',
    hips: 'Бёдра', bicep: 'Бицепс', thigh: 'Бедро'
};
var MEAS_UNITS = {
    weight: 'кг', shoulders: 'см', chest: 'см', waist: 'см',
    hips: 'см', bicep: 'см', thigh: 'см'
};

async function loadMeasurementsData() {
    try {
        var chatId = _myChatId();
        var url = APPS_SCRIPT_URL + '?action=getMeasurements&chatId=' + chatId;
        var response = await fetch(url);
        var data = await response.json();
        if (data.error) {
            document.getElementById('measurements-latest').innerHTML = '<div class="no-data">Ошибка: ' + data.error + '</div>';
            initMeasForm();
            return;
        }
        measurementsData = data.measurements || [];
        renderPhotoProgress();
        if (measurementsData.length === 0) {
            document.getElementById('measurements-latest').innerHTML =
                '<div class="no-data">Пока нет замеров<br><br>Заполни форму ниже, чтобы записать первые</div>';
            document.getElementById('measurements-list').innerHTML = '';
            initMeasForm();
            return;
        }
        renderLatestMeasurements();
        renderMeasurementsChart('weight');
        renderMeasurementsHistory();
        initMeasForm();
        if (!measSelectInitialized) {
            measSelectInitialized = true;
            document.getElementById('measurement-select').addEventListener('change', function(e) {
                renderMeasurementsChart(e.target.value);
            });
        }
    } catch (error) {
        console.error('Measurements load error:', error);
        document.getElementById('measurements-latest').innerHTML = '<div class="no-data">Ошибка загрузки замеров</div>';
        initMeasForm();
    }
}

// ===== ФОТО ПРОГРЕССА (хиро-секция вкладки «Замеры») =====
// Показываем клиенту его же фото: первое сохранённое и последнее — рядом,
// с датой и весом, как в отчёте тренера (см. renderStatsPhotoCompareStrip).
function renderPhotoProgress() {
    var container = document.getElementById('photo-progress-content');
    if (!container) return;

    var withPhotos = measurementsData
        .map(function(m) {
            var photos = (m.photos && m.photos.length)
                ? m.photos
                : [m.photoUrl, m.photoUrl2, m.photoUrl3].filter(function(u) { return !!u; });
            return { date: m.date, weight: m.weight, photos: photos };
        })
        .filter(function(m) { return m.photos.length > 0; });

    if (withPhotos.length === 0) {
        container.innerHTML =
            '<div class="photo-progress-empty">' +
                '<div class="photo-progress-empty-icon">' + _homeIcon('image') + '</div>' +
                '<div>Пока нет фото прогресса.<br>Прикрепи первое фото в форме ниже</div>' +
            '</div>';
        return;
    }

    var first = withPhotos[0];
    var last = withPhotos[withPhotos.length - 1];
    var showBoth = withPhotos.length > 1;

    // В карточке "Было/Сейчас" — один (главный) ракурс на дату, чтобы влезало
    // на любой ширине экрана; остальные ракурсы этой же даты — бейджем и
    // полностью доступны в истории замеров ниже.
    function renderCol(m, badge) {
        var extra = m.photos.length - 1;
        return '<div class="photo-progress-col">' +
            (badge ? '<div class="photo-progress-badge">' + badge + '</div>' : '') +
            '<div class="photo-progress-date">' + formatDate(m.date) + '</div>' +
            (m.weight != null ? '<div class="photo-progress-weight">' + m.weight + ' кг</div>' : '') +
            '<div class="photo-progress-photos">' +
                '<img class="photo-progress-photo" src="' + m.photos[0] + '" onclick="tg.openLink(\'' + m.photos[0] + '\')">' +
            '</div>' +
            (extra > 0 ? '<div class="photo-progress-extra">+' + extra + ' ' + (extra === 1 ? 'ракурс' : 'ракурса') + '</div>' : '') +
        '</div>';
    }

    var colsHtml = showBoth
        ? renderCol(first, 'Было') + renderCol(last, 'Сейчас')
        : renderCol(first, null);

    var gapHtml = '';
    if (showBoth) {
        var d1 = _parseDateRu(first.date), d2 = _parseDateRu(last.date);
        if (d1 && d2 && d2 > d1) {
            var days = Math.round((d2 - d1) / 86400000);
            var weightDiffHtml = '';
            if (first.weight != null && last.weight != null) {
                var diff = (last.weight - first.weight).toFixed(1);
                var cls = diff > 0 ? 'diff-up' : (diff < 0 ? 'diff-down' : 'diff-neutral');
                weightDiffHtml = ' · <span class="' + cls + '">' + (diff > 0 ? '+' : '') + diff + ' кг</span>';
            }
            gapHtml = '<div class="photo-progress-gap">' + days + ' дн. в пути' + weightDiffHtml + '</div>';
        }
    }

    container.innerHTML =
        '<div class="photo-progress-cols">' + colsHtml + '</div>' +
        gapHtml +
        (withPhotos.length > 2 ? '<div class="photo-progress-hint">Все фото — в истории замеров ниже</div>' : '');
}

// Показатели, где СНИЖЕНИЕ — хорошая динамика. Для всех остальных хорошей
// считается прибавка: плечи, грудь, бёдра, бицепс и бедро растут вместе с
// мышцами, и красить их рост красным неправильно.
var MEAS_LOWER_IS_BETTER = { weight: true, waist: true };

function renderLatestMeasurements() {
    var latest = measurementsData[measurementsData.length - 1];
    var prev = measurementsData.length >= 2 ? measurementsData[measurementsData.length - 2] : null;
    var keys = ['weight', 'shoulders', 'chest', 'waist', 'hips', 'bicep', 'thigh'];
    var items = keys.map(function(key) {
        var val = latest[key];
        var diffHtml = '';
        if (prev && prev[key] != null && val != null) {
            var diff = (val - prev[key]).toFixed(1);
            // .diff-up / .diff-down по-прежнему означают НАПРАВЛЕНИЕ и общие
            // с тренерской статистикой — их смысл не меняем. Цвет вешаем на
            // отдельный класс, который есть только на этом экране: он говорит
            // не «выросло/упало», а «хорошо/плохо».
            var grew = Number(diff) > 0;
            var good = MEAS_LOWER_IS_BETTER[key] ? !grew : grew;
            var tone = good ? ' diff-good' : ' diff-bad';
            if (diff > 0) diffHtml = '<div class="latest-item-diff diff-up' + tone + '">+' + diff + '</div>';
            else if (diff < 0) diffHtml = '<div class="latest-item-diff diff-down' + tone + '">' + diff + '</div>';
            else diffHtml = '<div class="latest-item-diff diff-neutral">0</div>';
        }
        return '<div class="latest-item">' +
            '<div class="latest-item-value">' + (val != null ? val : '—') + '</div>' +
            '<div class="latest-item-label">' + MEAS_LABELS[key] + ' (' + MEAS_UNITS[key] + ')</div>' +
            diffHtml +
        '</div>';
    }).join('');

    document.getElementById('measurements-latest').innerHTML =
        '<div class="latest-card">' +
            '<div class="latest-card-title">Последние замеры</div>' +
            '<div class="latest-card-date">' + formatDate(latest.date) + '</div>' +
            '<div class="latest-grid">' + items + '</div>' +
        '</div>';
}

// ===== MEASUREMENTS INPUT FORM =====

var measFormInitialized = false;

function initMeasForm() {
    if (measFormInitialized) return;
    measFormInitialized = true;

    // Green highlight on filled inputs
    document.querySelectorAll('.meas-input').forEach(function(input) {
        input.addEventListener('input', function() {
            if (input.value) input.classList.add('filled');
            else input.classList.remove('filled');
        });
    });

    // Save button
    document.getElementById('meas-save-btn').addEventListener('click', saveMeasurements);

    // Фото прогресса — до 3 ракурсов (спереди/сбоку/сзади). Каждый слот
    // сжимается в браузере и показывает превью, как в редакторе упражнений.
    [1, 2, 3].forEach(function(slot) {
        var slotEl = document.getElementById('meas-photo-slot-' + slot);
        var fileInput = document.getElementById('meas-photo-file-' + slot);
        var removeBtn = slotEl.querySelector('.meas-photo-slot-remove');
        slotEl.addEventListener('click', function(e) {
            if (e.target === removeBtn) return;
            fileInput.click();
        });
        fileInput.addEventListener('change', function(e) {
            var file = e.target.files && e.target.files[0];
            if (!file) return;
            _compressImageFile(file, 1280, 0.82, function(result) {
                measPhotoPending[slot] = result;
                slotEl.classList.add('filled');
                slotEl.style.backgroundImage = 'url(data:' + result.mime + ';base64,' + result.base64 + ')';
                removeBtn.classList.remove('hidden');
            }, function(errMsg) {
                e.target.value = '';
                measPhotoPending[slot] = null;
                tg.showAlert('❌ ' + errMsg);
            });
        });
        removeBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            measPhotoPending[slot] = null;
            fileInput.value = '';
            slotEl.classList.remove('filled');
            slotEl.style.backgroundImage = '';
            removeBtn.classList.add('hidden');
        });
    });
}

var measPhotoPending = { 1: null, 2: null, 3: null };

// Исходная разметка кнопки «Сохранить замеры» — см. saveMeasurements ниже.
var _MEAS_SAVE_HTML = '';

async function saveMeasurements() {
    var btn = document.getElementById('meas-save-btn');
    // Разметку кнопки (вместе с иконкой) запоминаем один раз: раньше
    // состояния ставились через textContent, и иконка стиралась бы после
    // первого же сохранения.
    if (!_MEAS_SAVE_HTML) _MEAS_SAVE_HTML = btn.innerHTML;
    var fields = {
        weight: document.getElementById('meas-weight').value,
        shoulders: document.getElementById('meas-shoulders').value,
        chest: document.getElementById('meas-chest').value,
        waist: document.getElementById('meas-waist').value,
        hips: document.getElementById('meas-hips').value,
        bicep: document.getElementById('meas-bicep').value,
        thigh: document.getElementById('meas-thigh').value
    };

    // Check at least one field filled (фото само по себе тоже считается записью)
    var hasAnyPhoto = !!(measPhotoPending[1] || measPhotoPending[2] || measPhotoPending[3]);
    var hasAny = Object.values(fields).some(function(v) { return v && v.trim() !== ''; }) || hasAnyPhoto;
    if (!hasAny) {
        tg.showAlert('Заполни хотя бы одно поле или прикрепи фото');
        return;
    }

    // Иконка кнопки сохраняется во всех состояниях: раньше здесь стоял
    // textContent — он стирал её и подставлял эмодзи.
    btn.innerHTML = _homeIcon('check') + '<span>Сохранение…</span>';
    btn.classList.add('saving');
    btn.disabled = true;

    try {
        var chatId = _myChatId();
        var payload = Object.assign({}, fields);
        if (measPhotoPending[1]) {
            payload.photoBase64 = measPhotoPending[1].base64;
            payload.photoMime = measPhotoPending[1].mime;
        }
        if (measPhotoPending[2]) {
            payload.photo2Base64 = measPhotoPending[2].base64;
            payload.photo2Mime = measPhotoPending[2].mime;
        }
        if (measPhotoPending[3]) {
            payload.photo3Base64 = measPhotoPending[3].base64;
            payload.photo3Mime = measPhotoPending[3].mime;
        }
        var url = APPS_SCRIPT_URL + '?action=saveMeasurements&chatId=' + chatId;
        // Без явного Content-Type: application/json — иначе браузер шлёт CORS
        // preflight (OPTIONS), а Apps Script его не обрабатывает и запрос падает
        // с "Failed to fetch". Без заголовка тело уходит как text/plain (что для
        // CORS считается "простым" запросом), а doPost всё равно парсит его как
        // JSON — тем же способом уже работает saveExerciseMedia.
        var response = await fetch(url, {
            method: 'POST',
            body: JSON.stringify(payload)
        });
        var data = await response.json();

        if (data.success) {
            btn.classList.remove('saving');
            btn.classList.add('success');
            btn.innerHTML = _homeIcon('check') + '<span>Сохранено</span>';
            if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
            // Clear form
            document.querySelectorAll('.meas-input').forEach(function(input) {
                input.value = '';
                input.classList.remove('filled');
            });
            [1, 2, 3].forEach(function(slot) {
                measPhotoPending[slot] = null;
                var slotEl = document.getElementById('meas-photo-slot-' + slot);
                document.getElementById('meas-photo-file-' + slot).value = '';
                slotEl.classList.remove('filled');
                slotEl.style.backgroundImage = '';
                slotEl.querySelector('.meas-photo-slot-remove').classList.add('hidden');
            });
            // Reload data
            setTimeout(function() {
                btn.classList.remove('success');
                btn.innerHTML = _MEAS_SAVE_HTML;
                btn.disabled = false;
                measSelectInitialized = false;
                loadMeasurementsData();
            }, 1500);
        } else {
            tg.showAlert('Ошибка сохранения: ' + (data.error || 'Попробуй ещё раз'));
            btn.classList.remove('saving');
            btn.innerHTML = _MEAS_SAVE_HTML;
            btn.disabled = false;
        }
    } catch (error) {
        console.error('Save measurements error:', error);
        tg.showAlert('Ошибка сохранения');
        btn.classList.remove('saving');
        btn.innerHTML = _MEAS_SAVE_HTML;
        btn.disabled = false;
    }
}

function renderMeasurementsChart(key) {
    var filtered = measurementsData.filter(function(m) { return m[key] != null; });
    if (filtered.length === 0) return;
    if (measurementsChart) measurementsChart.destroy();
    var ctx = document.getElementById('measurements-chart').getContext('2d');

    // Цвета РЯДОВ ДАННЫХ, по одному на показатель: переключив показатель,
    // клиент по цвету понимает, что перед ним другой график. Это данные, а
    // не элементы интерфейса, поэтому они не акцентные.
    //
    // Ярко-красный и фиолетовый убраны: первый читался как ошибка, второй —
    // как чужой акцент. Палитра приглушённая, все семь различимы между собой.
    // Карта цветов у тренера (renderStatsMeasurements) своя и не менялась.
    var colors = {
        weight:    '#2F6BB5',  // синий — как на «Прогрессе»
        shoulders: '#4A6572',  // серо-синий
        chest:     '#3E7C8C',  // приглушённая бирюза
        waist:     '#A9743F',  // терракота вместо оранжевого
        hips:      '#6B6BA3',  // спокойный сине-лиловый вместо фиолетового
        bicep:     '#4C7A52',  // приглушённый зелёный
        thigh:     '#8A5A66'   // пыльно-винный вместо красного
    };
    var color = colors[key] || '#2F6BB5';
    var c = _hexToRgb(color) || { r: 47, g: 107, b: 181 };
    var fill = ctx.createLinearGradient(0, 0, 0, 220);
    fill.addColorStop(0, 'rgba(' + c.r + ',' + c.g + ',' + c.b + ',.20)');
    fill.addColorStop(1, 'rgba(' + c.r + ',' + c.g + ',' + c.b + ',0)');
    var FONT = { family: 'Inter, -apple-system, sans-serif', size: 11, weight: '600' };

    measurementsChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: filtered.map(function(m) { return formatDate(m.date); }),
            datasets: [{
                label: MEAS_LABELS[key] + ' (' + MEAS_UNITS[key] + ')',
                data: filtered.map(function(m) { return m[key]; }),
                borderColor: color,
                backgroundColor: fill,
                borderWidth: 2.5,
                fill: true,
                tension: 0.4,
                pointRadius: 3.5,
                pointBackgroundColor: color,
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointHoverRadius: 6,
                pointHoverBorderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: { duration: 400, easing: 'easeOutQuart' },
            layout: { padding: { top: 8, right: 4 } },
            interaction: { intersect: false, mode: 'index' },
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: '#1E2126',
                    titleColor: 'rgba(255,255,255,.62)',
                    bodyColor: '#fff',
                    titleFont: { family: FONT.family, size: 11, weight: '600' },
                    bodyFont: { family: FONT.family, size: 13, weight: '700' },
                    padding: { top: 6, bottom: 6, left: 10, right: 10 },
                    cornerRadius: 8,
                    displayColors: false,
                    caretSize: 0
                }
            },
            scales: {
                y: {
                    border: { display: false },
                    grid: { display: false },
                    ticks: {
                        padding: 6,
                        color: '#A0A4AB',
                        font: FONT,
                        // Округление: Chart.js сам подбирает шаг оси и выдаёт
                        // числа вроде 63.80000000000001 — без этого подпись
                        // такой и рисовалась, растягивая ось на пол-экрана.
                        callback: function(v) {
                            return (Math.round(v * 10) / 10) + ' ' + MEAS_UNITS[key];
                        }
                    }
                },
                x: {
                    border: { display: false },
                    grid: { color: '#F0F0F3', drawTicks: false },
                    ticks: { padding: 6, color: '#A0A4AB', font: FONT, maxRotation: 0, autoSkipPadding: 12 }
                }
            }
        }
    });
}

function renderMeasurementsHistory() {
    var list = document.getElementById('measurements-list');
    var keys = ['weight', 'shoulders', 'chest', 'waist', 'hips', 'bicep', 'thigh'];
    var reversed = measurementsData.slice().reverse();
    list.innerHTML = reversed.map(function(m, i) {
        var values = keys.map(function(key) {
            return '<div class="measurement-row-item">' +
                '<div class="measurement-row-label">' + MEAS_LABELS[key] + '</div>' +
                '<div class="measurement-row-value">' + (m[key] != null ? m[key] + ' ' + MEAS_UNITS[key] : '—') + '</div>' +
            '</div>';
        }).join('');
        var photos = (m.photos && m.photos.length)
            ? m.photos
            : [m.photoUrl, m.photoUrl2, m.photoUrl3].filter(function(u) { return !!u; });
        var photoHtml = photos.length
            ? '<div class="measurement-row-photos">' + photos.map(function(url) {
                return '<img class="measurement-row-photo" src="' + url + '" onclick="tg.openLink(\'' + url + '\')">';
            }).join('') + '</div>'
            : '';
        return '<div class="measurement-row" style="animation-delay:' + (i * 0.05) + 's">' +
            '<div class="measurement-row-date">' + formatDate(m.date) + '</div>' +
            photoHtml +
            '<div class="measurement-row-values">' + values + '</div>' +
        '</div>';
    }).join('');
}

function messageClient(chatId, name) {
    var msg = prompt('Сообщение для ' + name + ':');
    if (!msg || !msg.trim()) return;
    var text = '💬 Сообщение от тренера:\n\n' + msg;
    fetch(APPS_SCRIPT_URL + '?action=notifyClient&targetChatId=' + encodeURIComponent(chatId) + '&message=' + encodeURIComponent(text))
        .then(function(resp) { return resp.json(); })
        .then(function(data) {
            if (data.success) tg.showAlert('Сообщение отправлено! ✅');
            else tg.showAlert('Ошибка отправки ❌');
        }).catch(function() { tg.showAlert('Ошибка отправки ❌'); });
}
 